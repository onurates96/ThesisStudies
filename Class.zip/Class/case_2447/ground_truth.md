classDiagram
    class Patient {
        +int PatientID
        string Name
        string Address
        string Email
        string Phone
    }
    class Doctor {
        +int DoctorID
        string Name
        string Specialization
        string Hospital
    }
    class Appointment {
        +int AppointmentID
        int PatientID
        int DoctorID
        Date AppointmentDate
        string Notes
    }
    class Prescription {
        +int PrescriptionID
        int AppointmentID
        string Medication
        string Dosage
        string Instructions
    }
    class MedicalRecord {
        +int RecordID
        int PatientID
        int DoctorID
        Date RecordDate
        string Diagnosis
        string Treatment
    }
    Patient --> Appointment : schedules
    Doctor --> Appointment : manages
    Appointment --> Prescription : issues
    Patient --> MedicalRecord : has_records