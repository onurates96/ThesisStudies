```mermaid
classDiagram
    Patient <|-- Doctor
    Appointment: +string doctorId
    Prescription: +string patientId, string medication, string dosage
    MedicalRecord: +string patientId, string diagnosis, string symptoms
    class Doctor {
        +string name
        +age
        +experience
        +clinic
    }
    class Appointment {
        +string date
        +time
        +duration
    }
```