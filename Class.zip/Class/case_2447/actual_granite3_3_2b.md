```mermaid
classDiagram
    class Patient {
        +string name
        +string address
        +Date birthDate
        +Doctor primaryCarePhysician
        +list appointments
    }
    class Doctor {
        +string name
        +string specialization
        +list availableAppointments
        +Prescription prescribedMedication
    }
    class Appointment {
        +Date date
        +Time time
        +Patient patient
        +Doctor doctor
        +Purpose purpose
    }
    class Prescription {
        +string medicationName
        +string dosage
        +Doctor prescriber
    }
    class MedicalRecord {
        +Patient patient
        +list appointments
        +Prescription prescriptions
    }

    Patient "1" "1..*" Appointment : *
    Doctor "1.." "*" Appointment : uses
    Appointment "1"--> Patient : scheduled
    Doctor "1"--> Prescription : writes
    Prescription "1"--> MedicalRecord : records
    MedicalRecord "1.." "*" Appointment : tracks
```