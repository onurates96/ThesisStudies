```mermaid
classDiagram
    Patient <|-- Doctor | Appointment
    Prescription <|-- Medication
    MedicalRecord <|-- Information, Diagnostic

    class A {
        +string name
        +string description
        class B {
            -int age: 10
            -boolean isSenior = true
        }
        Doctor : +string specialty
        Patient : +string patientID
    }

    Doctor : +string specialization
    Appointment <|-- Doctor, Patient
    Prescription <|-- Medication
    Medicine <|-- Prescription

    MedicalRecord : +string description
    MedicalRecord : +string dateOfPrescription
    Prescription <|-- MedicalRecord
```

This Mermaid class diagram outlines a healthcare management system with classes for `Patient`, `Doctor`, and `Appointment`. It uses standard relationship connectors, adheres to the specific rules provided, and follows the guidelines for creating a valid Mermaid UML class diagram.