```mermaid
classDiagram
    class Patient
        +string name
        +int age
        +string gender
        -MedicalRecord medicalRecord
    class Doctor
        +string name
        +string specialization
        -Appointment[] appointments
        +prescribePrescription(Patient patient) -> Prescription
    class Appointment
        +dateTime time
        +Doctor doctor
        +Patient patient
    class Prescription
        +string medication
        +int dose
        +Patient patient : prescribedFor
    class MedicalRecord
        +string recordId
        +Patient patient

Patient "1" --> "0..*" Appointment : books
Patient "1" --> "1" MedicalRecord : has
Doctor "0..*" <|-- Prescription : canPrescribe
Doctor --> Appointment : manages
Appointment *-- Prescription : includes
```