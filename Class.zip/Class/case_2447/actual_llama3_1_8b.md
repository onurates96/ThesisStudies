```mermaid
classDiagram
class Patient {
  -string name
  -int age
}
class Doctor {
  +string specialization
  +string officeLocation
}
class Appointment {
  +date scheduleDate
  +time scheduledTime
  Patient -- "1" > Doctor : assignedTo
  class Patient { ... }
  class Doctor { ... }
}
class Prescription {
  +date prescriptionDate
  -string medicationName
  Patient -- "0..n" > Prescription : issuedFor
  class Patient { ... }
  class Prescription { ... }
}
class MedicalRecord {
  +date recordDate
  -string diagnosis
  Patient -- "0..n" > MedicalRecord : hasRecord
  class Patient { ... }
  class MedicalRecord { ... }
}
```