```mermaid
classDiagram
    class Patient {
        +string name
        +int id
        -date dob
        #list~Prescription~ prescriptions
        -MedicalRecord record
    }
    class Doctor {
        +string name
        +int id
        -list~Appointment~ appointments
    }
    class Appointment {
        +Patient patient
        +Doctor doctor
        +datetime date
    }
    class Prescription {
        +string drugName
        +int dosage
        -Patient patient
    }
    class MedicalRecord {
        +List~Diagnosis~ diagnoses
        *Patient patient
    }
    Patient *-- Appointment : has
    Doctor *-- Appointment : sees
    Appointment --> Prescription : prescribes
    Patient o-- MedicalRecord : owns
```