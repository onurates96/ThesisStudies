```mermaid
classDiagram
    class User {
        +name: string
        +email: string
        +password: string
        -age: int
        -gender: string
        -isMammal(): bool
        -mate(): void
    }
    class Booking {
        +id: int
        +userId: int
        +serviceId: int
        +paymentId: int
        +status: string
    }
    class Payment {
        +id: int
        +bookingId: int
        +amount: decimal
    }
    class Service {
        +id: int
        +name: string
        -price: decimal
    }
    class Location {
        +id: int
        +name: string
        +address: string
    }
class Relationship {
    class User:
        --> Booking : + bookingId: int
        --> Payment: + id: int
        --> Service: + id: int
}
```