```mermaid
classDiagram
    class User {
        +string name
        +string email
        -string password
    }
    class Booking {
        -User user
        +string bookingDate
        +string bookingTime
        +decimal amountPaid
    }
    class Payment {
        +string paymentMethod
        +string paymentStatus
    }
    class Service {
        +string serviceName
        +decimal serviceCost
    }
    class Location {
        +string locationName
        +string locationAddress
    }
    User --> Booking : makes
    Booking --> Payment : requires
    Service *-- Location : provided
    User "1" <-- "*" Booking : has many bookings
    Booking "1" <-- "0..*" Payment : has multiple payments
```