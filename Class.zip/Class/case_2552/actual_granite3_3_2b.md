```mermaid
classDiagram
    class User {
        +string name
        +string email
        +Password password
        +List<Booking> bookings
        +Payment payment
    }

    class Booking {
        +int id
        +Date date
        +Location location
        +Service service
        +User user
    }

    class Payment {
        +int amount
        +Date date
        +Transaction transaction
    }

    class Service {
        +string name
        +Description description
        +Price price
    }

    class Location {
        +string address
        +City city
        +Country country
    }

    User "1" "--* Booking : uses
    User "1" "--* Payment : charges
    Booking "1" "0..1" Service : provides
    Service "1" "..* Booking : offers
    Location "1" "0.." Booking "1" : located_in
    Payment "1" "1..*" Booking : processes
```