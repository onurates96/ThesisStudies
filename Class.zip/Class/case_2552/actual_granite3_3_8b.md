```mermaid
classDiagram
    class User {
        +string username
        +string password
        -List~string~ bookedServices
        +Book createBooking() : Booking
        +Payment makePayment(Booking booking) : Payment
    }
    class Booking {
        +User user
        +Service service
        +Location location
        +DateTime date
        +Payment payment
        +boolean confirmed
        +boolean completed
        -User host
    }
    class Payment {
        +Booking booking
        +decimal amount
        +string transactionId
    }
    class Service {
        +string name
        +string description
        +Location location
        +float price
        -List~Service~ subServices
    }
    class Location {
        +string address
        +string city
        +string country
        -List~Service~ services
    }
```