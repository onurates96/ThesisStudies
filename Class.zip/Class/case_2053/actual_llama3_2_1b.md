```mermaid
graph LR;
    classCustomer[Customer] {
        +name string
        +age int
        +email string
    }
    classOrder[Order] {
        +id int
        +customer_id int
        +order_date date
        +total float
    }
    classProduct[Product] {
        +id int
        +name string
        +price float
    }
    classCustomerOrder[Customer-Order] {
        +id int
        +customer_id int
        +order_id int
        +status string
    }
    classSalesPerson[SalesPerson] {
        +id int
        +name string
        +email string
    }
    classProductManager[Product Manager] {
        +id int
        +name string
        +email string
    }
    classDepartment[Department] {
        +id int
        +name string
        +description string
    }
    classCustomerDepartment[Customer-Department] {
        +id int
        +customer_id int
        +department_id int
    }
    Customer -->+--> Order [Order Customer]
    Student -->+--> Course [Course Student]
    Galaxy -->+--> Star [Star Galaxy]
    SalesPerson -->+--> ProductManager [ProductManager SalesPerson]
```