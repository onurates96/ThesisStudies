%% Use Case Diagram for Online Shopping Platform
classDiagram
  class Customer {
    +browseProducts()
    +addToCart()
    +checkout()
  }
  class Admin {
    +manageInventory()
    +manageOrders()
  }
  class UseCase {}
  Customer --> UseCase : "Browse Products"
  Customer --> UseCase : "Add to Cart"
  Customer --> UseCase : "Checkout"
  Admin --> UseCase : "Manage Inventory"
  Admin --> UseCase : "Manage Orders"
  UseCase :