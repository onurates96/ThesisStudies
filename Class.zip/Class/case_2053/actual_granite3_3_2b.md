```mermaid
classDiagram
    class Customer {
        +id
        +name
        +email
        +password
        +browseProducts()
        +addToCart()
        +placeOrder()
    }
    class Admin {
        +id
        +name
        +email
        +password
        +manageInventory()
        +addProduct()
        +removeProduct()
    }
    Customer "1" -- "*" Ticket : browses
    Customer "1" -- "*" Cart : adds to
    Admin "1" -- "*" Inventory : manages
```