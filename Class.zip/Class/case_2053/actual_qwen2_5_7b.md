```mermaid
classDiagram
    class Actor {
        -name: string
    }
    class UseCase {
        +title: string
        +description: string
    }
    Admin <|-- Customer
    Admin ..> BrowseProducts
    Admin ..> AddToCart
    Admin ..> ManageInventory
    Customer --> BrowseProducts : can use
    Customer --> AddToCart : can use
    Admin --> ManageInventory : manages
```