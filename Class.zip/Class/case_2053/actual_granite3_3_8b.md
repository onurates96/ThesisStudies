```mermaid
classDiagram
    class Customer
    class Admin
    class Product
    class Cart
    class Inventory

    Customer --> Product : Browse Products
    Customer --> Cart : Add to Cart
    Admin --> Inventory : Manage Inventory
```