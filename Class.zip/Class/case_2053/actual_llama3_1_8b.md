```mermaid
classDiagram
class Customer {
    +string name
    +login() bool
}
Customer "..> " Order : dependency
Order "-->" Product : association
class Admin {
    +deleteProduct(Product) void
    +updateInventory(Inventory) void
}
Admin "..|> " Inventory : realization
Product "1" --> "*" Order : contains
class Ticket {
    -int id
    +string title
    +assignCustomer(Customer) void
}
```