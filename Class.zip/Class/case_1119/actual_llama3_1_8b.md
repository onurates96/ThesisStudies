```mermaid
classDiagram
    class Book {
        +string title
        +string author
        -bool isAvailable
    }
    class Member {
        +string name
        +string email
        -bool isBlocked
    }
    class Librarian {
        +string name
        +string email
        -bool isAdmin
    }
    class Library {
        +string address
        +string phone
        -bool isOpened
    }
    class Transaction {
        -Book borrowedBook
        -Member borrower
        -Library lendingLibrary
    }
    Member --> Book : borrows
    Librarian --> Library : manages
    Transaction --> Book : records Borrowing
```