```mermaid
classDiagram
    class Book {
        +string title
        +string author
        -int yearPublished
        +borrow() void
    }
    class Member {
        +string name
        +string membershipType
        *Book "0..*" borrowedBooks : borrows
        +returnBook(book:Book) void
    }
    class Librarian {
        +string name
        oLibrary "1" -- "1" Library : manages
        +addBook(book:Book) void
        +removeBook(book:Book) void
    }
    class Library {
        +string location
        *Librarian "0..1" -- "1" Librarian : has
        *Member "0..*" -- "0..*" Members : belongsTo
    }
    class Transaction {
        +string type
        "1" --> "0..*" Member : records
        "1" --> "0..*" Book : records
    }
```