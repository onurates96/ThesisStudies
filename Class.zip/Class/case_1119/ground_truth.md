classDiagram
  Class Book{
    +title : string
    +author : string
    +ISBN : string
  }
  Class Member{
    +name : string
    +id : int
  }
  Class Librarian{
    +name : string
    +id : int
  }
  Class Library{
    +name : string
    +address : string
  }
  Class Transaction{
    +date : Date
    +member : Member
    +book : Book
  }
  Book -- Member : borrows
  Library -- Librarian : manages
  Transaction -- Book : records