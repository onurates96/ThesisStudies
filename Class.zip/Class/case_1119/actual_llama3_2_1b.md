classDiagram
    Book "0" --> "1..* Member"
    Member : +string name ~+String login() bool ~+isMember() bool
    Librarian : +string name ~+boolean isManager() bool
    Library : +string address ~+boolean isOpen()
    Transaction : +date ~+type ~+status:~+TransactionType ~+amount:~+TransactionDetails
classDuck{
        +string beakColor
        +quack() void
}
classFish{
        -int sizeInFeet
        -canEat() bool
}
classZebra{
    +bool is_wild
    +run() void
}