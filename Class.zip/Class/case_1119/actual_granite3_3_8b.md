```mermaid
classDiagram
    class Book{
        +string title
        +string author
        +int yearOfPublication
        -boolean isAvailable
    }
    class Member{
        +string name
        +string idCard
        +Book *--> "borrows"
    }
    class Librarian{
        +string name
        +string idCard
        +Library manage : "manages"
    }
    class Library{
        +string address
        +Librarian *--> "employs"
        +Book "contains"
    }
    class Transaction{
        +DateTime timestamp
        +Member borrower
        +Book book
        +boolean isOverdue
    }
```