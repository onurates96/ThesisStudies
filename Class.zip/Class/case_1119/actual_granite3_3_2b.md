```mermaid
classDiagram
    classBook {
        +string title
        +string author
        +int publicationYear
        +boolean isAvailable
    }
    classMember {
        +string name
        +string membershipId
        +Book[] borrowedBooks
    }
    classLibrarian {
        +string name
        +Library library
    }
    classLibrary {
        +string name
        +Librarian librarian
        +Book[] books
    }
    classTransaction {
        +Date timestamp
        +Member member
        +Book book
        +Status status : "Pending", "Approved", "Rejected"
    }
    Book --> Member : borrows
    Librarian *-- Library : manages
    Transaction : records Borrowing -> Member
```