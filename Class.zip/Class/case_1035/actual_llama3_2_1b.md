```mermaid
classDiagram
    class Account {
        +string accountNumber;
        +decimal balance;
        -isActive() bool;
        +deposit(amount:decimal) void;
        +withdrawal(amount:decimal) void;
    }
    
    class Customer {
        +string customerName;
        -age int;
        -gender string;
        +isActive() bool;
        +getBalance(): decimal -> Account
        +getTransactions(): list[Account] -> Transaction
    }
    
    class Transaction {
        +date datetime;
        +amount: decimal;
        +type: string;
        +customer: Customer;
    }
    
    class Bank {
        +string bankName;
        -location: address;
        +isActive() bool;
    }
    
    class CustomerAccount : Account {
        +Bank account:B
    }
    
    class StudentAccount : Account {
        +Student student:B
    }
```