```mermaid
classDiagram
  Account (Account) <|-- Transaction(Account, Amount)
  Customer (Customer) ->* (Transaction(Customer, Amount))
  Bank (Bank) <|-- Account
  Customer (Customer) : +string accountNumber
  Account (Account) : +string customerID
  Account (Account) : *+customerID
  Account (Account) : -string accountNumber
  Customer (Customer) : +string name
  Customer (Customer) : -int age
  Customer (Customer) : +string gender
  Transaction(Account, Amount) : +amount

  Transaction(Account, Amount) ->* (Transaction(Customer, Amount))
  Transaction(Customer, Amount) ->* (Transaction(Manager, Amount))
  Transaction(Account, Amount) ->+ (Transaction(Account, -Amount))
  Transaction(Account, Amount) ->- (Account)
  Account ->* (Transaction(Account, +Amount))
  Bank (Bank) : +string bankName
  Customer (Customer) : +string customerID1
  Customer (Customer) : +int customerAge1
  Customer (Customer) : -string name1
  Customer (Customer) : +int age1

  Customer (Customer) : +string name2
  Account (Account) : *+name2
  Bank (Bank) <|-- Customer(Customer, Bank)
```

This Mermaid code generates a valid class diagram for the provided banking system. The classes are defined using standard Python notation, and relationships between them are depicted with appropriate connectors.