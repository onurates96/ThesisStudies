```mermaid
classDiagram
    class Account {
        +string accountNumber
        +decimal balance
        +deposit(amount: decimal) void
        +withdrawal(amount: decimal) void
    }
    class Transaction {
        +decimal amount
        +type: string (deposit/withdrawal)
        +account: Account ref
    }
    class Customer {
        +string name
        +Account[] accounts
    }
    class Bank {
        +string name
        +Customer[] customers
    }

    Account "1" --> * Transaction : uses
    Customer "1" "1.." Account : has
```