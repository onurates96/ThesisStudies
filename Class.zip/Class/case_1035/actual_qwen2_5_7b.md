```mermaid
classDiagram
    class Bank {
        +string name
        +list~Account~ accounts
    }
    class Account {
        -string accountNumber
        -decimal balance
        +deposit(amount: decimal) void
        +withdraw(amount: decimal) void
    }
    class Customer {
        -string firstName
        -string lastName
        -list~Account~ ownedAccounts
    }
    class Transaction {
        -datetime date
        -decimal amount
        -Account account
        +execute() void
    }
    Bank *-- Account : owns
    Customer *-- Account : owns
    Account --|> Transaction : includes
```