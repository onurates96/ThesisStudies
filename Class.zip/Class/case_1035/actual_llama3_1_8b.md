```mermaid
classDiagram
class Account {
    +string accountNumber
    +decimal balance
    +Customer owner
}

class Transaction {
    +decimal amount
    +string description
    -- Account sourceAccount
    -- Account destinationAccount
}

class Customer {
    +string name
    +string address
    ~int age~
}

class Bank {
    -list<Account> accounts
    -list<Transaction> transactions
}

Customer "1" --> "*" Account : hasAccount
Bank "0..1" --> "*1" Account : ownsAccount
Transaction "--" * Account : isRelatedTo
```