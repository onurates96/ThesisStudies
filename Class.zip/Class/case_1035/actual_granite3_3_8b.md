```mermaid
classDiagram
    class Customer {
        +string name
        +string address
        +int customerId
        -List~Account~ accounts
        +addAccount(account:Account) void
        +removeAccount(account:Account) void
    }
    class Account {
        +string accountNumber
        +decimal balance
        +Customer owner
        +deposit(amount:decimal) void
        +withdrawal(amount:decimal) void
    }
    class Transaction {
        +TransactionId
        +Account fromAccount
        +Account toAccount
        +decimal amount
        +timestamp
        -create()
    }
    class Bank {
        +List~Account~ accounts
        +addAccount(account:Account) void
        +removeAccount(account:Account) void
        +processTransaction(transaction:Transaction) void
    }
    Customer "1" --> "*" Account : has
    Customer "1" --> "0..*" Transaction : initiates
    Account "1" --> "0..*" Transaction : involved_in
    Bank "1" --> "0..*" Account : manages
```