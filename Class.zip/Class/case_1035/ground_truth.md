classDiagram
  class Account {
    - accountNumber
    - balance
    + deposit(amount)
    + withdraw(amount)
  }
  class Transaction {
    - transactionId
    - date
    + processTransaction()
  }
  class Customer {
    - customerId
    - name
    + login()
    + logout()
  }
  class Bank {
    - bankId
    - name
    + createAccount()
    + closeAccount()
  }
  Account -- Transaction
  Account -- Customer
  Customer -- Bank