```mermaid
classDiagram
    class Book {
        +title
        +isbn
        +author
        
        +inStock(boolean) default true
        
        +price(decimal)
        
        +available(int, boolean) default true
        
        +borrowed(bool, int, time interval) default 0
        
        +returnDate(time interval, bool) default false
        
    }
    
    class Customer {
        +id
        +name
        
        +email
        
        +address
        
        +orders()
        
        +buyBook(Book)
        
        +makePayment(Payment)
    }
    
    class Order {
        +id
        +customer_id(int, Customer)
        +book_id(int, Book)
        
        +total(decimal)
        
        +status(bool) default false
        
        +dueDate(time interval, bool) default true
        
        +cancel()
        
    }
    
    class Payment {
        +id
        +order_id(int, Order)
        +amount(decimal)
        
        +paymentMethod(string)
        
        +created_at(time)
        
        +cancelledAt(time)
    }
```