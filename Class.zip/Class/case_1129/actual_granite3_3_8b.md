```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +int pages
        +bool isAvailable
        -Inventory inventory
        -List~Order~ orders
    }
    class Customer {
        +string name
        +string email
        -List~Book~ borrowedBooks
    }
    class Order {
        +int orderID
        +Customer customer
        *--"1" Payment payment
        -->"1" Book book
    }
    class Payment {
        +string method
        +decimal amount
        -Order order
    }
    class Inventory {
        +List~Book~ books
        -Book addBook(book: Book) : boolean
        -Book removeBook(book: Book) : boolean
    }
```