```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +int yearPublished
        +int quantityInStock
        +Inventory inventory
    }
    class Customer {
        +string name
        +string email
        +BookOrder order
    }
    class Order {
        +string orderNumber
        +Customer customer
        +Payment payment
        + list<Book> books
    }
    class Payment {
        +string cardNumber
        +string expiry
        +string cvv
        +bool isApproved
    }
    class Inventory {
        +int stockLevel
        +Book book
    }

    Book "1" "1.." Order : uses
    Customer "1" "1..*" Order : places
    Order "1" "1.." Payment : needs
    Payment "1" "1.." Order : approves
    Order "1" "1.." Book : contains
```