```mermaid
classDiagram
class Book {
    +string title
    +string author
}
class Customer {
    +string name
    -string email
}
class Order {
    +Customer customer
    +Book book
}
class Payment {
    +Order order
    -decimal amount
}
class Inventory {
    +Book[] books
}

Book ..> Order : payment_required
Order "1" *-- Payment : multiple_payments_allowed
Customer "0..n" --> "*" Order : many_orders_per_customer
Inventory o-- Book : inventory_contains_books
```