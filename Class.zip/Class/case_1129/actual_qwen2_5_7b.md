```mermaid
classDiagram
    class Book {
        +string title
        +string author
        -int isbn
        +bool available
    }
    class Customer {
        +string name
        +string address
        -List~Book~ borrowedBooks
    }
    class Order {
        +Date orderDate
        +decimal totalAmount
        *Customer customer
        o-- Inventory inventory
    }
    class Payment {
        +string paymentMethod
        +decimal amount
        --> Order order
    }
    class Inventory {
        -List~Book~ stockBooks
        *Order order
    }
    Book --|> Inventory : contains
    Customer "1" --> "0..*" Order : places
    Order *-- Payment : includes
```