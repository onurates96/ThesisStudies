```mermaid
classDiagram
    Customer "0.." "1" --> "*" "0.." "2" --> "*" "Customer 0.." (Customer 1)
    Customer "0.." "1" *-- "*" "0.." "2" --> "*" "Customer 0.." (Customer 2)
    Customer "0.." "1" *-- "*" "0.." "2" --> "*" "Customer 0.." (Customer 3)
    Customer "0.." "1" -- "*" "0.." "2" --> "*" "Customer 0.." (Customer 4)
```