classDiagram
  Class Book{
    +title: string
    +author: string
    +price: float
  }
  Class Customer{
    +name: string
    +address: string
  }
  Class Order{
    +orderId: int
    +orderDate: date
  }
  Class Payment{
    +paymentId: int
    +amount: float
  }
  Class Inventory{
    +quantity: int
  }
  Book --> Order
  Customer --> Order
  Order --> Payment
  Order --> Inventory