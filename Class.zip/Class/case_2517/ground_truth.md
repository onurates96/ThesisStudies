classDiagram
    class Student {
        +int StudentID
        string Name
        string Major
        string Email
        Date EnrollmentDate
    }
    class Course {
        +int CourseID
        string Title
        string Code
        int Credits
    }
    class Instructor {
        +int InstructorID
        string Name
        string Department
        string Email
    }
    class Department {
        +int DepartmentID
        string Name
        string Location
    }
    class Enrollment {
        +int EnrollmentID
        int StudentID
        int CourseID
        Date EnrollmentDate
        double Grade
    }
    Student --> Enrollment : enrolls_in
    Course --> Enrollment : has_enrollments
    Instructor --> Course : teaches
    Department --> Instructor : employs