```mermaid
classDiagram
    class Student {
        +int id: primary key
        +string name
        +integer age
        +boolean gender
        
        Association "enrollment"
            class Enrollment 
                -Student student: references Student(id)
                -Course course: references Course(name)
            end
        
        ClassA : mate() void
    }
    
    class Course {
        +string name
        +int sizeInFeet: null
        
        Association *-- Student student:
            -Student student: references Student(id)
            
        Association o-- Instructor instructor: references Instructor(teacher)
        
        Association o-- Student student:
            -Student student: references Student(id)
    
    }
    class Department {
        +string name
        +integer id: primary key
        
        Association *-- Course course: references Course(name)
        ClassA : department: references Department(id) 
    }
    
classStudent
    Student : enrollment : +Customer customer: references Customer(customer_id)
    classCourse
        Course : student : references Student(student_id) : +course: references Course(name) : +isFavorite() bool
    classEnrollment
        classCourse : student : references Student(student_id) : references Course(course_id): references Student(id): references Department(department_id):
            ->+Course
classInstructor
    Instructor : teacher: references Teacher(teacher_id)
    classStudent
        Student : instructor : references Instructor(instructor_id): references Student(student_id): references Department(department_id): references Course(course_id)
```