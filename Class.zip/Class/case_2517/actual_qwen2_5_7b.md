```mermaid
classDiagram
    class Department {
        +string name
        +List~Instructor~ instructors
    }
    class Instructor {
        -string name
        -string subjectArea
        +teach(course:Course) void
    }
    class Course {
        +string title
        +Department department
        +List~Student~ students "1..*"
    }
    class Student {
        +string name
        +string major
        +enroll(enrollment:Enrollment) void
    }
    class Enrollment {
        -Date startDate
        -Date endDate
        +register(student:Student, course:Course) void
    }
    Department *-- Instructor : has
    Course --> Student : offers "0..*"
    Student --o Enrollment : is enrolled in
```