```mermaid
classDiagram
    student [1] "<-- course: enrolls
    instructor [1] "1" *-- department: belonging to
    department [1] "1.." *-- course: offers
    course [1] "1..*" enrollment: has
    Enrollment [1] "1" *-- student: enrolled
    Enrollment [1] "1" o-- course: enrolledIn
```