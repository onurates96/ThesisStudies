```mermaid
classDiagram
    class University {
        +string name
        +string address
    }
    class Department {
        -University university
        +string name
        +string description
    }
    class Instructor {
        -Department department
        +string name
        +string email
    }
    class Student {
        -Department department
        +string name
        +string email
    }
    class Course {
        -Department department
        +string code
        +string title
    }
    class Enrollment {
        -Student student
        -Course course
        +datetime enrollmentDate
    }
    University --> Department : belongs_to
    Department "1" *-- "*" Instructor : teaches
    Student "1" *-- "*" Course : enrolled_in
    Course -- Enrollment : offered_by
```