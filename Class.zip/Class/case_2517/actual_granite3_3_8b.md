```mermaid
classDiagram
    class Student {
        +string name
        +int studentID
        -List~Course~ enrolledCourses
        +enroll(course:Course) void
        +dropCourse(course:Course) void
    }
    class Course {
        +string courseID
        +string title
        +Instructor instructor
        +List~Student~ studentsEnrolled
        +addStudent(student:Student) void
        +removeStudent(student:Student) void
    }
    class Instructor {
        +string name
        +string subject
        -List~Course~ coursesTaught
        +assignGrade(course:Course, student:Student, grade:int) void
    }
    class Department {
        +string deptName
        +List~Course~ offeredCourses
        +addCourse(course:Course) void
        +removeCourse(course:Course) void
    }
    class Enrollment {
        +Student enrolledStudent
        +Course course
        +Grade gradeReceived
        +Enrollment()
    }

    Student "1" --> "*" Enrollment : enrolls
    Course "1" --> "*" Enrollment : hasEnrollments
    Instructor "1" --> "1..*" Course : teaches
    Department "1" --> "1.." Course : offers
```