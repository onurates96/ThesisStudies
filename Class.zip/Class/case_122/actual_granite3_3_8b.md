```mermaid
classDiagram
    class Customer {
        +string name
        +string email
        +string address
        -List~Order~ orders
    }
    class Product {
        +string name
        +decimal price
        +string description
        -List~Order~ orders
    }
    class Order {
        +int orderID
        +string customerName
        +List~Product~ products
        +Payment payment
        +Shipping shippingDetails
    }
    class Payment {
        +string paymentID
        +decimal amount
        +string paymentMethod
    }
    class Shipping {
        +string trackingNumber
        +string shippingAddress
    }
    Customer "1" --> "*" Order : placing
    Product --> Order : includes
    Order <|-- Payment : processes
    Order <|-- Shipping : ships
```