```mermaid
classDiagram
    class Customer {
        +string name
        +List<Product> shoppingCart
        +Order currentOrder
        +Payment payment
        +Shipping shipping
    }
    class Product {
        +string name
        +double price
        +Category category
    }
    class Order {
        +List<Product> items
        +Customer customer
        +Date orderDate
        +Status status
    }
    class Payment {
        +Customer customer
        +List<Payment> transactions
        +Status status
    }
    class Shipping {
        +Order order
        +Carrier carrier
        +TrackingNumber trackingNumber
    }

    Customer "1" --> "*" Order : places
    Customer "1" "1" -- "*" Payment : pays
    Customer "1" "1" -- "*" Shipping : ships
    Product *-- "*Order" : addedTo
    Order *-- "*Payment" : pays
    Order *-- "*Shipping" : ships
    Payment *-- "*" Transaction : processes
```