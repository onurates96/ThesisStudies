```mermaid
classDiagram
    class Customer {
        +string name
        -int id
        +order() Order
    }
    class Product {
        +string name
        -decimal price
        +description() string
    }
    class Order {
        +OrderNumber() string
        -Customer customer
        -Product product
        -Payment payment
        -Shipping shipping
    }
    class Payment {
        +type() string
        -amount() decimal
    }
    class Shipping {
        +method() string
        -cost() decimal
    }

    Customer "1" --> "*" Order : One customer can have multiple orders
    Product "1" *-- Order : An order contains one product
    Order o-- Payment : One payment for each order
    Order o-- Shipping : One shipping for each order
```