```mermaid
classDiagram
    class Customer {
        +name string
        +email string
        +order integer: [id]
        +paymentMethodType string
        +shippingAddress string
        -address(integer): [street, city, state)
        +phone string
    }
    
    class Order {
        +customerId integer: [id]
        +productIds List[int]: [product_id]
        +quantity int
        +total decimal: [0.00]
        +paymentMethodType string
        -address(integer): [street, city, state)
        +phone string
    }
    
    class Product {
        +name string
        +description text
        +price decimal: [0.00]
        +quantityInStock int: [0..100]
        +category string
        -image URL: [required]
    }
    
    class Payment {
        +methodType string
        +amount decimal: [0.00]
        -address(integer): [street, city, state)
        +phone string
    }
```