classDiagram;
  class Customer {
    +customerId: String
    +name: String
    +email: String
  }
  class Product {
    +productId: String
    +name: String
    +price: Float
  }
  class Order {
    +orderId: String
    +customerId: String
    +productId: String
    +quantity: Int
    +orderDate: Date
  }
  class Payment {
    +paymentId: String
    +orderId: String
    +amount: Float
    +paymentDate: Date
  }
  class Shipping {
    +shippingId: String
    +orderId: String
    +address: String
    +shippingDate: Date
  }
  Customer "1" -- "*" Order: places;
  Product "1" -- "*" Order: includes;
  Order "1" -- "*" Payment: hasPayments;
  Order "1" -- "*" Shipping: hasShipments;