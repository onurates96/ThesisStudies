```mermaid
classDiagram
    class Customer {
        -name: string
        -email: string
        +login(): bool
        +placeOrder(): Order
    }
    class Product {
        +id: int
        +name: string
        +price: decimal
        o-- OrderItem : Aggregation
    }
    class Order {
        "1" --> "*": OrderItem : Contains
        -customerId: int
        +addProduct(product: Product): void
        +placePayment(payment: Payment): bool
    }
    class Payment {
        +amount: decimal
        +method: string
        ..> Customer : Dependency
    }
    class Shipping {
        -order: Order
        +calculateShippingCost(): decimal
        +shipOrder(): bool
    }
```