```mermaid
classDiagram
    class User {
        +string id
        +string name
        +addPlaylist(playlistName: string) void
    }
    class Playlist {
        +string id
        +string name
        -User user
        --Song[] songs
    }
    class Song {
        +string id
        +string title
        +Artist artist
    }
    class Artist {
        +string id
        +string name
        -Song[] songs
    }
    class Subscription {
        +string id
        +User user
        --Playlist[] playlists
    }

    User --> "1" Playlist : has
    Playlist ..> Subscription : dependentOn
    Song <-- Artist : belongsTo
    Subscription <-- User : subscribedTo
```

This diagram represents a music streaming service with classes for `User`, `Playlist`, `Song`, `Artist`, and `Subscription`. The relationships between these classes include the user having playlists, playlists being dependent on subscriptions, songs belonging to artists, and subscriptions being related to users.