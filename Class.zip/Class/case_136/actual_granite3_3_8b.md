```mermaid
classDiagram
    class User {
        +string username
        +string passwordHash
        +List~String~ playlists
        +Subscription subscription
    }
    class Playlist {
        -User owner
        +String title
        *Song[] songs
    }
    class Song {
        +String title
        +Artist artist
        +Duration duration
    }
    class Artist {
        +String name
        +List~String~ albums
        +List~String~ genres
    }
    class Subscription {
        +SubscriptionType type
        +String paymentMethod
        +DateTime expirationDate
    }
    User "1" --> "0..*" Playlist : owns
    Playlist *-- Song : contains
    Song --> Artist : belongsTo
    Artist "1" --> "*" Song : has
```