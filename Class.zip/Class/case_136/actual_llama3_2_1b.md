```mermaid
classDiagram
    class User { 
        +string name: 
        +bool isSubscriber: bool
        - Song[] playlist
        + Playlist() void
        + connect(Playlist)
    }
    class Playlist {
        +string name: 
        +Song[] songs
        + connect(Song) : belongsToPlaylist
        + connect(User)
    }
    class Song { 
        +string title: 
        - int lengthInMinutes
        + bool isFavorited: bool
        + void play() void
    }
    class Artist {
        +string name: 
        +bool isAlive: bool
        - Music[] albums
        + connect(Music) : containsAlbum
    }
    class Music { 
        +string title: 
        - int durationInMinutes
        + bool isFavorite: bool
        + void addSong(Song())
    }
```