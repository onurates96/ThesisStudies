classDiagram;
  class User {
    +userId: String
    +username: String
    +email: String
  }
  class Playlist {
    +playlistId: String
    +userId: String
    +name: String
  }
  class Song {
    +songId: String
    +title: String
    +artistId: String
    +duration: Int
  }
  class Artist {
    +artistId: String
    +name: String
    +genre: String
  }
  class Subscription {
    +subscriptionId: String
    +userId: String
    +plan: String
    +expiryDate: Date
  }
  User "1" -- "*" Playlist: creates;
  Playlist "1" -- "*" Song: contains;
  Song "1" -- "1" Artist: performedBy;
  User "1" -- "1" Subscription: has;