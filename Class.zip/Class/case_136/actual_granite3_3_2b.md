```mermaid
classDiagram
    class User {
        +string name
        +string email
        +string password
        +string password_confirmation
        +int age
        +string gender
        +Subscription subscription
        +List<Playlist> userPlaylists
        +Set<Song> songLibrary
    }

    class Playlist {
        +string name
        +List<Song> songs
        +Artist playlistArtist
    }

    class Song {
        +string title
        +Artist artist
        +List<Subscription> subscriptions_owned
    }

    class Artist {
        +string name
        +List<Song> songs
        +List<Playlist> playlists
    }

    class Subscription {
        +string plan
        +string start_date
        +string end_date
    }

    User "1" "--* Playlist: userPlaylists
    User "1" "--* Song: songLibrary
    Artist "1" "0..1 Playlist: playlists
    Subscription "1" "--* Subscription
```