```mermaid
classDiagram
    class User {
        +string name
        +string email
        -list~Playlist~ playlists
        +addPlaylist(playlist:Playlist) void
        +removePlaylist(playlist:Playlist) void
    }
    class Playlist {
        +string title
        *User owner
        +addSong(song:Song) void
        +removeSong(song:Song) void
        o-- Song songs
    }
    class Song {
        +string title
        +string artistName
        +int durationInSeconds
    }
    class Artist {
        +string name
        +list~Song~ songs
    }
    class Subscription {
        +string plan
        +bool is_active
        "1" -- "*" User : has
    }
```