```mermaid
classDiagram
    Room : +int number : guest : +guestInfo() void
    Guest : +string name : +int id
    Payment : -amount: decimal
    Staff : +string name : +isManager(bool) bool, +department(string), +employeeId(int)
    classA -->| inheritance | classB : Inheritance
    classC *--| composition| classD : Composition
    classE o--| aggregation| classF : Aggregation
    classG -->| association| classH : Association
    classI ..>| link| classJ : Link(Solid)
    classK ..>| dependency| classL : Dependency
    classM ..| realisation| classN : Realization
    classO .. classP : Link(Dashed)
```