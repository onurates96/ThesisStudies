```mermaid
classDiagram    
    class Room {
        +string roomNumber
        -decimal pricePerNight
        +Room() 
        +makeReservation(Guest) void
    }
    class Guest {
        +string name
        -string contactInformation
        +Guest()
        +login() bool
    }
    class Reservation {
        +int reservationID
        +Reservation(Room, Guest)
        +cancel() void
    }
    class Payment {
        +decimal amountPaid
        +Payment()
        +payForReservation(Reservation) void
    }
    class Staff {
        +string name
        -string role
        +Staff()
        +assignRoom(Room) void
    }
    Room <|-- Reservation : A reservation is created for a room
    Guest *-- Reservation : A guest can have multiple reservations
    Payment o-- Reservation : A payment is associated with one reservation
    Staff --> Room : Staff assigns rooms to guests
```