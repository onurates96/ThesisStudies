classDiagram
    class Room {
        +int RoomNumber
        string Type
        double Rate
        string Status
    }
    class Guest {
        +int GuestID
        string Name
        string Address
    }
    class Reservation {
        +int ReservationID
        int GuestID
        int RoomNumber
        Date CheckInDate
        Date CheckOutDate
        double TotalCost
        string Status
    }
    class Payment {
        +int PaymentID
        int ReservationID
        Date PaymentDate
        double Amount
        string Method
    }
    class Staff {
        +int StaffID
        string Name
        string Department
    }
    Guest --> Reservation : makes
    Room --> Reservation : reserved
    Reservation --> Payment : pays
    Staff --> Reservation : manages