```mermaid
classDiagram
    class Room {
        -id: int
        -type: string
        +getAvailability(date: date) bool
    }
    class Guest {
        -name: string
        -email: string
        +reserveRoom(room: Room, date: date) void
    }
    class Reservation {
        +reservationId: int
        +checkInDate: date
        +checkOutDate: date
        +guest: Guest
        +room: Room
        -- guest *-- Reservation
        -- room *-- Reservation
    }
    class Payment {
        -paymentId: int
        -amount: decimal
        -method: string
        +processPayment(reservation: Reservation) void
    }
    class Staff {
        -staffId: int
        -role: string
        +manageReservation(reservation: Reservation) void
    }
    Guest --> Reservation : reserves
    Room *-- Reservation : has
    Payment <|-- Reservation : includes
    Staff o-- Reservation : manages
```