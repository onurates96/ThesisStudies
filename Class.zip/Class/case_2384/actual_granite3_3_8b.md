```mermaid
classDiagram
    class Room{
        +int roomNumber
        +string roomType
        +bool isAvailable
    }
    class Guest{
        +string name
        +string contactInfo
        -List~string~ reservationHistory
    }
    class Reservation{
        +Guest guest
        +Room room
        +DateTime checkIn
        +DateTime checkOut
        +Payment payment
    }
    class Payment{
        +Guest guest
        +amount decimal
        +paymentDate DateTime
    }
    class Staff{
        +string name
        +List~string~ roles
        -List~Reservation~ managedReservations
    }
    Room <|-- "1" Reservation : booked
    Guest "1" --> "*" Reservation : makes
    Reservation "1" -- "1" Payment : has
    Staff "1" <-- "* Reservation : manages
```