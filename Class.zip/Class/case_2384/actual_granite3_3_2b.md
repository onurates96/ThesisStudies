```mermaid
classDiagram
    subclass {Room}
    subclass {Guest}
    subclass {Reservation}
    subclass {Payment}
    subclass {Staff}

    Room --> Staff : uses
    Guest *-- Reservation : booked
    Payment *-- Reservation : paid
    Staff *-- Reservation : manages
    Reservation *-- BookingDetails : contains
    Room *-- Amenity : has
    Amenity *-- Room : provided by
    Guest *-- Profile : has
    Payment *-- Transaction : generates
    Transaction *-- BankAccount : deposits
    Staff *-- Shift : works
    Reservation *-- CheckIn : records
    CheckIn *-- Stay : begins
    CheckOut *-- CheckIn : ends
    Reservation *-- Rating : receives
    Guest *-- Review : writes
    Payment *-- Refund : issues
```