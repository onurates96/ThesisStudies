```mermaid
classDiagram
    class Customer {
        +string name
        +string email
        -string address
        +list carPurchases
        +int purchaseCount() int
    }
    class Car {
        +string make
        +string model
        +int year
        -boolean isSold
    }
    class Salesperson {
        +string name
        +string idNumber
        -list assignedCustomers
    }
    class Inventory {
        +List~Car~ availableCars
        +addCar(car:Car) void
        +removeCar(car:Car) void
    }
    class Transaction {
        +string transactionId
        +Customer buyer
        +Car soldCar
        +Salesperson salesperson
        +dateTime dateTime
        -boolean isCompleted
    }

Customer "1" --> "*" Transaction : purchases
Car *-- "1" Inventory : managedByInventory
Salesperson o-- "*" Customer : managesCustomers
Transaction --> Car : recordsSoldCar
Transaction --> Salesperson : assignedToSalesperson
```