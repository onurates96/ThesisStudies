```mermaid
classDiagram
class Vehicle {
    +int id
    -string name
    -bool isElectric
    class Car {
        +int id
        -string color
        -bool isStocked
        class Inventory {
            +List~Vehicle[]>
        }
    }
    class Truck {
        +int id
        -string size
        -bool isStocked
    }
}
class Customer {
    +int id
    -string name
    -bool hasPurchased
    class Vehicle {
        +int id
        -string color
        -bool isStocked
        +function purchase(Vehicle vehicle:Vehicle): bool
            return vehicle.isElectric || vehicle.name == "Tesla"
        }
    }
}
class Salesperson {
    +int id
    -string name
    -bool hasPurchased
}
class Inventory {
    +List~Vehicle[]>
}
```