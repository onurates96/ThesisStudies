```mermaid
classDiagram
    class Customer {
        -name: string
        +purchase(car: Car, salesperson: Salesperson) Transaction
    }
    class Car {
        +model: string
        +year: int
        *-- Inventory
    }
    class Salesperson {
        -name: string
        +assign(customer: Customer) void
    }
    class Inventory {
        *-- Car
        +manageStock() void
    }
    class Transaction {
        +date: Date
        +amount: decimal
    }
    Customer --> "1" Transaction : makes
    Salesperson <|-- "1" Customer : serves
    Car *-- "0..*" Inventory : in
    Salesperson --. "1" Inventory : manages
```