```mermaid
classDiagram
    class Customer {
        +string name
        +string email
        +date birthDate
        +address homeAddress
        +PhoneNumber contactNumber
        ++int number_of_cars
        +purchase(car:Car)
    }
    class Car {
        +string make
        +string model
        +year manufactured
        +string color
        ++float price
        +inventory *-- Inventory
    }
    class Salesperson {
        +string name
        +string contactNumber
        +Department department
        +Car[] recommendedCars
        +Sale[] completedSales
    }
    class Department {
        +string name
        +Salesperson[] members
    }
    class Inventory {
        +string location
        +Car[] cars
        ++int currentStock
    }
    class Transaction {
        +date transactionDate
        +Customer customer
        +Salesperson salesperson
        +Car purchasedCar
        +float transactionAmount
    }

    Customer "1" "--* Department : has
    Car *-- Inventory : is_stored_in
    Salesperson +Department : belongs_to
    Salesperson -> Transaction : performs
    Transaction --> Customer : records
```