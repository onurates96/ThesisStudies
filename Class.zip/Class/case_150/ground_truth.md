classDiagram;
  class Customer {
    +customerId: String
    +name: String
    +email: String
  }
  class Car {
    +carId: String
    +make: String
    +model: String
    +year: Int
    +price: Float
  }
  class Salesperson {
    +salespersonId: String
    +name: String
    +email: String
  }
  class Inventory {
    +inventoryId: String
    +carId: String
    +quantity: Int
  }
  class Transaction {
    +transactionId: String
    +customerId: String
    +carId: String
    +salespersonId: String
    +transactionDate: Date
    +amount: Float
  }
  Customer "1" -- "*" Transaction: makes;
  Car "1" -- "*" Transaction: involvedIn;
  Salesperson "1" -- "*" Transaction: handles;
  Car "1" -- "*" Inventory: managesInventory;