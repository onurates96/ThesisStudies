```mermaid
classDiagram
    class Customer {
        +string name
        +string email
        +address() void
    }
    class Car {
        +string VIN
        +int year
        -boolean isSold
    }
    class Salesperson {
        +string name
        +string email
        ~list~<Car> assignedCars:0..*
    }
    class Inventory {
        +list~<Car> cars:1..
        +addCar(car: Car) void
    }
    class Transaction {
        +string date
        +decimal amount
        -Customer customer
        -Car car
    }

    Customer --> Salesperson : assignedTo
    Salesperson *-- Inventory : managesInventory
    Car -- Inventory : storedIn
    Customer ..> Transaction : makesPurchase
    Salesperson ..|> Transaction : facilitatesTransaction
```