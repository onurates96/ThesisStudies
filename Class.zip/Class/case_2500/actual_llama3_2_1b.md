class Diagram
{
    +string name;
    class Product {
        -string description;
        -float price;
        +string category;
        
        class Inventory {
            -int quantity;
            
            +void addQuantity(quantity: int) void;
            +void removeQuantity(quantity: int) void;
        }
        
        -Product another;
        
        +void getDetails() void
    }
    
    class Customer {
        -string name;
        -integer age;
        -boolean isMammal;
        
        +Customer login(): bool = function() return true;
        -void displayInfo() void
        
        +List<Payment> payments = new List~Payment~()
    }
    
    class Sale {
        -integer id;
        -Date date;
        -Customer customer;
        -Product product;
        -float amount;
        
        +Sale login(): bool = function() return true;
        +void displayInfo() void
        
        +void createSale(product: Product, price: float, amount: float) void
    }
    
    class Payment {
        -integer id;
        -Date date;
        -Customer customer;
        
        +Payment login(): bool = function() return true;
        +void displayInfo() void
        
        +float getAmount() float
    }
    
    class InventoryItem {
        -int id;
        -Product product;
        
        +void addQuantity(quantity: int) void
        +void removeQuantity(quantity: int) void
        
        +List<Inventory> inventory = new List~Inventory~()
    }
}