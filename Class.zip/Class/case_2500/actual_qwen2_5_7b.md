```mermaid
classDiagram
    class Product {
        +string name
        +decimal price
        -int stockQuantity
        +sell(quantity:int) void
    }
    class Customer {
        +string firstName
        +string lastName
        -List~Purchase~ purchases
    }
    class Sale {
        +Product product
        +Customer customer
        +decimal totalAmount
        +date saleDate
    }
    class Payment {
        +string paymentMethod
        +decimal amountPaid
    }
    class Inventory {
        +List~Product~ productsInStock
        -updateInventory(quantity:int) void
    }
    Product --|> Sale : contains
    Customer --|> Purchase : madeBy
    Sale --> Payment : uses
    Inventory *-- Product : manages
```