```mermaid
classDiagram
    class Product {
        +string name
        +double price
        +int quantity
    }
    class Customer {
        +string name
        +string address
        +List<Product> shoppingCart
    }
    class Sale {
        +Date date
        +Customer customer
        +association Customer->Sale : placedFor
        +list Products products
    }
    class Payment {
        +string type
        +double amount
        +association Sale.Payment: payment
        +void confirm()
    }
    class Inventory {
        +Product product
        +int quantity
        +association Product.Inventory: stock
    }

    Product <|-- Inventory : Composition
    Customer -> Sale : placesOrder
    Sale --> Payment : needsPayment
    Sale o-- Inventory : isBasedOn
```