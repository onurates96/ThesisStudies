```mermaid
classDiagram
    Customer <|-- Store
    Customer : +string name
    Customer : +string address
    Store : *--"0.."* Customer
    Store : +string id
    Store : +int quantity
    Store : +boolean closed
    Customer : +1..* customer
    Customer : +2..* order
    Customer : +3..* orderTotal
    Product <|-- Category
    Product : +integer price
    Sale <|-- Customer
    Payment <|-- Sale
    Inventory <|-- Product
    Inventory : +decimal quantity
    Inventory : +string category
```