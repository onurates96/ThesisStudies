```mermaid
classDiagram
    class Product {
        +string name
        +decimal price
        +int quantity
        -Category category
        +addInventory(item:Product) void
        +removeInventory(quantity:int) void
    }
    class Customer {
        +string name
        +string address
        +string phone
        -List<Sale> purchases
        +makePurchase(product:Product, quantity:int) void
    }
    class Sale {
        +Product product
        +Customer customer
        +Date timestamp
        +Payment payment
        +void finalize()
    }
    class Payment {
        +Customer customer
        +decimal amount
        +string paymentMethod
        -String transactionID
        +processPayment() bool
    }
    class Inventory {
        *-- Product : stocks
        +addProduct(product:Product) void
        +removeProduct(product:Product) void
    }
```