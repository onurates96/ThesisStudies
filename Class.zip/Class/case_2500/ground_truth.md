classDiagram
    class Product {
        +int ProductID
        string Name
        string Description
        double Price
        int Stock
    }
    class Customer {
        +int CustomerID
        string Name
        string Address
        string Email
        string Phone
    }
    class Sale {
        +int SaleID
        int CustomerID
        Date SaleDate
        double TotalAmount
    }
    class Payment {
        +int PaymentID
        int SaleID
        double Amount
        string PaymentMethod
    }
    class Inventory {
        +int InventoryID
        int ProductID
        int Quantity
    }
    Customer --> Sale : makes_purchase
    Product --> Sale : includes_products
    Sale --> Payment : completes_payment
    Product --> Inventory : manages_inventory