```mermaid
classDiagram
class Product {
    +string name
    -decimal price
}
class Customer {
    +string name
    -decimal balance
}
class Sale {
    +datetime date
    -decimal totalCost
    +Customer customer
    +Product product
}
class Payment {
    +datetime paymentDate
    -decimal amount
    +Sale sale
}
class Inventory {
    +int quantity
    +Product product
}
Product *-- Sale : Sold
Sale *-- Customer : BelongsTo
Sale o-- Product : IncludedInInventory
Customer --> Inventory : HasInventory
Payment -- Sale : AssociatedWithSale
```