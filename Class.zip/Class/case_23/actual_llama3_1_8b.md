```mermaid
classDiagram
    class Book {
        +string title
        +decimal price
    }
    class Patron {
        -int id
        +string name
        +borrow(Book) bool
        +return(Book) void
    }
    class Librarian {
        +string name
        #manageInventory() void
        Patron "1" --> "*" Book : belongsTo
        Book -- Patron : borrowedBy
        Patron ..> Librarian : dependentOn
    }
```