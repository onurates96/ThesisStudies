```mermaid
mermaid
classDiagram
    class LibraryManagementSystem {
        Book <|-- Patron
        Librarian
            +Book
            +Return
            +ManageInventory
        Book : +Author
        Patron : +ISBN
        Patron : +ID
        Librarian : +Name
    }
```