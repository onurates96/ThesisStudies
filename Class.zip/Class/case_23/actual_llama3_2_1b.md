```mermaid
classDiagram
    class Book {
        +title string
        +author string
        +year int
        +borrowed bool
    }
    
    class Patron {
        +name string
        +id int
    }
    
    class Librarian {
        +name string
        +age int
        +license boolean
    }
    
    class Borrow {
        +book Book : +patron Patron 
        +issueDate date
        +returnDate date
    }
    
    class Return {
        +borrowingID int
        +book Book : +borrowed bool
        +status string: 'Available' | 'Lost'
    }
```