```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +int yearPublished
        -List~Patron~ borrowedBy
        borrow(Patron) void
        return() void
    }
    class Patron {
        +string name
        +string contactInfo
        "1" --> "0..*" Book : borrowedBooks
    }
    class Librarian {
        +string name
        +List~Book~ inventory
        addBook(Book) void
        removeBook(Book) void
        manageInventory() void
    }
    Book --> Patron : borrow, return
    Librarian *-- Book : manageInventory
```