```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +int publicationYear
        -boolean isAvailable
        +void borrow()
        +void returnBook()
    }
    class Patron {
        +string name
        +string patronID
        +List~string~ borrowedBooks
        +void borrowBook(book: Book)
        +void returnBook(book: Book)
    }
    class Librarian {
        +string name
        +string librarianID
        +ManageInventory manageBooks
        +void addBook()
        +void removeBook()
        +void updateAvailability()
    }
    Patron "1" --> "*" Book : borrows
    Librarian "1" --> "1..*" Book : manages
```