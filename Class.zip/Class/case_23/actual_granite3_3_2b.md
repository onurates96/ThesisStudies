```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +int yearPublished
        +BookInventory inventory
        +borrow(Patron patron)
        +return(Librarian librarian)
    }
    class Patron {
        +string name
        +list borrowedBooks
        +Book.borrow(Book book)
        +Book.return(Book book, Librarian librarian)
    }
    class Librarian {
        +string name
        +Book.manageInventory()
    }
    Book "1" "--* Patron : Borrow
    Patron "1..*" "-- Book Return
    Librarian "0..1 : Manage Inventory"
```