```mermaid
classDiagram
    class Product { +int id: string }
    class Inventory { +Product id: int }
    class Supplier { +string name }
    class PurchaseOrder { +Product id: int }
    class SalesTransaction { +PurchaseOrder id: int, product: Product, quantity: int }
    class OrderItem { -Product id: int, quantity: int }
    
    class Customer { +CustomerId: string, name: string }
    class Employee { +EmployeeId: string, name: string, role: string }
    class Department { +DepartmentId: string, name: string }
    class Location { +LocationId: string, address: string }
    
    Supplier : +string supplierName
    PurchasingDepartment : +Customer id: int
    
    class PurchaseOrder {
        +Customer id: int
        +Supplier id: int
        +Quantity: int
    }
```