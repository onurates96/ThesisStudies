```mermaid
classDiagram
    Product <|-- Inventory
    Inventory : +* *..* Product

    Supplier <|-- PurchaseOrder
    PurchaseOrder : *..* Supplier

    PurchaseOrder <|-- SalesTransaction
    SalesTransaction : *.."1..*" PurchaseOrder

    Product <|-- OrderLine
    OrderLine : +* *..* Product

    OrderLine <|-- Transaction
    Transaction : *..* OrderLine

    PurchaseOrder <|-- Order
    Order : *..* PurchaseOrder
```