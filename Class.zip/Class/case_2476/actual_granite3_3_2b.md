```mermaid
classDiagram
    interface Supplier{
        +string name
        +string contactInfo
        +string location
    }
    class Product {
        +string id
        +string name
        +string description
        +float price
        +int stockQuantity
        *-- Inventory: manageInventory
    }
    class Inventory {
        +Product product
        +float currentStockQuantity
        +void updateStock(delta int)
    }
    class PurchaseOrder{
        +Supplier supplier
        +List orderDetails : ~String
        ..> Product : placeOrder
    }
    class SalesTransaction{
        +date transactionDate
        +int quantity
        o-- Inventory: updateStock
        ..> Product : recordSale
    }
```