```mermaid
classDiagram
    class Product {
        +string name
        +decimal price
        +Supplier supplier
        -Inventory inventory
        +addInventory(quantity:int) void
        +removeInventory(quantity:int) void
    }
    class Inventory {
        +int quantity
        +Product product
        -PurchaseOrder purchaseOrder
        +updateStock(change:int) void
    }
    class Supplier {
        +string name
        +string contactInfo
        -List~Product~ products
        +addProduct(product:Product) void
        +removeProduct(product:Product) void
    }
    class PurchaseOrder {
        +string orderDate
        +Supplier supplier
        *--"1" Inventory inventory
        +placeOrder(products:List~Product~) void
    }
    class SalesTransaction {
        +DateTime transactionDate
        +Product product
        +Customer customer
        +decimal amount
        -PurchaseOrder purchaseOrder
        +recordSale() void
    }
```