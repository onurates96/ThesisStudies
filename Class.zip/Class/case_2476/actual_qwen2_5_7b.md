```mermaid
classDiagram
    class Product {
        +string name
        +int price
        -Supplier supplier
        +void updatePrice(newPrice:int) void
    }
    class Inventory {
        +List~Product~ productsInventory
        *-- PurchaseOrder purchaseOrders
        o-- SalesTransaction salesTransactions
        +int getStockLevel() int
    }
    class Supplier {
        +string companyName
        +list~Product~ productsSupplied
        -Inventory inventory
        +void updateStock(product:Product, quantity:int) void
    }
    class PurchaseOrder {
        *-- Product productOrdered
        +int orderQuantity
        +float totalCost() float
    }
    class SalesTransaction {
        o-- Product soldProduct
        +string transactionId
        +float transactionAmount
    }
    Product --> Inventory : Association
    Supplier <|-- Product : Inheritance
    PurchaseOrder *-- Supplier : Composition
    SalesTransaction ..> Product : Realization
```