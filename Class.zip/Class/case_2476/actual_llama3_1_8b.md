```mermaid
classDiagram
    class Product {
        +string name
        +decimal price
    }
    class Inventory {
        +Product products
        -int quantity
    }
    class Supplier {
        +string name
        +ContactInfo contactInfo
    }
    class PurchaseOrder {
        +Supplier supplier
        +Inventory inventory
        -datetime orderDate
    }
    class SalesTransaction {
        +Product product
        +Inventory inventory
        -datetime transactionDate
    }
    Inventory "1" --> "*" Product : contains
    Supplier ..> PurchaseOrder : dependency
    SalesTransaction -- Inventory : link
    class ContactInfo {
        -string address
        -string phone
        -string email
    }
```

This Mermaid code block represents a basic design for a retail inventory management system.