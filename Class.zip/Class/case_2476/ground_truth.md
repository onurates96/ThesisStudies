classDiagram
    class Product {
        +int ProductID
        string Name
        string Description
        double Price
        int Quantity
    }
    class Inventory {
        +int InventoryID
        int ProductID
        int SupplierID
        int QuantityOnHand
    }
    class Supplier {
        +int SupplierID
        string Name
        string Address
        string Phone
    }
    class PurchaseOrder {
        +int OrderID
        int ProductID
        int SupplierID
        Date OrderDate
        int Quantity
    }
    class SalesTransaction {
        +int TransactionID
        int ProductID
        Date TransactionDate
        int Quantity
        double TotalAmount
    }
    Product --> Inventory : is_stored_in
    Supplier --> Inventory : supplies
    Supplier --> PurchaseOrder : places_orders
    Product --> PurchaseOrder : is_ordered_in
    Product --> SalesTransaction : is_sold_in