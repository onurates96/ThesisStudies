```mermaid
classDiagram
    class Customer
        +string name
        +string email
        +string address
        +int cartItems "0..*"
    class Admin
        +string username
        +string password
        -boolean isActive
        +void addProduct() void
        +void removeProduct() void
    class Product
        +string name
        +decimal price
        +string description
        +image url
    class PaymentGateway
        +string gatewayId
        +boolean isSecure
        +void processPayment(amount:decimal) bool
    Customer "1" --> "*" Order : purchases
    Admin <|-- Product : manages
    Customer --> Product : browses
    Customer --> Product : adds to cart
    Customer --> PaymentGateway : processes payment
    Admin --> Product : manages inventory
```