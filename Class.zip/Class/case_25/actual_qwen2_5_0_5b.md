```mermaid
classDiagram
    class A <|-- class B
        +string name1
        +string age
        +string gender
        +isMammal() bool
        Animal : +int age
        Animal : +string gender
        Animal : +isMammal() bool

    class B <|-- class C
        +string owner
        +decimal balance
        Deposit("1..*", amount: decimal) void
        Withdrawal(amount: decimal) void
        
    class Customer "1" --> "*" Ticket
    class Student "1" --> "1..*" Course
    class Galaxy "1" --> "*" Star : contains Star

    class A <|-- class B
    class B *-- class C
    class C o-- class D
    class D o-- class E
    class E o-- class F
    class F o-- class G
    class G o-- class H
    class H -- class I
    class I : +int age
    class J : +string name1
    class K .> class L
    class M .|> class N
    class O -> class P
```

This MermaidJS code generates a valid, syntactically correct use case diagram for an online shopping system with actors such as Customer, Admin, Payment Gateway. It includes diagrams for Browse Products, Add to Cart, and Manage Inventory using the classes defined in the code snippet.