```mermaid
classDiagram
    class Customer {
        +string name
        +string address
        -login() bool
        +browseProducts() void
        +addToCart(product: string) void
    }
    class Admin {
        +manageInventory() void
        -addProduct() void
        -removeProduct() void
    }
    PaymentGateway -- "1..*" Customer : processPayment()
    Customer --> "0..*" Order : placeOrder()
    class Order {
        +string orderId
        +List~Product~ products
        +totalAmount() decimal
    }
    Admin <|-- "1" Customer : authorizeAdminAccess()
    class Product {
        +string name
        +decimal price
    }
    Admin o-- "0..*" Product : manageProductInventory()
```