```mermaid
classDiagram
    class Actor {
        +name: string;
        +age: int;
        +gender: str;
        +isMammal(): bool;
        +mate(): void;
        +children: List~Actor?;
    }
    
    class Product {
        +name: str;
        +description: str;
        +price: decimal
    }
    
    class PaymentGateway {
        +url: str;
        +timeout: int?
    }
    
    class Customer {
        +id: int;
        +name: str;
        +email: str;
        +password: str;
        +address: str
        +balance: decimal
        +inventory: Map~Product?;
    }
    
    class PaymentMethod {
        +type: str;
        +name: str;
        +description: str
    }
    
    class Order {
        +id: int;
        +customer: Customer;
        +product: Product;
        +payment: PaymentGateway
    }
```