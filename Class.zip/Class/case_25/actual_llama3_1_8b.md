```mermaid
classDiagram
class OnlineShoppingSystem {
  +string database_name
  +list products
}
OnlineShoppingSystem <|-- Customer
Customer *-- Order
Order o-- Product
Product --> PaymentGateway : payment_required
PaymentGateway ..> Admin : authentication_required
Admin ..|> OnlineShoppingSystem : management_required
class Customer{
  +string email
  +login() bool
}
class Order{
  -int order_id
  +add_to_cart(product:Product) void
}
class Product{
  +string product_name
  +list images
  +view_product_details() void
}
```