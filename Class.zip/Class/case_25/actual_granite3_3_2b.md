```mermaid
classDiagram
    class Customer {
        +string name
        +string email
        +string address
        +int id
        +void browseProducts()
        +void addToCart(Product product)
    }
    class Admin {
        +string username
        +string password
        +string role
        +void manageInventory(Product product, int quantity)
    }
    class PaymentGateway {
        +string api_key
        +void processTransaction(Order order)
    }
    class Product {
        +string name
        +float price
        +string description
        +void addToCart(Customer customer)
    }
    Customer "1" --> "*" Order : places
    Admin "1" >> "*" Order : views
    PaymentGateway "1" --> "*" Order : processes
    Admin "1" --> "1..*" Order : approves
    Product "1" "1..*" Order : selected
```