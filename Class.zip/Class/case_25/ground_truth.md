classDiagram
  Class Customer{
    +name: string
    +email: string
  }

  Class Admin{
    +name: string
    +username: string
  }

  Class PaymentGateway{
    +name: string
    +apiKey: string
  }

  Customer --> Browse Products
  Customer --> Add to Cart
  Admin --> Manage Inventory
  PaymentGateway --> Process Payment