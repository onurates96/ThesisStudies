classDiagram
    class Customer {
        +int CustomerID
        string Name
        string Address
        string Email
        string Phone
    }
    class Account {
        +int AccountID
        int CustomerID
        double Balance
        Date OpenDate
    }
    class Transaction {
        +int TransactionID
        int AccountID
        string Type
        double Amount
        Date TransactionDate
    }
    class Bank {
        +int BankID
        string Name
        string Address
    }
    class Loan {
        +int LoanID
        int CustomerID
        double Amount
        double InterestRate
        Date LoanDate
    }
    Customer --> Account : owns
    Customer --> Loan : applies_for
    Account --> Transaction : performs
    Bank --> Account : manages_accounts