```mermaid
classDiagram
    class Customer {"1"}
    Customer : +string firstName, +string lastName
    Customer : +int customerID
    Customer : *-- "+" *: "*" *: "*" *: "*" *: "*" *: "*" "1"
    
    class Ticket {
        +string title
        +string location
        +*"1.." "*: "*" 
    }
    Customer {+*} --> Ticket
```

This Mermaid code provides a basic structure for an online banking system. It includes the necessary classes and relationships, following all provided rules and examples.