```mermaid
classDiagram
    class Customer {
        +string name
        +int age
        -string address
        login() bool
        viewAccount(Account) void
    }
    class Account {
        +decimal balance
        +string accountNumber
        deposit(amount:decimal) void
        withdraw(amount:decimal) void
    }
    class Transaction {
        +decimal amount
        +string description
    }
    class Bank {
        +string name
        -List~Transaction~ transactions
    }
    class Loan {
        +decimal interestRate
        +int termInMonths
    }
    Customer -- Account : hasAccount
    Account *-- Transaction : containsTransaction
    Bank o-- Account : ownsAccount
    Loan --> Account : appliesTo
```