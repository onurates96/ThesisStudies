```mermaid
classDiagram
    class Customer {
        +string name
        +int customerId
        +address
            -street
            -city
            -zip
        +login(username:string, password:string) bool
        +registerAccount() Account
    }
    class Account {
        +int accountId
        +string accountType
        +decimal balance
        +Customer owner
        -list<Transaction> transactions
    }
    class Transaction {
        +transactionId
        +amount decimal
        +date dateTime
        +Account fromAccount
        +Account toAccount
        -isCompleted bool
    }
    class Bank {
        +bankName
        +branchLocations
            -street
            -city
            -zip
        +offerLoan() Loan
    }
    class Loan {
        +loanId
        +amount decimal
        +interestRate decimal
        +term years
        +customer Customer
        -status string
    }
    Customer "1" --> "*" Account : has
    Account --> Transaction : records
    Bank "1" --> "*" Loan : offers
```