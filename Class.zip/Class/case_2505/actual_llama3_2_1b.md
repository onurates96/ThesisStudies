class Diagrammer {
    +string name
    +string description
    +Customer
        +integer id
        +string name
    +Account
        +string owner
        +decimal balance
        +function deposit(amount:decimal)
        +function withdrawl(amount:decimal)
    +BankAccount
        +string owner
        +decimal balance
        +function getBalance()
        +function deposit(amount:decimal)
        +function withdrawl(amount:decimal)
    +Loan
        +integer id
        +Customer : owner
        +decimal interestRate
        +function payInterest()
} : Inheritance
class Customer {
    +string name
    +Customer : owner
    +Customer : mate() void
} : Aggregation
class Transaction {
    +integer id
    +BankAccount : owner
    +decimal amount
    +Transaction : realization
    class BankAccount {
        +string owner
        +BankAccount : owner
        +BankAccount : deposit(amount:decimal) void
        +BankAccount : withdrawl(amount:decimal) void
        +BankAccount : getBalance() decimal
    }
} : Association
class Bank {
    +string name
    +Customer : owners
    +Bank : BankAccount
    class BankAccount {
        +string owner
        +BankAccount : owner
        +BankAccount : deposit(amount:decimal) void
        +BankAccount : withdrawl(amount:decimal) void
        +BankAccount : getBalance() decimal
    }
} : Composition
class Loan {
    +integer id
    +Customer : owner
    +Loan : BankAccount
    class BankAccount {
        +string owner
        +BankAccount : owner
        +BankAccount : deposit(amount:decimal) void
        +BankAccount : withdrawl(amount:decimal) void
        +BankAccount : getBalance() decimal
    }
} : Composition