```mermaid
classDiagram
    class Bank {
        +string bankName
        +list~Account~ accounts
        -- Account *accounts
    }
    class Customer {
        -string customerId
        -string name
        +openAccount() Account
    }
    class Account {
        +decimal balance
        -Customer customer
        --> Customer : owner
        -- Bank *banks
    }
    class Transaction {
        +decimal amount
        +string description
        -Account account
        --> Account : relatedTo
    }
    class Loan {
        +decimal loanAmount
        -Account account
        o-- Account : securedBy
    }
```