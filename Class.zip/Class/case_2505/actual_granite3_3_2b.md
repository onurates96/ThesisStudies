```mermaid
classDiagram
    classCustomer {
        +string name
        +string address
        +decimal balance
        +void deposit(amount: decimal)
        +void withdrawal(amount: decimal)
    } *-- classAccount {
        +void transferToBank(amount: decimal, customer: Customer)
    }

    classAccount {
        +decimal balance
        +void deposit(amount: decimal)
        +void withdrawal(amount: decimal)
    } --> classTransaction {
        +void processTransaction(account: Account, amount: decimal, type: string)
    }

    classLoan {
        +string borrowerName
        +decimal loanAmount
        +void approveLoan()
        +void repayLoan(amount: decimal)
    } o-- classBank {
        +void issueLoan(customer: Customer, amount: decimal)
    }
```