```mermaid
classDiagram
    class Car {
        -string model
        -int year
        +drive() void
        +park() void
    }
    class Customer {
        +string name
        +string address
        -string phoneNumber
        +rentCar(car:Car) void
    }
    class RentalAgency {
        -string agencyName
        -List~Car~ availableCars
        +addCar(car:Car) void
        +removeCar(car:Car) void
        +rentCar(customer:Customer, car:Car) void
    }
    class Rental {
        "1"
        +car:Car
        +customer:Customer
        +startDate:date
        +endDate:date
        +totalCost():decimal
    }
    class Payment {
        -decimal amount
        +makePayment(rental=Rental, amount:decimal) void
    }
    Car -- Customer : Rent
    RentalAgency *-- Car : Manages
    RentalAgency --> Rental : Offers
    Rental <|-- Payment : Includes
```