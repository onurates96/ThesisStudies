classDiagram
    class Car {
        +int CarID
        string Model
        string Brand
        string Color
        double RentalPricePerDay
        boolean Available
    }
    class Customer {
        +int CustomerID
        string Name
        string Address
        string Email
        string Phone
    }
    class Rental {
        +int RentalID
        int CarID
        int CustomerID
        Date StartDate
        Date ReturnDate
        double TotalCost
    }
    class RentalAgency {
        +int AgencyID
        string Name
        string Location
    }
    class Payment {
        +int PaymentID
        int RentalID
        double Amount
        string PaymentMethod
    }
    Customer --> Rental : rents
    Car --> Rental : is_rented
    RentalAgency --> Car : manages_cars
    Rental --> Payment : processes_payment