```mermaid
classDiagram
    class Car { +integer licensePlateNumber +string color: string -number mileage: int }
    class Customer {
        +string firstName +string lastName +string phoneNumber
        +optional integer age
        +optional string gender
        +optional bool isMammal()
        +optional void mate() 
        +optional method login(): bool
        +optional void payment(int depositAmount): void
    }

    class Rental {
        +integer customerNumber: int +integer rentalDuration: int -int id : integer -class Customer customer: classCustomer customerNumber: integer +string carLicensePlateNumber: string +string location: string -Car car: Car +boolean hasPaidReturn(): bool 
        +method rent(): void
        +method returnCar(): void
    }

    class RentalAgency {
        +integer agencyId: int +string name: string +class ListRentalList rentals: List<_rental.Rental>
        +optional method addCustomer(customer: Customer): void
        -method removeCustomer(customerNumber: integer): void
    }

    class Payment {
        +integer paymentNumber: int +decimal amountToPay: decimal -class Transaction transaction: classTransaction
        +optional method makePayment(): void
        +optional method refund(): void
    }
```