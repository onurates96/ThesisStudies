```mermaid
classDiagram
    Car <|-- Rental
    Rental <|-- Payment
    class Car {
        +string licensePlateNumber
        +string color
        +int yearOfManufacture
    }
    class Customer {
        +string name
        +string email
        +string phoneNumber
    }
    class RentalAgency {
        +string name
        +string address
        +string contactInformation
    }
    class Rental {
        -Car car
        -Customer customer
        -Payment payment
        -RentalAgency agency
    }
    class Payment {
        -float amount
        -PaymentMethod method
    }
    Customer "1" --> "*" Rental : canRent
    Rental *-- Car : hasCar
    Rental *-- Payment : hasPayment
    Rental o-- RentalAgency : belongsTo
```