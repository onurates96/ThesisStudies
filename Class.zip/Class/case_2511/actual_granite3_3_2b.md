```mermaid
classDiagram
    class Car {
        +string color
        +int year
        +float fuelCapacity
        +void refuel(amount: float)
    }
    class Customer {
        +string name
        +int id
        +Car[] reservedCars
    }
    class RentalAgency {
        +string name
        +int id
        +Customer[] customers
    }
    class Rental {
        +Date startDateTime
        +Date endDateTime
        +Car car
        +RentalAgency agency
        +void calculateRent()
    }
    class Payment {
        +float amount
        +Rental rental
        +void processPayment(rental: Rental)
    }
    Car <|-- Payment
    Customer *-- RentalAgency
    Rental o-- Car
    Rental o-- Payment
```