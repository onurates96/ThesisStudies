```mermaid
classDiagram
    class Car{
        +string model
        +int year
        +Engine engine
        -Rental rental
        +start() void
        +stop() void
    }
    class Customer{
        +string name
        +string id
        -Payment payment
        +rentCar(car:Car) : Rental
    }
    class Rental{
        +dateStart
        +dateEnd
        +Car car
        +Customer customer
    }
    class RentalAgency{
        +string name
        *-- Rental rental
        +addRental(rental:Rental) void
        +removeRental(rental:Rental) void
    }
    class Payment{
        +amount
        +date
        -Rental rental
        +pay(rental:Rental) void
    }
```