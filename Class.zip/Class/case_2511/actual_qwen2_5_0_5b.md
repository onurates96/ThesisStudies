```mermaid
classDiagram
    class Car {"1"}
    Customer "1" -- Car {0..*}
    Rental "1" -- * (Car, RentalAgency)
    Rental Agency "1" -- * (Customer, RentalAgency)
    Payment "1" -- Rental (Payment, Rental)
    Payment "2" -- Rental (Payment, Rental)
```
```mermaid
classDiagram
classA {"1"}
Duck "1" -- classA {0..*}
Fish "1" -- Fish
Zebra "1" -- Zebra
Duck : +string beakColor
Fish : +int sizeInFeet
Fish : +canEat()
Zebra : +run() 
```