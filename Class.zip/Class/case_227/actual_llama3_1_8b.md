```mermaid
classDiagram    
    class Library {
        +string name
        +Catalog catalog
        -Loan loanSystem
        +Member[] members
    }
    class Book {
        +string title
        +Author author
        -string ISBN
        +boolean isAvailable
    }
    class Member {
        +string memberId
        +string name
        +Library library
    }
    class Loan {
        +string loanId
        +Member member
        +Book book
        +date borrowedDate
    }
    class Reservation {
        +string reservationId
        +Member member
        +Book book
        +date reservedDate
    }
    class Catalog {
        +Book[] books
        +Library library
    }
    Library <|-- Loan
    Member *-- Reservation
    Book o-- Catalog : Belongs
    Member --> Library : Member of library
    Loan -- Catalog : Contains books
    Catalog ..> Loan : Dependency on loan system
    class Author {
        +string name
        -Book[] books
    }
```