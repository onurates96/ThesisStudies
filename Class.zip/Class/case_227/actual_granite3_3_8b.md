```mermaid
classDiagram
    class Library
        +string name
        +Location location
        +int totalBooks
        +Member[] members
        +Book[] books
        +Loan[] loans
        +Reservation[] reservations
    class Book
        +string title
        +string isbn
        +string author
        +Library library
        +boolean available
    class Member
        +string name
        +string id
        +string address
        +Library library
        +Book[] borrowedBooks
        +Reservation[] reservedBooks
    class Loan
        +LoanId id
        +Member borrower
        +Book book
        +LoanDate loanDate
        +DueDate dueDate
        +Library library
    class Reservation
        +ReservationId id
        +Member member
        +Book book
        +ReservationDate reservationDate
        +Library library
    class Catalog
        +string format
        +Library library
        +Book[] books
    Library <|-- "1" "has" Book : catalogs
    Member "1..*" "borrows" Loan : canBorrow
    Member "0..1" "reserves" Reservation : canReserve
    Library "1" "manages" Member : hasMembers
    Library "1" "catalogs" Catalog : hasCatalog
```