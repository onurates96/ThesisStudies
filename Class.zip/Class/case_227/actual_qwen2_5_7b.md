```mermaid
classDiagram
    class Library {
        +string name
        -List~Book~ books
        -List~Member~ members
        +addBook(book: Book) void
        +removeBook(book: Book) void
        +addMember(member: Member) void
        +removeMember(member: Member) void
    }
    class Book {
        +string title
        +int isbn
        +string author
        -Loan currentLoan
        -Reservation pendingReservations
        +borrow() Loan
        +reserve() Reservation
    }
    class Member {
        +string name
        +string membershipType
        -List~Loan~ loans
        -List~Reservation~ reservations
        +borrowBook(book: Book) Loan
        +placeReservation(book: Book) Reservation
    }
    class Loan {
        +Date borrowDate
        +Date returnDate
        +Book book
        +Member member
    }
    class Reservation {
        +Date reservationDate
        +Book book
        +Member member
    }
    class Catalog {
        +List~Book~ books
        +search(title: string) Book
    }
    Library *-- Book : contains
    Library *-- Member : manages
    Book --> Loan : has
    Book --> Reservation : has
    Member --> Loan : borrows
    Member --> Reservation : reserves
    Catalog o-- Book : catalogs
```