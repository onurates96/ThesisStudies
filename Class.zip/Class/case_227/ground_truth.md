classDiagram;
  class Library {
    +libraryId: String
    +name: String
    +location: String
  }
  class Book {
    +bookId: String
    +title: String
    +author: String
  }
  class Member {
    +memberId: String
    +name: String
    +address: String
  }
  class Loan {
    +loanId: String
    +memberId: String
    +bookId: String
    +loanDate: Date
    +returnDate: Date
  }
  class Reservation {
    +reservationId: String
    +memberId: String
    +bookId: String
    +reservationDate: Date
  }
  class Catalog {
    +catalogId: String
    +bookId: String
    +location: String
  }
  Library "1" -- "*" Book: hasBooks;
  Library "1" -- "*" Member: hasMembers;
  Book "1" -- "*" Loan: isLoaned;
  Member "1" -- "*" Loan: borrows;
  Member "1" -- "*" Reservation: makesReservation;
  Book "1" -- "*" Reservation: hasReservations;