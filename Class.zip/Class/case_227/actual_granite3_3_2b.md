```mermaid
classDiagram
    class Library {
        +void addBook(book: Book)
        +List<Book> searchCatalog(query: string)
        +Book reserveBook(book: Book, member: Member)
        +Book borrowBook(book: Book, member: Member)
        +void returnBook(book: Book, member: Member)
    }

    class Book {
        +string title
        +string author
        +Date publicationDate
        +List<Member> membersReserved : 1..*
    }

    class Member {
        +string name
        +string id
        +List<Book> checkedOut : 0..*
    }

    class Loan {
        +Book book
        +Member member
        +Date loanDate
        +Date dueDate
        +Date returnDate : 1
    }

    class Reservation {
        +Book book
        +Member member
        +Date reservationDate
        +Date expectedReturnDate : 1
    }

    Library <|-- Book
    Library <|-- Member
    Member "1..*" "0..1" Loan : Association
    Member "1.." Reservation : Association
```