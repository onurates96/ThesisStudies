```mermaid
classDiagram
    Library : 
        --> Catalog
        -->
    Book : 
        +title
        +subject
        --> Library
        +genre
        --> Member
        classCatalog {
            --> Loan
            --> Reservation
        }
    Member : 
        --> Loan
        --> LoanReturn
        --> Notification
        --> Vacation
        +name
        +age
        +email
        +phone
        +borrowingHistory
        --> Catalog
classCatalog : 
        --> BorrowedBooks
        --> CheckedOutBooks
        classBorrowed {
            --> Book
            --> IssueDate
        }
    Loan : 
        --> Member
        --> ReturnDate
    Reservation : 
        --> Date
        --> Time
        --> Room
```