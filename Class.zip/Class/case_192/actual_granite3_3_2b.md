```mermaid
classDiagram
    class Restaurant {
        +string name
        +location
        +Chef chef
        +Menu menu
        +Table table
        +Reservation reservation
    }
    class Menu {
        +list<MenuItem> items
    }
    class Table {
        +seat_count
        +occupied_seats : boolean
    }
    class Reservation {
        +Party party
        +time time
        +Restaurant restaurant
    }
    class Order {
        +OrderID
        +Table table
        +items list<OrderItem>
        +Chef chef
    }
    class Chef {
        +name
        +expertise : string
        +assigned_restaurant Restaurant
    }
    Restaurant "1" --> "1.." Menu
    Restaurant *-- Reservation
    Menu --> Order
    Chef -> Restaurant
    Chef : +string expertise
    Reservation : time
    Order : table
```