```mermaid
classDiagram
    class Restaurant
        +string name
        +List~Table~ tables
        +Menu menu
        +List~Chef~ chefs
    class Menu
        +string category
        *--"1" MenuItem : defines
    class Table
        +int number
        +bool occupied
        +Reservation reservation
        *--"1" Order : placed at table
    class Reservation
        +Date time
        +Customer customer
        "1" --> "*" Table : reserved for
    class Order
        +List~Dish~ dishes
        +bool completed
        +Chef chef : assigned to prepare
    class Chef
        +string name
        +List~Dish~ specialties
        o--"1" Restaurant : works at
```