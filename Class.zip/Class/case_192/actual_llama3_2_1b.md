```mermaid
classDiagram
    class Restaurant {
        +name: string
        +address: string
    }
    
    class Menu {
        +id: integer
        +name: string
        
        +classA: string = ""
    }
    
    class Table {
        +id: integer
        
        -status: string
        -customer: Customer
        -menu: Menu
    
    }
    
    class Reservation {
        +id: integer
        +table: Table
        
        +classB: String = "None"
    }
    
    class Order {
        +id: integer
        +classC: List<OrderItem>
        
        +classD: Integer = 1
        
        +classE: void
        -classF: String = ""
    }
    
    class Chef {
        +name: string
    
        +classG: void
    }
    
    class OrderItem {
        +id: integer
        
        +classH: int = 0
        
        +classI: string = ""
        
        +classJ: Object
    }
```

```mermaid
classDiagram
    class Chef {
        +name: string
    
        +classK: void
    }
    
    class MenuItem {
        +id: integer
        
        -category: String
        -quantity: int
        
        +classL: Object
    }
```