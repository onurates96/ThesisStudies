```mermaid
classDiagram
    Restaurant <|-- Menu
    Menu : +string name
    Menu : *-- Table
    Menu <|-- Order : +string dish
    MenuItem : +string item
    Order : +Restaurant restaurant
    Order : +Table table
    Table : +string location

    Menu : +isFavorite() bool
    Customer "1" --> "*" order
    Customer "2" --> "*" order
    Customer "3" --> "*" order
    Customer "4" --> "*" order
```

This code snippet generates a Mermaid class diagram for the restaurant management system. It includes the required classes, relationships, and additional details as specified in the rules.