classDiagram;
  class Restaurant {
    +restaurantId: String
    +name: String
    +location: String
  }
  class Menu {
    +menuId: String
    +restaurantId: String
    +item: String
    +price: Float
  }
  class Table {
    +tableId: String
    +restaurantId: String
    +capacity: Int
  }
  class Reservation {
    +reservationId: String
    +restaurantId: String
    +tableId: String
    +dateTime: DateTime
  }
  class Order {
    +orderId: String
    +reservationId: String
    +menuItem: String
    +quantity: Int
    +status: String
  }
  class Chef {
    +chefId: String
    +name: String
    +specialty: String
  }
  Restaurant "1" -- "*" Menu: hasMenu;
  Restaurant "1" -- "*" Table: hasTables;
  Table "1" -- "*" Reservation: hasReservations;
  Reservation "1" -- "*" Order: hasOrders;
  Chef "1" -- "*" Order: prepares;