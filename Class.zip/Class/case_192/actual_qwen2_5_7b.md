```mermaid
classDiagram
    class Restaurant {
        -name: string
        +setupTables(): void
        +addMenuItems(): void
    }
    class Menu {
        +items: Map~string, string~
        +add(itemName: string, description: string): void
        +remove(itemName: string): void
    }
    class Table {
        -number: int
        -status: string
        -- Reservation : 0..1
        +reserve(reservation: Reservation): void
        +clear(): void
    }
    class Reservation {
        -date: Date
        -time: Time
        -partySize: int
        *-- Table : 1
        +makeReservation(table: Table, date: Date, time: Time, partySize: int): void
    }
    class Order {
        +items: List~string~
        +totalAmount(): decimal
        +add(itemName: string): void
        +remove(itemName: string): void
    }
    class Chef {
        -specialities: List~string~
        +assignToTable(table: Table): void
        +prepareOrder(order: Order): void
        +serveDish(itemName: string, table: Table): void
    }
```