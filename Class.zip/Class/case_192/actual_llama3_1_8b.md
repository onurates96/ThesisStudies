```mermaid
classDiagram
    class Restaurant {
        +string name
        +list Menu
        +list Table
        +list Reservation
        +list Order
    }
    
    class Menu {
        -int id
        +string name
        +float price
    }
    
    class Table {
        -int id
        +bool isReserved
    }
    
    class Reservation {
        -int id
        +datetime date
        +Reservation customer : has_reservation
    }
    
    class Order {
        -int id
        +list MenuItem
        +datetime placedAt
        +Order chef : has_assigned_chef
    }
    
    class Chef {
        -int id
        +string name
        +Order orders : has_assigned_orders
    }
    
    Restaurant "*" --* Menu : contains
    Menu "*--" * Table : is_on
    Table "1" --> "*" Reservation : reserved_at
    Reservation "-->" Order : belongs_to
    Order "0..*" --> MenuItem : includes
    Order "--" Chef : assigned_chef
```