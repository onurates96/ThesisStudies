```mermaid
classDiagram
    class Account {
        +string accountNumber
        +decimal balance
        -list<Transaction> transactionHistory
        +deposit(amount:decimal) void
        +withdrawal(amount:decimal) void
    }
    class Customer {
        +string name
        +string id
        -Account account
        +openAccount(account:Account) void
    }
    class Transaction {
        +long id
        +DateTime timestamp
        +Account fromAccount
        +Account toAccount
        +decimal amount
        -Customer customer
    }
    class Loan {
        +string loanId
        +Account account
        +decimal principal
        +decimal interestRate
        +boolean isPaidOff
        +PaymentPlan paymentPlan
    }
    class ATM {
        +String location
        -List<Account> accessibleAccounts
        +processTransaction(transaction:Transaction) void
    }
    Customer "1" --> "*" Account : has
    Account --> "1" * Transaction : records
    Account <|-- Loan : specializes
    ATM --> * Account : accesses
```