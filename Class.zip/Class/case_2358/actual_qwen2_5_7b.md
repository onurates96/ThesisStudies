```mermaid
classDiagram
    class Account {
        +string accountNumber
        -decimal balance
        +deposit(amount: decimal) void
        +withdraw(amount: decimal) void
    }
    class Customer {
        +string name
        +string address
        o-- Account : has
    }
    class Transaction {
        +datetime date
        +decimal amount
        --> Account : related to
    }
    class Loan {
        -decimal loanAmount
        +repay(amount: decimal) void
        -- Customer : belongs to
    }
    class ATM {
        +string location
        *-- Transaction : performs
    }
```