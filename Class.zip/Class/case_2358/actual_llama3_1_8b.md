```mermaid
classDiagram
    class Account {
        +string accountNumber
        +decimal balance
        +Customer customer
        +Transaction transaction
        -login() bool
        -logout() void
    }
    class Customer {
        +string name
        +string address
        +Account account
        +Loan loan
        +ATM atm
        +deposit() decimal
        +withdrawal(decimal) decimal
    }
    class Transaction {
        +decimal amount
        +datetime date
        +Account account
        +Customer customer
        -initiateTransaction() void
    }
    class Loan {
        +decimal amount
        +int interestRate
        +Account account
        +Customer customer
        -applyForLoan() bool
    }
    class ATM {
        +string location
        +Customer customer
        -withdrawCash(decimal) decimal
    }
    Customer "1" --> "*" Account : hasManyAccounts
    Customer <-- "0..n" Transaction : hasTransactions
    Account <-- "0..n" Transaction : hasTransactions
    Customer "1" --> "1..*" Loan : hasLoans
    ATM -- Customer : usesAccount
```