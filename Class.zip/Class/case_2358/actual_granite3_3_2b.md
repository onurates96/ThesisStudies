```mermaid
classDiagram
    class Account {
        +string accountNumber
        +string accountHolderName
        +decimal balance
        +void deposit(decimal amount)
        +void withdraw(decimal amount)
    }

    class Customer {
        +string name
        +Account account
        +Address address
        +void setAccount(Account acc)
        +Account getAccount()
    }

    class Transaction {
        +decimal amount
        +date date
        +string description
        +Account debit
        +Account credit
    }

    class Loan {
        +string loanID
        +Customer customer
        +decimal principal
        +decimal interestRate
        +void applyInterest()
    }

    class ATM {
        +void dispBalance(Account acc)
        +void deposit(Transaction t, Account acc)
        +void withdraw(Transaction t, Account acc)
    }

    Account "1" --> "1" Customer
    Loan "1" --> "1" Customer
    Transaction "1" --> "1" Customer
    ATM "1" "1..*" Loan
```