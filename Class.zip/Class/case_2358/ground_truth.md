classDiagram
    class Account {
        +int AccountNumber
        string Type
        double Balance
    }
    class Customer {
        +int CustomerID
        string Name
        string Address
    }
    class Transaction {
        +int TransactionID
        int AccountNumber
        double Amount
        Date TransactionDate
        string Type
    }
    class Loan {
        +int LoanID
        int CustomerID
        double Amount
        double InterestRate
    }
    class ATM {
        +int ATMID
        string Location
    }
    Customer --> Account : owns
    Account --> Transaction : makes
    Customer --> Loan : applies
    ATM --> Transaction : processes