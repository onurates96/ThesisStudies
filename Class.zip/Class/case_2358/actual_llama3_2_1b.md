```mermaid
classDiagram
    Account : +string owner 
    Customer : *(+int age) *:isMammal() 
    Loan : *(+float interestRate) *:mustBe >= 0 : deposit (+decimal) void 
    Transaction : +(+int amount) *:inBankBranch ?* (+string description) void
    ATM : +string pin : *(+int accountNumber) ->* (+int balance) void
    classD : (Loan, Customer) Inheritance
    classE : (Transaction, Loan) Composition
    classF : (ATM, Loan) Aggregation
classBankAccount : (Customer)
classStudent : (Course)
classGalaxy : (Star)
```