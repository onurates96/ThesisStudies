```mermaid
classDiagram
    class Account <|-- Customer
        class Account : +string accountNumber, -string firstName, -string lastName, -money balance
        Customer : +string name
        Customer : -string address
    class Customer "1" --> "*" Customer 2: +string contactInfo
    class Loan "1" --> "*" Loan 3: +money principal, -string interestRate
    class Account "1" --> "*" Customer 4: +string accountNumber, -string firstName, -string lastName, -money balance
    class Loan "1" : +string borrower, -string amount:loanPrincipal
```