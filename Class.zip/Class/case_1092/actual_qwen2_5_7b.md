```mermaid
classDiagram
    class Account {
        -balance: decimal
        +deposit(amount: decimal) void
        +withdraw(amount: decimal) void
    }
    class Customer {
        +accounts: Account[]
        +openAccount() Account
        +closeAccount(account: Account) void
    }
    class Transaction {
        -amount: decimal
        -account: Account
        +processTransaction() void
    }
    class BankManager {
        +managesATMs: ATM[]
        +addATM(atm: ATM) void
        +removeATM(atm: ATM) void
    }
    class ATM {
        +bankManager: BankManager
        +dispenseCash(amount: decimal) void
    }
    Customer "1" -- "*" Account : owns
    Transaction "0..*" -- "1" Account : involves
    BankManager "1" -- "*" ATM : manages
```