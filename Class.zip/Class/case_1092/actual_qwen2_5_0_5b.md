```mermaid
classDiagram
class Account <|-- Customer
Account : +string owner, -int balance
Customer : +string name, -decimal balance
Transaction : +TransactionID :+amount:+transactionDateTime: Customer ID: Customer : -string type, *-string message, -date dateOfTransaction, -string customerID

BankManager <|-- ATM
ATM : +string accountNumber, *-- ATM : +Account "1" : -string operator, -string password, -int PIN

Customer :
    Member "1" : CustomerID, **Member** "2" : ContactInformation

Transaction :
    Member "1" : AccountID, Member "2" : Amount
```

This Mermaid class diagram visualizes a banking system with classes like 'Account', 'Customer', and 'Transaction'. It includes relationships such as 'Customer owns Account' and 'Transaction involves Account', as well as 'Bank Manager manages ATM'. The code block starts with `classDiagram` and does not include any additional text outside the block.