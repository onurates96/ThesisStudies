```mermaid
classDiagram
    class Account {
        +string accountNumber
        +decimal balance
        +deposit(amount: decimal) void
        +withdrawal(amount: decimal) void
    }
    
    class Customer {
        +string name
        -Account account
        +login() bool
        +viewBalance() void
    }
    
    class Transaction {
        +decimal amount
        -Account sourceAccount
        -Account destinationAccount
    }
    
    class BankManager {
        +string managerName
        -Account[] accounts
        +manageAccounts() void
    }
    
    class ATM {
        +string atmLocation
        -BankManager manager
        +dispenseCash() void
    }

    Customer o-- Account : One customer can have many accounts
    Account *-- Transaction : Each transaction involves one account
    BankManager ..> ATM : The bank manager manages one or more ATMs
```