```mermaid
classDiagram
    class Customer "1" --> "*": owns Account
    class Account {
        +string accountNumber
        +decimal balance
        -Customer owner
    }
    class Transaction {
        +Account fromAccount
        +Account toAccount
        +decimal amount
    }
    class BankManager {
        +List~Transaction~ managedTransactions
    }
    class ATM {
        +BankManager manager
        -List~Transaction~ recentTransactions
    }
```