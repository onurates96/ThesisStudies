```mermaid
classDiagram
    class Account {
        +owner: string
        +balance: decimal
        +deposit(amount:decimal) void
        +withdrawal(amount:decimal) void
    }
    
    class Customer {
        +name: string
        +email: string
        +password: password
        +account: Account
    }
    
    class Transaction {
        +amount: decimal
        +type: string
    }
    
    class BankManager {
        +id: integer
        +name: string
        +balance: decimal
    }
    
    class ATM {
        +id: integer
        +bankId: integer
        +accountNumber: integer
    }
```