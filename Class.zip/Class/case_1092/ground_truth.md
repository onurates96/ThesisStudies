classDiagram
  Class Account {
    - accountId
    - balance
    + deposit()
    + withdraw()
  }
  Class Customer {
    - customerId
    - name
    + openAccount()
    + closeAccount()
  }
  Class Transaction {
    - transactionId
    - amount
    + process()
  }
  Class BankManager {
    - managerId
    - name
    + manageATM()
  }
  Class ATM {
    - atmId
    + withdrawCash()
  }
  Account <|-- Customer
  Account <|-- Transaction
  BankManager <-- ATM