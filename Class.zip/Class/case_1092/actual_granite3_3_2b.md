```mermaid
classDiagram
    class Account {
        +string accountNumber
        +decimal balance
        +deposit(amount:decimal) void
        +withdrawal(amount:decimal) void
    }
    class Customer {
        +string name
        +Account account : owns
    }
    class Transaction {
        +string description
        +decimal amount
        +Account sender : uses
        +Account receiver : uses
    }
    class BankManager {
        +string name
        +string password : secret
        +ATM atm : manages
    }
    class ATM {
        +string location
        +BankManager manager : oversees
    }
```