```mermaid
classDiagram
    Car {
        +string color
        +string model
        +bool isAvailable()
    }
    Customer {
        +string name
        -string password
        +makeReservation(Car) void
    }
    RentalAgency {
        +string name
        +list<Reservation> reservations
        +addCar(Car) void
    }
    Reservation {
        +Customer customer
        +Car car
        +datetime startDate
        +datetime endDate
        +calculateTotal() decimal
    }
    Payment {
        +decimal amount
        +PaymentMethod paymentMethod
        +processPayment() void
    }
    PaymentMethod {
        -string type
        -PaymentDetails details
        +getDetails() string
    }
    Insurance {
        +datetime startDate
        +datetime endDate
        +calculatePremium() decimal
    }
    Car "1" *-- RentalAgency : Car is owned by Agency
    Customer "1" --> "* Reservation : A customer makes many reservations
    RentalAgency o-- Reservation : An agency manages many reservations
    Car -- Customer : A car is rented by a single customer
    Reservation <-- Payment : A reservation requires a payment
    Payment ..> Insurance : Insurance is required for payments
```