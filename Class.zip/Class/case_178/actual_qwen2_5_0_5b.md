```mermaid

classDiagram

  Customer <|-- "1" --* Ticket
  Customer *--"* Ticket
  Customer <|-- "1..*" --* Ticket
  Student <|-- "1" --* Course
  Student <|-- "1..*" --* Course
  Galaxy <|-- "*" Star : contains Galaxy "1"

```