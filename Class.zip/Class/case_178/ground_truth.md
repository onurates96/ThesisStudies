classDiagram;
  class Car {
    +carId: String
    +make: String
    +model: String
    +year: Int
    +dailyRate: Float
  }
  class Customer {
    +customerId: String
    +name: String
    +email: String
  }
  class Rental_Agency {
    +agencyId: String
    +name: String
    +location: String
  }
  class Reservation {
    +reservationId: String
    +customerId: String
    +carId: String
    +pickupDate: Date
    +returnDate: Date
  }
  class Payment {
    +paymentId: String
    +reservationId: String
    +amount: Float
    +paymentDate: Date
  }
  class Insurance {
    +insuranceId: String
    +reservationId: String
    +coverageDetails: String
  }
  Car "1" -- "*" Reservation: availableFor;
  Customer "1" -- "*" Reservation: makes;
  Rental_Agency "1" -- "*" Reservation: manages;
  Reservation "1" -- "1" Payment: requiresPayment;
  Reservation "1" -- "1" Insurance: includesInsurance;