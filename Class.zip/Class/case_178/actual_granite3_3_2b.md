```mermaid
classDiagram
    class Car {
        +string color
        +int year
        +boolean isAvailable
        +float rentalRate
        +RentalAgency agency
    }
    class Customer {
        +string name
        +string contactInfo
        +list<Reservation> reservations
    }
    class RentalAgency {
        +string name
        +float managementFee
        +list<Car> vehicles
    }
    class Reservation {
        +string customerID
        +Car car
        +date rentalDate
        +date returnDate
        +float totalPrice
    }
    class Payment {
        +string amount
        +Customer customer
        +Reservation reservation
        +date paymentDate
    }
    class Insurance {
        +string policyNumber
        +Customer customer
        +Car car
        +float coverageAmount
    }

    Car <|-- RentalAgency
    Customer "1" --> "*" Reservation
    RentalAgency *-- Car
    Payment "1" --> Reservation
    Insurance *--> Car
    Payment "1" -- Customer : uses
```