```mermaid
classDiagram
    class Car {
        +classType String: licensePlateNumber
        +classType Integer: year
        +classType Boolean: isAvailable
    }
    
    class Customer {
        +classType String: firstName
        +classType String: lastName
        +classType Boolean: isRenting
    }
    
    class RentalAgency {
        +classType String: agencyName
        +classType Integer: numRentalCarows
    }
    
    class Reservation {
        +classType Customer: customer
        +classType Car: car
        +classType Date: reservationDate
    }
    
    class Payment {
        +classType Customer: customer
        -classType Money: paymentAmount
        +classType Boolean: isPaid
    }
    
    class Insurance {
        +classType Car: insuredCar
        +classType Number: insurancePremium
    }
    
    class CarRentalSystem {
        +classType RentalAgency: agency
        +classType Customer: customer
        +classType Reservation: reservation
        +classType Payment: payment
        +classType Insurance: insurance
        
        -classType Car: car
        
        +classType Availability {
            +classType Date: checkInDate
            +classType Date: checkOutDate
            
            +classType Map{ 
                +keyString: carLicensePlateNumber
                +valueClassType Car:
                    classType String: licensePlateNumber
                    classType Integer: year
                    classType Boolean: isAvailable
            }
        }
    }
```