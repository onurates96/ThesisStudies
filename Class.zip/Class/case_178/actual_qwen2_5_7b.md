```mermaid
classDiagram
    class Car {
        +string model
        +int year
        -List~Reservation~ reservations
    }
    class Customer {
        +string name
        +string contactInfo
        -List~Reservation~ reservations
    }
    class RentalAgency {
        +string agencyName
        +List~Car~ carsForRent
        *-- "0..*" Reservation
        -- "1" Insurance : covers
    }
    class Reservation {
        +Customer customer
        +Car car
        -Date startDate
        -Date endDate
    }
    class Payment {
        +decimal amount
        +string method
        -Reservation reservation
    }
    class Insurance {
        +string insurerName
        +string policyNumber
    }
    Car --> "0..*" Reservation : has
    Customer --> "1" Reservation : makes
    RentalAgency *-- "1" Car : owns
    Reservation -- "1" Payment : includes
    RentalAgency ..> Insurance : provides
```