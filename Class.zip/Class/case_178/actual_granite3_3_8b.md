```mermaid
classDiagram
    class Car {
        +int id
        +string model
        +int year
        -List~int~ available
        +void checkAvailability() void
        +void rent(Customer c) void
    }
    class Customer {
        +string name
        +string address
        +string contactInfo
        +List~Reservation~ reservations
    }
    class RentalAgency {
        +string agencyName
        +List~Car~ cars
        +List~Reservation~ bookings
    }
    class Reservation {
        +Customer customer
        +Car car
        +Date start
        +Date end
        +Payment payment
        -Insurance insurance
    }
    class Payment {
        +float amount
        +Date date
        +string method
    }
    class Insurance {
        +string type
        +float coverageAmount
        +boolean active
    }
    Car <|-- "1" Reservation : rentsCar
    Customer "1" --> "*" Reservation : makesReservations
    RentalAgency "1" *--> "n" Car : managesCars
    RentalAgency "1" *--> "n" Reservation : recordsBookings
    Reservation "1" --> "1" Payment : hasPaymentDetails
    Reservation "0..1" --> "1" Insurance : mayHaveInsurance
```