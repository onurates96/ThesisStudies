```mermaid
@end

class Diagram: ClassA {
  +string username
  +int age
}
```