```mermaid
classDiagram
    class User
        +int id
        +string name
        +string email
        +List~string~ posts
        +List~Comment~ comments
        +List~Friend~ friends
        +List~Group~ groups
    class Post
        -int postId
        -User author
        -string content
        +List~Comment~ comments
    class Comment
        -int commentId
        -User author
        -Post post
        -string text
    class Friend
        *-- User friend
    class Group
        *-- User member
```