```mermaid
classDiagram
    class User {
        +string username
        +string email
        -bool is_admin
        +login() bool
        +postMessage(post:Post) void
        +addFriend(friend:User) void
    }
    class Post {
        +string content
        +int likes "0..*"
        +publish(user:User) void
        -- Comment *-- Post : comments
    }
    class Comment {
        +string text
        -User user
        +replyTo(comment:Comment) void
    }
    class Friend {
        +User user1
        +User user2
        +acceptFriendship() void
        o-- User : friendship
    }
    class Group {
        +string name
        *-- User : members
        -- Post *-- Group : posts
    }
    User --> "0..*" Post : creates
    Comment --> "0..*" User : postedBy
    Friend <|-- User : friendsWith
    Group o-- "1" User : owns
```