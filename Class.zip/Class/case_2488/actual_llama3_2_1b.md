```mermaid
classDiagram
    class User {
        +username: string
        -email: string
        +password: string
    }
    class Post {
        +id: int
        +title: string
        +content: string
        -author: User
        +created_at: datetime
    }
    class Comment {
        +id: int
        +post_id: int
        +text: string
        +created_at: datetime
        -user: User
    }
    class Friend {
        +id: int
        +other_user_id: int
        -status: boolean (0 = friend, 1 = blocked)
        +joined_at: datetime
    }
    class Group {
        +id: int
        +name: string
        -members: User[]
        +created_at: datetime
    }
```