classDiagram
    class User {
        +int UserID
        string Name
        string Email
        Date JoinDate
    }
    class Post {
        +int PostID
        int UserID
        string Content
        Date PostDate
    }
    class Comment {
        +int CommentID
        int UserID
        int PostID
        string Content
        Date CommentDate
    }
    class Friend {
        +int FriendID
        int UserID
        int FriendUserID
    }
    class Group {
        +int GroupID
        string Name
        string Description
    }
    User --> Post : creates
    Post --> Comment : has_comments
    User --> Friend : has_friends
    User --> Group : member_of