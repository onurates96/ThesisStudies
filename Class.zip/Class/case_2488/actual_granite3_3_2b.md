```mermaid
classDiagram
    class User {
        +string name
        +string email
        +string password
        +Date birthDate
        +string bio
        +List<Post> posts
        +Map<String, Comment> comments
        +Set<Friend> friends
        +Set<Group> groups
    }

    class Post {
        +string content
        +User creator
        +Date created_at
        +List<Comment> comments
        * likes
    }

    class Comment {
        +string text
        +User creator
        +Post post
        +Date created_at
    }

    class Friend {
        +User user
        +User friend
    }

    class Group {
        +String name
        +List<User> members
        +List<Post> posts
        +List<Comment> comments
    }

    User "1" "--* Friend : has
    Friend "1" "--* Friend : mutual
    User --> Group : forms
    Group -- User : member
    Post <-- Comment : has_comments
    Comment --> Post : posted_to
    Friendship "1" "--1 Friend : one_to_many
    Group "1" "0..*" User : members
```