```mermaid
classDiagram
    class User {
        +string name
        +int age
        +login() bool
    }
    class Post {
        -int id
        -string content
        +replyTo(Post) void
    }
    class Comment {
        -int id
        -string text
        +post(Post)
    }
    class Friend {
        +User user1
        +User user2
        +request(Friend) bool
    }
    class Group {
        +string name
        +User owner
        +addMember(User) void
    }
    User <|-- Post : A post is created by a user.
    Post --> Comment : A comment is added to a post.
    Friend *-- User : A friend request is made from one user to another.
    Group o-- User : A group contains multiple users.
```