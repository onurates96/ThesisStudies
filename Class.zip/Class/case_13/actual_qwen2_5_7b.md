```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +int yearPublished
        -borrow(member: Member) void
        +return() void
    }
    class Member {
        +string name
        +string address
        -borrow(book: Book) void
        +return(book: Book) void
    }
    class Librarian {
        +string name
        +string contactInfo
        -addBook(book: Book) void
        -removeBook(book: Book) void
        -manageInventory() void
    }
    Book --> Member : Borrow
    Member --> Book : Return
    Librarian *-- Book : Manage Inventory
```