```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +int yearPublished
        +bool isAvailable
        +void borrow(Member member)
        +void returnBook(Librarian librarian)
    }
    class Member {
        +string name
        +string id
        +void borrow(Book book)
        +void returnBook(Book book)
        +void updateProfile(string newInfo)
    }
    class Librarian {
        +string name
        +string id
        +void manageInventory(Book book)
        +void processReturn(Member member, Book book)
        +void processBorrow(Member member, Book book)
    }
    Book "1" -- "*" Member : Borrow
    Member "1" -- "*" Book : Return
    Librarian "1" -> "*" Book : Manage Inventory
```