```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +date publishedDate
        +void borrow(Member member)
        +void returnMember(Member member)
    }
    class Member {
        -string memberId
        -string name
        -string email
        -bool isSubscriber
        +void login()
        +void logout()
        +void payMembershipFee()
    }
    class Librarian {
        +string librarianId
        +string name
        +string role
        +void manageInventory(Book book)
        +void issueBook(Member member, Book book)
        +void takeBackBook(Member member, Book book)
    }
    Book *-- Member : Borrow
    Member --> Librarian : Manage Inventory
```