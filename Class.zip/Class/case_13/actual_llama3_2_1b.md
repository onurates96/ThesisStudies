```mermaid
classDiagram
    class Library {
        +members: list member;
        +books: list book;
        +staff: list librarian;
    }
    
    class Book {
        +id: string id;
        +title: string title;
        +author: string author;
        +borrowedBy: list member;
        +returnDueDate: date returnDueDate;
    }
    
    class Member {
        +id: int id;
        +name: string name;
        +email: string email;
        +balance: float balance;
        +borrowBooks: bool borrowBooks
    }
    
    class Librarian {
        +classDiagram
            class A : inherits B {
                +classB: extends Member;
            }
            class C { *-- classD: composed by classC; }
            class E: aggregation classF: association with classE;
            class G: solid classH: dependency on classG; 
            class I: realization of classJ: dependency on classI;
            class K: dashing link on classL: dependency on classK; 
            class L: realization of classM: dependency on classL;
            class O: link on classP: depends on classO;
        }
    }
    
    class Inventory {
        +classDiagram
            class Book { *-- inventory : holds* books; }
            class StudentCard : inventory : holdsStudentCards;
            class LibraryCard : inventory : holdsLibraryCards;
        }
```