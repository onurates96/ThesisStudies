```mermaid
mermaid

    @end
```

    classDiagram
        <|>
```