```mermaid
classDiagram
    class Book{
        +string title
        +string author
        +int yearOfPublication
        -bool isAvailable
        +addBook() void
        +removeBook() void
        +manageInventory() void
    }
    class Member{
        +string memberId
        +string name
        +Book borrowedBook "0..*"
    }
    class Librarian{
        +string librarianId
        +string name
        +Book manageBooks "*"
    }
    Book --> "borrow" Member : has
    Book --> "lend" Member : isBorrowedBy
    Librarian --> "manage" Book : handlesInventory
```