classDiagram
  class Book {
    + title
    + author
    + ISBN
    + availability
    + checkOut()
    + checkIn()
  }
  class Member {
    + name
    + memberID
    + borrow()
    + return()
  }
  class Librarian {
    + name
    + staffID
    + manageInventory()
  }

  Book <-- borrow
  Book <-- return
  Librarian <-- manageInventory