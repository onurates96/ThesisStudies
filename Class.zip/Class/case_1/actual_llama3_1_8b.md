```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +bool available
        +borrow(Member) void
        +return(Member) void
        +reserve(Member) void
    }
    class Member {
        +string name
        -string password
        +login() bool
        +borrow(Book) void
        +return(Book) void
        +reserve(Book) void
    }
    class Librarian {
        +string name
        #password string
        +manageInventory() void
    }
    Book <|-- Member : Borrow
    Book <-- Librarian : Manage Inventory
    Member *-- Book : Holds multiple books
    Librarian o-- Member : Can manage members
```