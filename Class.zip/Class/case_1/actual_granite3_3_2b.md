```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +int yearPublished
        +void borrow(Member member)
        +void returnBook(Librarian librarian)
    }
    class Member {
        +string name
        +string id
        +void borrowBook(Book book)
        +void returnBook(Book book)
    }
    class Librarian {
        +string name
        +string id
        +void manageInventory()
    }
```