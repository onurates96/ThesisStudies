```mermaid
classDiagram
    class Book {
        +string title
        +string author
        -int isbn
        +borrow(member: Member) void
        +return() void
        +reserve(librarian: Librarian) void
    }
    class Member {
        +string name
        +string contact
        -List~Book~ borrowedBooks
        +borrow(book: Book) void
        +return(book: Book) void
    }
    class Librarian {
        +string name
        +string contact
        +manageInventory() void
        o-- Book book: 1
    }
    Book --> Member : borrow, return
    Book --> Librarian : reserve ..>
    Member -- Librarian : manageInventory --|
```