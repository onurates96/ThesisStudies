```mermaid
classDiagram
    class Book{
        +string title
        +string author
        +int publicationYear
        -boolean isAvailable
        +reserve() void
        +return() void
    }
    class Member{
        +string name
        +string memberID
        +Book reserve()
        -Book returnedBook
    }
    class Librarian{
        +string name
        +string librarianID
        +ManageInventory manageInventory()
    }
    Member "1" --> "1..*" Book : borrows
    Librarian "1" --> "*" Book : manages
    Book --> Librarian : managedBy
```