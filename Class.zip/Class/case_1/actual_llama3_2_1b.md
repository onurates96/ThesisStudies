```mermaid
classDiagram
    class Book {
        +title String
        +author String
        +genre String
        -borrowed bool
        +returnDate String
    }
    class Member {
        +name String
        +age int
        +gender String
        +isMammal bool
        +mate Person?: void
        +book?: Book?: void
    }
    class Librarian {
        +id int
        +name String
        +position String
        +contact Info?: void
        +manage Inventory: [Book!] void
    }
    class Manager {
        +id int
        +name String
        +position String
        +contact Info?: void
        +assignMember: [Member!] void
        +manageStaff: [Person!] void
    }
class Book{
    -title String
    -author String
}
class Member{
    -name String
    -age int
}
class Librarian {
    -id int
    -name String
    -position String
}
class Manager {
    -id int
    -name String
}
class Card {
    +number Int
    +expiration Date
    +holder Name: String
    - issued At: DateTime
}
class BankAccount{
    +accountNumber String
    +owner Name: String
    +balance Double
    +deposit(amount : double) void
    +withdrawal(amount : double) void
}

class Transaction {
    +date Date
    +type String
    +amount Double
    +description String
}
```