```mermaid
classDiagram
    class Library {
        +string name
        -List~Book~ books
        -List~Member~ members
        -List~Transaction~ transactions
        manageTransaction(T: Transaction) void
    }
    class Book {
        +string title
        +int yearPublished
        -Library library
    }
    class Member {
        +string name
        -List~Book~ borrowedBooks "0..*"
        -Fine fine "0..1"
        borrowBook(B: Book) bool
        payFine(amount: int) void
    }
    class Librarian {
        +string name
        -Library library
        manageTransaction(T: Transaction) void
    }
    class Transaction {
        +Book book
        +Member member
        -Date borrowDate
        -Date returnDate "0..1"
        extendBorrowPeriod(days: int) bool
    }
    class Fine {
        +int amount
        -Member member
    }
    Library *-- Book : contains
    Library -- Member : managesLibrary
    Library -- Librarian : employs
    Member --> Book : borrows
    Librarian --> Transaction : manages
    Member ..> Fine : hasFine
```