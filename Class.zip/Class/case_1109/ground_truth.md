classDiagram
  Class Book
  Class Member
  Class Librarian
  Class Library
  Class Transaction
  Class Fine
  Book <|-- Library
  Member -- Transaction
  Member -- Fine