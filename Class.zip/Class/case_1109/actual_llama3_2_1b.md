```mermaid
classDiagram
    class Member {
        +id: int
        +name: string
        -borrowedBooks: Book[]
        +fine: Decimal
        +age: int
        +gender: string
        +isMammal(): bool
        +mate(): void
        +login(): bool
    }
    
    class Book {
        +id: int
        +title: string
        +author: string
        -borrowedBy: Member[]
        +borrowDate: DateTime
    }
    
    class Transaction {
        +id: int
        +bookId: int
        +dueDate: DateTime
        +fineAmount: Decimal
    }
    
    class Fine {
        +id: int
        +amount: Decimal
        -associatedWith: Member[]
        +dueDate: DateTime
    }
```