```mermaid

    return;
    
    classDiagram
    
        Book <|-- Library
        Member : +string name
        Librarian : +int age
        Library : +list Books
        Transaction : +string description
        
        Member : +isMember()
        Transaction : -isTransaction()
        
        Fine : *-- 1, "n" (Note: n refers to "not applicable") --> "1..*" : *-- Quantity
        
```