```mermaid
classDiagram
    class Book{
        +string title
        +string author
        +int publicationYear
        -bool isAvailable
    }
    class Member{
        +string name
        +string memberId
        +List~Book~ borrowedBooks "0..*"
    }
    class Librarian{
        +string name
        +string librarianId
        +List~Transaction~ managedTransactions "*"
    }
    class Library{
        +string address
        +int totalBooks "n"
        +List~Book~ bookCollection "*"
        -List~Fine~ fineList "*"
    }
    class Transaction{
        +DateTime transactionDate
        +Member borrower
        +Librarian librarian
        +Book book
        +string status
    }
    class Fine{
        +double amount
        +Member member "1"
        +Transaction transaction "..> "
    }
    Member "1" --> "*" Transaction : borrows
    Librarian manages Transaction
    Fine associated with Member
```