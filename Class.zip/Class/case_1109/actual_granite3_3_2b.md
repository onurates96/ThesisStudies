```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +int yearPublished
        +boolean isAvailable
    }
    class Member {
        +string name
        +string memberID
        +string email
        +Book borrowedBook
        -int overdueDays
    }
    class Librarian {
        +string name
        +Book favoriteBook
        +int totalFines
        +Member managerMembers : 1..*
    }
    class Library {
        +string name
        +Librarian librarian
        +Book collection : Book
        +Member membership : Member
    }
    class Transaction {
        +Member borrower
        +Book bookBorrowed
        +date transactionDate
        +float amountDue
    }
    class Fine {
        +int amount
        +Transaction transaction
        +Member member : 1..*
    }

    Library "1" "-- Librarian : 1.."
```