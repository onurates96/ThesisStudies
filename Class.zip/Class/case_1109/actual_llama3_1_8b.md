```mermaid
classDiagram
    class Book {
        +string title
        +int publicationYear
    }
    class Member {
        +string name
        -string address
        +login() bool
        +borrow(Book) void
    }
    class Librarian {
        +string name
        #string libraryName
        +manage(Transaction) void
    }
    class Library {
        +string name
        *Transaction* transactionList
        +addBook(Book) void
    }
    class Transaction {
        -string date
        -Member member
        -Book book
        -Fine fine
        +complete() void
    }
    class Fine {
        -string type
        -int amount
        -Member member
        +calculate() void
    }

    Member --> "1" Book : borrows
    Librarian ..> Transaction : manages
    Library o-- Transaction : has
    Transaction --> "-1" Fine : associatedWith
```