```mermaid
classDiagram
    class User {
        +string username
        -string password
        +post() void
        #getProfile() object
    }
    class Post {
        +string content
        -User author
        +comment() void
        +like() void
    }
    class Comment {
        +string text
        -Post post
        -User author
    }
    class Like {
        -User user
        -Post post
    }
    class Friendship {
        -User user1
        -User user2
    }
    User --> "0..*" Post : posted
    Post --> "0..*" Comment : commented
    Post -- "0..*" Like : liked
    User *-- "0..*" User : friends
```