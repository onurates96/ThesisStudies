```mermaid
classDiagram
    class User {
        +string username
        +string email
        +string password
        +List<Post> posts
        +Map<String, Comment> comments
        +Set<Like> likes
        +List<Friendship> friendships
    }
    class Post {
        +string content
        +User author
        +Date creationDate
        *Comment comments
        +List<Like> likes
    }
    class Comment {
        +string text
        +User creator
        +Post post
        +Date creationDate
        ..> Like likes
    }
    class Like {
        +User giver
        +User receiver
        +Post post
        ..Realization reaction
    }
    class Friendship {
        +User friend1
        +User friend2
    }

    User "1" "--*-- Post : creates
    User "--*-- Comment : commentsOn
    User "--*-- Like : likes
    Post "--*-- Comment : has
    Post "--*-- Like : has
    User "--*-- Friendship : friendsWith
```