```mermaid
mermaid

    User (u) --**-Post()-- Post()
    User (u) --**-Comment()-- Comment(u, _id)
    User (u) --**-Like()-- Like(user=u, post=Post(_id))
    User (u) --**-Friendship()-- Friendship(user1=u, user2=Friendship())
```

In this Mermaid class diagram:

1. We start with the `classDiagram` header.
2. We declare four classes: `User`, `Post`, `Comment`, and `Like`.
3. The relationships between these classes are represented using solid lines.

Each relationship has a different class name in the top part of the diagram:
- User (u) connects to Post()
- User (u) connects to Comment(u, _id)
- User (u) connects to Like(user=u, post=Post(_id))
- User (u) connects to Friendship(user1=u, user2=Friendship())

Each relationship also has a different class name in the bottom part of the diagram:
- User (u) connects to Post(), Comment(u, _id)
- User (u) connects to Like()
- User (u) connects to Friendship()

The relationships are represented with solid lines that run between classes. Each line represents an instance of a relationship.
```mermaid
```