classDiagram;
  class User {
    +userId: String
    +username: String
    +email: String
  }
  class Post {
    +postId: String
    +userId: String
    +content: String
    +timestamp: DateTime
  }
  class Comment {
    +commentId: String
    +postId: String
    +userId: String
    +content: String
    +timestamp: DateTime
  }
  class Like {
    +likeId: String
    +postId: String
    +userId: String
    +timestamp: DateTime
  }
  class Friendship {
    +friendshipId: String
    +userId1: String
    +userId2: String
    +since: DateTime
  }
  User "1" -- "*" Post: makesPosts;
  Post "1" -- "*" Comment: hasComments;
  Post "1" -- "*" Like: hasLikes;
  User "1" -- "*" Friendship: hasFriends;