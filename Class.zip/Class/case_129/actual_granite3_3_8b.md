```mermaid
classDiagram
    class User {
        +string username
        +string passwordHash
        +List~int~ followedUsers
        +List~Post~ posts
        +List~Comment~ comments
        +List~Like~ likes
        -List~User~ friends
    }
    class Post {
        +string content
        +User author
        +List~Comment~ comments
        +List~Like~ likes
    }
    class Comment {
        +string text
        +User user
        +Post post
    }
    class Like {
        +User user
        +Post post
    }
    class Friendship {
        +boolean accepted
        -User fromUser
        -User toUser
    }
```