```mermaid
graph LR
    title Contract for Class Diagram for Social Media Platform
    User--> Post[Post]-(Comment)
    Comment--> Post[Comment]
    Post--> Friend[Friendship]
    Friendship--> User[User]

    classDiagram    
        class User { +string name, int age+ string gender+, bool isMammal+ +List[int+] +List<string> genders+: true
            class Post { +int id, int userId: -postText-, bool isPublic+: false, +List[Comment] comments: +int userId: -1+
                class Comment { +int id, int postId: -commentText-, -postUser: -userId-
                    comment: +
                    class Friendship { +int friendId: -friendUser: -userId+}
                }
            }

        class Post { +id: int, title: string, content: string
            +int userId : -user_id- +isPublic+: false
        }

        class Comment { +id: int, userId: int, text: string
            -user_id- -> +userId-
        }

        class Friendship { +friendId: int, friendUser: int }
    ```