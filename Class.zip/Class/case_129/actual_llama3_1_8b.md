```mermaid
classDiagram
class User {
    +string id
    -string password
    +bool isAdmin
}
class Post {
    +string content
    -User author : authorOfPost
    0..* Comment comments : commentOnPost
    0..* Like likes : likeOnPost
}
class Comment {
    +string text
    -Post post : commentedOnPost
    User author : commenter
}
class Like {
    +bool isPositive
    -Post post : likedPost
    User user : liker
}
class Friendship {
    +boolean isMutual
    -User user1 : friendA
    -User user2 : friendB
}
```

This code block represents a Mermaid UML class diagram for a social media platform with the specified classes, relationships, and attributes.