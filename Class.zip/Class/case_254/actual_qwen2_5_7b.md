```mermaid
classDiagram
    class User {
        +string username
        +string password
        -List~Review~ reviews
        +addReview(product:Product, rating:int, comment:string) void
    }
    class Product {
        +string name
        +decimal price
        -User seller
        *ShoppingCart cartItems
        +addToCart(user:User) void
    }
    class ShoppingCart {
        +List~Product~ items
        +addProduct(product:Product) void
    }
    class Order {
        +List~OrderItem~ orderItems
        -User customer
        "1" --> "1..*" Payment : placedWith
    }
    class OrderItem {
        +Product product
        +decimal quantity
    }
    class Payment {
        +string paymentMethod
    }
    class Review {
        +int rating
        +string comment
        -User reviewer
    }
    User -- Product : reviews
    Product *-- ShoppingCart : contains
    ShoppingCart *-- OrderItem : contains
    Order "1" --> "0..*" Payment : placedWith
    OrderItem --> Product : contains
    Review o-- User : writtenBy
```