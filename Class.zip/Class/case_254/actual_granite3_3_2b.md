```mermaid
classDiagram
    class User {
        +string name
        +string email
        +string password
        +string address
        +string phone
        +date birthDate
        +Status status
        ++setPassword(password: string)
        +bool checkEmail(email: string): boolean
        +bool enrollInProgram(program: Program): boolean
    }

    class Product {
        +int id
        +string name
        +string description
        +float price
        +Category category
        +Image image
        ++getImageURL(): String
    }

    class ShoppingCart {
        +User user
        +List<Product> products = []
        +int quantity
        +() addToCart(product: Product): void
        +void removeFromCart(product: Product): void
        +int getQuantity(product: Product): int
    }

    class Order {
        +ShoppingCart cart
        +User user
        +Date placedAt
        +float totalAmount
        +() placeOrder(): void
        +void updateStatus(string status: string): void
    }

    class Payment {
        +Order order
        +PaymentMethod method
        +float amount
        +bool success: boolean
        +void processPayment(): void
    }

    class Review {
        +User reviewer
        +Product product
        +int rating
        +string comment
        +Date reviewDate
        +() submit(): void
    }

    User "1" "-- Order : places - "places"
    User "1" "-- Payment : receives - "receives"
    Product "1" "-- ShoppingCart : added to - "addedTo"
    ShoppingCart "1..*" "-- Order : products for - "productsFor
    Order "1" "-- Payment : pays - "pays"
    Payment "1" "-- Order : completes - "completes
    User "1" "-- Review : leaves - "leaves
    Product "1" "1..*" "-- Review : reviewed by - "reviewedBy
```