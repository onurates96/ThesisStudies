```mermaid
classDiagram
    class User {
        +string username
        +string password
        +string email
        -List~int~ purchaseHistory
        +addPurchaseHistory(purchase:Product) void
        +getPurchaseHistory():List~Product~
    }
    class Product {
        +string name
        +decimal price
        +string description
        +List~Review~ reviews
        +addReview(review:Review) void
        +getReviews():List~Review~
    }
    class ShoppingCart {
        +User owner
        +List~Product~ items
        +addProduct(product:Product) void
        +removeProduct(product:Product) void
        +clear() void
    }
    class Order {
        +User user
        +ShoppingCart cart
        +decimal totalAmount
        +Date placedAt
        +Status status
        +process() void
        +cancel() void
    }
    class Payment {
        +Order order
        +decimal amount
        +string paymentMethod
        +confirm() void
        +refund() void
    }
    class Review {
        +User reviewer
        +Product product
        +int rating
        +string comment
        +Date submittedAt
    }
    User "1" --> "*" Order : places
    User "1" --> "*.." Review : writes
    Product "1" --> "*" ShoppingCart : exists in cart
    ShoppingCart "1" --> "1" Order : creates
    Order "1" --> "*" Payment : has payment
    Order "1" --> "*" Review : may have reviews
```