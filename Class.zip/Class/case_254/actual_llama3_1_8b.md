```mermaid
classDiagram
    class User {
        +string username
        +string email
        -string password
        +login() bool
        +register() void
    }
    class Product {
        +string name
        +decimal price
        +string description
        +viewDetails() void
    }
    class ShoppingCart {
        -User user
        +addProduct(Product product) void
        +removeProduct(Product product) void
    }
    class Order {
        -ShoppingCart cart
        -Payment payment
        +placeOrder() void
    }
    class Payment {
        -Order order
        +makePayment(decimal amount) bool
    }
    class Review {
        -Product product
        +submitReview(string comment) void
    }
    
    User <|-- ShoppingCart : contains
    Product <-- Order : includedIn
    ShoppingCart *-- Order : manages
    Order ..> Payment : requires
    Product o-- Review : reviewedBy
```