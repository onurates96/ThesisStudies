classDiagram;
  class User {
    +userId: String
    +username: String
    +email: String
  }
  class Product {
    +productId: String
    +name: String
    +description: String
    +price: Float
  }
  class Shopping_Cart {
    +cartId: String
    +userId: String
    +items: List<Product>
  }
  class Order {
    +orderId: String
    +userId: String
    +items: List<Product>
    +totalAmount: Float
  }
  class Payment {
    +paymentId: String
    +orderId: String
    +amount: Float
    +paymentDate: Date
  }
  class Review {
    +reviewId: String
    +userId: String
    +productId: String
    +rating: Int
    +comment: String
  }
  User "1" -- "*" Shopping_Cart: manages;
  Shopping_Cart "1" -- "*" Product: contains;
  User "1" -- "*" Order: places;
  Order "1" -- "*" Product: includes;
  Order "1" -- "*" Payment: completes;
  Product "1" -- "*" Review: hasReviews;