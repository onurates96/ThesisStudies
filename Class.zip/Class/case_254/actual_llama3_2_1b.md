classDiagram
    User: +string name
    Product: +string description
    ShoppingCart: +
    Order: +integer id, +
    Payment: +
    Review: -integer userId, -, 
        -string rating, -
    class Product { 
        +string title
        +price
        -int quantityInStock
    }
    class Order {
        +integer id, -datePlanned, -datePaid, 
            -string description, -+boolean isDelivered
    }
    class Payment {
        +integer id, -amount, -currency, -, 
            -string description, -
        +integer userId, -+decimal amount, -, 
            -string cardNumber, -
    }