```mermaid
classDiagram
    class Bank {
        +string bankName
        -List~Account~ accounts
        +addAccount(account:Account) void
        +removeAccount(account:Account) void
    }
    class Customer {
        +string customerId
        -List~Account~ ownedAccounts
        +openAccount() Account
    }
    class Account {
        +decimal balance
        -- Bank managedBank
        +deposit(amount:decimal) void
        +withdraw(amount:decimal) void
    }
    class Transaction {
        +decimal amount
        --> "0..1" Account relatedAccount
        +execute() void
    }
```