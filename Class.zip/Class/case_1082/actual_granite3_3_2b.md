```mermaid
classDiagram
    class Account {
        +string accountNumber
        +decimal balance
        +deposit(amount: decimal) void
        +withdrawal(amount: decimal) void
    }
    class Customer {
        +string customerId
        +Account account : owns
    }
    class Transaction {
        +string transactionId
        +Account account : involves
        +decimal amount : value
    }
    class Bank {
        +string bankId
        +List[Account] accounts : manages
    }
    Customer "1" "--*-- Bank : uses
    Account * "--*-- Transaction : involved in
    Account * "--*-- Bank : managed by
```