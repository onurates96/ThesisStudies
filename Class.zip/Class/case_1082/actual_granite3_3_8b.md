```mermaid
classDiagram
    class Customer "1" -- "*" Account
    class Account {
        +string accountNumber
        +decimal balance
        +Account(accountHolder: Customer, initialDeposit: decimal)
        -List~Transaction~ transactions
    }
    class Transaction {
        +Date transactionDate
        +decimal amount
        +Account sourceAccount
        +Account destinationAccount
        +Transaction(date: Date, source: Account, destination: Account, amount: decimal)
    }
    class Bank {
        +List~Account~ accounts
        +Bank(name: string)
        -void addAccount(account: Account)
        -void removeAccount(account: Account)
    }
```