```mermaid
classDiagram
    Account <|-- Customer
    Account : +Customer id
    Account : +name customerName
    Customer : +age age
    Customer : +relationship -customer -age
    Transaction <|-- Account
    Bank : +customers bankCustomers
    Bank : +transactions bankTransactions
    Customer "1" --> "*" Customer1: containsBank
    Customer "2" --> "*" Customer2: containsBank
    Customer "3" --> "*" Customer3: containsBank

    classDiagram {
        Account "1" : +"1..*";
        Account : *{"1..*"};
        Customer "1" : +Customer id;
        Customer "2" : +Customer name;
        Customer "3" : +age;
        Customer "4" : +relationship -customer -age;
        Customer "5" : +id;
        Transaction : +"BankTransactions";
        Account : *{"1..*"};
        Bank : +"bankCustomers:containsBank";
        Bank : *{"1..*"};
        Customer "1" : +"Customer id: bankCustomers:containsBank";
        Customer "2" : +"Customer name: bankCustomers:containsBank";
        Customer "3" : +"age: bankCustomers:containsBank";
    }
```