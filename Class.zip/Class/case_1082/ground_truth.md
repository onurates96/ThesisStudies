classDiagram
  class Account {
    - balance : float
    + deposit(amount: float)
    + withdraw(amount: float)
  }
  class Customer {
    - name : string
    + getAddress()
  }
  class Transaction {
    - amount : float
    + getTransactionDetails()
  }
  class Bank {
    + manageAccount()
  }
  Account -- Customer : owns
  Account -- Transaction : has
  Bank -- Account : manages