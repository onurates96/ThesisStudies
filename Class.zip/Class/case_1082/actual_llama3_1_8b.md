```mermaid
classDiagram
    class Bank {
        +string name
        +list[Account] accounts
    }
    class Account {
        -string accountNumber
        -decimal balance
        +Customer customer
    }
    class Customer {
        +string firstName
        +string lastName
        list[Account] ownedAccounts
    }
    class Transaction {
        -decimal amount
        -Date date
        Account source
        Account destination
    }
    Bank <|-- Account : manages
    Customer --> "1" Account : owns
    Transaction *-- Account : belongsTo
```