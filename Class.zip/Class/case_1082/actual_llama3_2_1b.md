```mermaid
classDiagram
    class Account {
        +owner: string
        +balance: decimal
        +deposits(amount:decimal): void
        +withdrawals(amount:decimal): void
    }
    class Customer {
        +id: int
        +name: string
        +account: Account : owns Account
    }
    class Transaction {
        +id: int
        +amount: decimal
        +date: datetime
        +type: string
    }
    class Bank {
        +name: string
        +address: string
        +phone: string
    }
classBankAccount
BankAccount : owner : isMammal()
BankAccount : balance : isMammal()
BankAccount : deposit(amount: decimal) : void
BankAccount : withdraw() : void

Customer "1" --> "*" Ticket
Student "1" --> "1..*" Course
Galaxy "1" --> "*" Star : contains

class Zebra {
    +is_wild: bool
    +run(): void
}

class Duck{
    +beakColor: string
    +quack(): void
}
```