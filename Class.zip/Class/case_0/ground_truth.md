classDiagram
  Class Book
  Class Member
  Class Librarian

  Book -- Borrow
  Book -- Return
  Book -- Reserve
  Librarian -- Manage Inventory