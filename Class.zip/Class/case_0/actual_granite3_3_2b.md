```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +int yearPublished
        +boolean isAvailable
        +Librarian manager
        +Reservations reservations
    }
    class Member {
        +string name
        +string id
        +Book bookBorrowed
        +Reservations reservations
        +Librarian librarian
    }
    class Librarian {
        +string name
        +Password password
        +Members members
        +Books books
    }
    Book <-- Reservations : Uses
    Member --> Borrow : Performs
    Member --> Return : Performed
    Librarian : Manages -> Books
    Librarian : Manages -> Members
```