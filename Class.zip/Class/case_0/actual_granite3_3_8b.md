```mermaid
classDiagram
    class Book{
        +string title
        +string author
        +int publicationYear
        -bool isAvailable
        +Reserve() void
        +Return() void
    }
    class Member{
        +string name
        +string id
        +Book reserveList "0..*"
    }
    class Librarian{
        +string name
        +string id
        +ManageInventory() void
    }
    Book --> "borrow" Member : has
    Book --> "return" Member : receives
    Librarian --> "manage" Book : controls
```