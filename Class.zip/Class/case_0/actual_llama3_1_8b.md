```mermaid
classDiagram
class Book{
    +string title
    +Author author
    -bool isAvailable
    +borrowedBy() Member 
    +returnToLibrarian() void
}
class Member{
    +string name
    +int age
    -bool isAuthorized
    +borrow(Book) void
    +reserve(Book) void
}
class Librarian{
    +string name
    -bool isAdmin
    +manageInventory() void
    +issueBook(Member, Book) void
    +takeBookBack(Member, Book) void
}
Book *-- Member : Borrow
Member --> Librarian : Manage
Librarian -- Book : Issue
```