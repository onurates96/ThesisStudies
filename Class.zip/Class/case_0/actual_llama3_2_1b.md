```mermaid
classDiagram
    class Book {
        +title: string
        +author: string
        +yearOfPublication: int
    }
    
    class Member {
        +id: integer
        +name: string
        +address: string
        -borrowDate: date
    }
    
    class Librarian {
        +id: integer
        +name: string
        +experience: int
    }
    
    class Library {
        +id: integer
        +name: string
        
        +isOpen(): boolean
    
    }
    
    class BorrowedBook {
        -bookId: integer
        -memberId: integer
        -borrowDate: date
    }
    
    class ReturnBook {
        -bookId: integer
        -memberId: integer
        -returnDate: date
    }
    
    class ReserveBook {
        -bookId: integer
        -memberId: integer
        +reserveDate: date
    }
```