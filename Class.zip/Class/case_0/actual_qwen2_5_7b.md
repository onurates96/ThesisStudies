```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +date publicationDate
        -List~Book~ borrowedBy
    }
    class Member {
        +string name
        +string membershipType
        -Book~1 borrowedBook
    }
    class Librarian {
        +string name
        -Member* managedMembers
        -- Book* manageInventory
    }
    Book --> Member : Borrow
    Book <-- Member : Return
    Librarian o-- Member : Manage
    Librarian *-- Book : Inventory
```