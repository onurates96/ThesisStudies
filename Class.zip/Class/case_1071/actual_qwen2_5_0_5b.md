```mermaid
classDiagram
    Student <|-- Course
    Course --- Instructor : +string instructor
    Instructor <|-- Professor : +string professor
    Department <|-- * --> Courses
    Classes "1" --* --> Courses
    Professor <|-- * --> Departments
    Departments <|-- * --> * --> Instructors
    Instructors : +string names
    Instructors : * --> * --> * --> * --> * --> Instructors
```

This Mermaid class diagram represents the university management system with classes and their relationships. The diagram adheres to specific rules and patterns mentioned in the constraints, including correct usage of connectors, proper naming conventions, and cardinality calculations.