```mermaid
classDiagram
    class University {
        class Department {
            class Course {
                +name: string
                +credits: int
            }
        }
        class Professor {
            class Student {
                class Course { 
                    +name: string
                    +credits: int
                }
            }
        }
    }
```