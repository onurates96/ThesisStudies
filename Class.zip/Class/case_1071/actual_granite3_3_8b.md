```mermaid
classDiagram
    class Student {
        +string name
        +int studentId
        -List~Course~ enrolledCourses
        enrolls in Course
    }
    class Course {
        +string courseName
        +int courseId
        +Professor teacher
        +Department department
        manages Courses
    }
    class Professor {
        +string name
        +int professorId
        teaches Course
    }
    class Department {
        +string departmentName
        +int departmentId
        manages Courses
    }
```