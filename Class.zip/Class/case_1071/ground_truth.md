classDiagram
  Class01 <|-- Student
  Class01 <|-- Professor
  Class01 <|-- Course
  Class01 <|-- Department
  Student : Enrolls in Course
  Professor : Teaches Course
  Department : Manages Courses