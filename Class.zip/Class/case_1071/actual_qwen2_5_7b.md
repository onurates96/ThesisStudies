```mermaid
classDiagram
    class Department {
        +string name
        +List~Course~ courses
    }
    class Professor {
        +string name
        -List~Course~ taughtCourses
    }
    class Course {
        +string name
        +int creditHours
        *-- Department departmentManagedBy
        -- Professor teachesBy
    }
    class Student {
        +string name
        +List~Course~ enrolledCourses "0..*"
    }
```