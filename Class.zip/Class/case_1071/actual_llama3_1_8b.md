```mermaid
classDiagram
    class Student {
        +string name
        +int age
        +Course[] coursesEnrolled
        enrollInCourse() void
        getGPA() float
    }
    
    class Course {
        +string courseCode
        +string courseName
        -Professor professorTeaching
        teachBy() Professor : oneToOneRelationship
        manage() Department : oneToManyRelationship
    }
    
    class Professor {
        +string name
        +string title
        -Course[] coursesTaught
        +string department
        +teachCourse() void
    }
    
    class Department {
        +string departmentName
        -Professor professorInCharge
        manageCourses() Course[] : oneToManyRelationship
        hireProfessor() Professor : oneToOneRelationship
    }

    Student "1" --> "*" Course : enrollment 
    Course "--> *Department" : management
    Professor "--> *Course" : teaching
    Department "--> *Course" : management
```