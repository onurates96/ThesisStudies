```mermaid
classDiagram
    class Student {
        +string name
        +List<Course> enrolledCourses
    }
    class Course {
        +string name
        +Professor instructor
    }
    class Professor {
        +string name
        +Course taught
    }
    class Department {
        +string name
        +List<Course> managedCourses
    }
    Student "1" --> "1..*" Course : enrolls
    Professor "1" --> "1..*" Course : teaches
    Department "1" --> "1..*" Course : manages
```