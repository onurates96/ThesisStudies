```mermaid
classDiagram
    class Product {
        +string name
        +int price
        -string supplierId
    }
    class Inventory {
        +List~Product~ products
        *-- PurchaseOrder
        o-- SalesTransaction
    }
    class Supplier {
        +string name
        +List~string~ productIds
    }
    class PurchaseOrder {
        +string orderId
        -- Product "1" : contains
        -Inventory inventory
    }
    class SalesTransaction {
        +int transactionId
        -- Product "0..*" : sold
        -Customer customer
    }
```