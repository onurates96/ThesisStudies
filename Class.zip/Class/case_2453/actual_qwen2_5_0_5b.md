```mermaid
classDiagram
    class Product <|-- Inventory
        Item ID
        Quantity

        Supplier : +hasSupplier() bool
        PurchaseOrder : +inStock() bool
        SalesTransaction : +ordered() bool
        Invoice : +isInStock() bool
        Inventory : +hasQuantity() bool
        Stock : +all() bool

    class Inventory <|-- Product
    class Product <|-- Supplier
    class Supplier <|-- SalesTransaction
    class PurchaseOrder <|-- PurchaseOrder
    class PurchaseOrder <|-- Inventory
    class Sale : +ordered() bool
    class SalesTransaction : +inStock() bool
    class Product : +supplier() [Supplier] (class Product)
    class SalesTransaction : +ordered() [SalesTransaction]
    class Stock : +all() [Inventory]

```