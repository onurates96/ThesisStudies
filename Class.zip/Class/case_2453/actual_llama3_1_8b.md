```mermaid
classDiagram
    class Product {
        +string name
        +decimal price
        +Product(int id)
        +void updatePrice(decimal newPrice)
        ~List~Inventory~
    }
    class Inventory {
        -int quantity
        +Inventory(Product product, int quantity)
        +void restock()
    }
    class Supplier {
        +string name
        +Supplier(string companyName)
        +void placeOrder(PurchaseOrder po)
    }
    class PurchaseOrder {
        +decimal totalCost
        +PurchaseOrder(Supplier supplier, List~Product~ products)
        +void confirmOrder()
    }
    class SalesTransaction {
        +decimal amount
        +SalesTransaction(Product product, decimal amount)
        +void processPayment()
    }
    Product "1" *-- Inventory : containedIn
    Supplier --> PurchaseOrder : placesOrders
    PurchaseOrder "--> SalesTransaction : resultsIn
```