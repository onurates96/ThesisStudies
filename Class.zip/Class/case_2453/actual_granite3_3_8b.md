```mermaid
classDiagram
    class Product {
        +string name
        +decimal price
        +Supplier supplier : "*"
        +Inventory inventory : "1"
        -String category
        +addCategory(cat:String) void
    }
    class Inventory {
        +int quantity
        +Product product : "*"
        -String location
        +updateLocation(loc:String) void
    }
    class Supplier {
        +string name
        +String contactInfo
        +List~Product~ products : "1..*"
    }
    class PurchaseOrder {
        +Date orderDate
        +Supplier supplier : "*"
        +List~Product~ items : "1..*"
        -boolean status
    }
    class SalesTransaction {
        +Date transactionDate
        +Customer customer : "*"
        +List~Product~ items : "1..*"
        -decimal totalAmount
    }
```