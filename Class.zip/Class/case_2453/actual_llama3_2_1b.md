```mermaid
classDiagram
    class Product {
        +string name: 
        +int quantityInStock
        -inventor() Person
    }
    class Supplier {
        +string address: string
        -inventor() Person
    }
    class PurchaseOrder {
        +string orderId: int
        -supplier() Supplier
    }
    class SalesTransaction {
        +string transactionId: int
        -inventory() Inventory
        -supplier() Supplier
    }
```