classDiagram
    class Product {
        +int ProductID
        string Name
        string Description
        double Price
        int StockQuantity
    }
    class Inventory {
        +int InventoryID
        int ProductID
        int Quantity
        Date LastStockDate
    }
    class Supplier {
        +int SupplierID
        string Name
        string Address
        string Email
        string Phone
    }
    class PurchaseOrder {
        +int OrderID
        int SupplierID
        Date OrderDate
        double TotalAmount
    }
    class SalesTransaction {
        +int TransactionID
        int ProductID
        Date TransactionDate
        double Amount
        int QuantitySold
    }
    Product --> Inventory : is_stocked_in
    Product --> SalesTransaction : is_sold_in
    Supplier --> PurchaseOrder : supplies
    PurchaseOrder --> Product : includes_products