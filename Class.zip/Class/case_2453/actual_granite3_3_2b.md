```mermaid
classDiagram
    class Product {
        +string name
        +int quantity
        +float price
        +Supplier supplier
    }
    class Inventory {
        +Product[] products
        +void updateStock(Product p, int quantity)
    }
    class Supplier {
        +string name
        +Inventory inventory
    }
    class PurchaseOrder {
        +Product[] items
        +float totalPrice
        +Supplier issuer
    }
    class SalesTransaction {
        +Product item
        +int quantity
        +Date date
        +Customer customer
    }

    Product "1" -> Inventory : contains
    Inventory "1.." PurchaseOrder : issues
    PurchaseOrder "1" -> Supplier : places order with
    SalesTransaction "1" --> Product : records sale of
    Customer "1" --> SalesTransaction : initiates
```