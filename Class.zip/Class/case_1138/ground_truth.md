classDiagram
  Class Book{
    -title: string
    -author: string
    -ISBN: string
  }
  Class Member{
    -name: string
    -memberID: string
  }
  Class Librarian{
    -name: string
    -employeeID: string
  }
  Class Library{
    -name: string
    -address: string
  }
  Class Transaction{
    -transactionID: string
    -date: Date
  }
  Book --> Library
  Member --> Library
  Transaction --> Book
  Transaction --> Member
  Transaction --> Librarian