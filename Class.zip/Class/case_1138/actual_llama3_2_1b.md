```mermaid
classDiagram
    class Member {
        + string name
        + int age
        - boolean isStudent()
    }
    
    class Book {
        + string title
        + int pages
        + boolean isAvailable()
    }
    
    class Librarian {
        + string username
        + String password
        
        + void addBook(Book book)
        + void removeBook(Book book)
        
        : inherit from Member
    }
    
    class Library {
        + string name
        + int capacity
    
        - addMember(Member member) void
        - removeMember(Member member) void
        
        : inherit from Librarian
    }
    
    class Transaction {
        + boolean success
        + int transactionId
        
        + void execute()
    }
```