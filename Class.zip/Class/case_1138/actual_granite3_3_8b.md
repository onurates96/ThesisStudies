```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +int publicationYear
        -bool isAvailable
        +checkOut() void
        +returnBook() void
    }
    class Member {
        +string name
        +string membershipID
        -List~Book~ checkedOutBooks
    }
    class Librarian {
        +string name
        +int employeeID
        -Book checkOut(title:string) Book
        -Book returnBook(title:string) void
    }
    Library <|-- Librarian
    Member "1" --> "*" Transaction : borrowed
    Transaction --> "1" Book : borrowed
```