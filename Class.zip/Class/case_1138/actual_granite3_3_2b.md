```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +int publicationYear
        +boolean isAvailable
    }
    class Member {
        +string name
        +string memberID
        +bookList Book*
    }
    class Librarian {
        +string name
        +LibrarianLibrary library
        +list pendingTransactions Transaction*
    }
    class Library {
        +string name
        +Librarian librarian
        +Book collection
        +Member memberList
    }
    class Transaction {
        +string transactionID
        +TransactionType type
        +Book book
        +Member issuedTo
        +LibrarianLibrarianLibrarian responsible
    }

    Book "1" "-- Library.collection : contains"
    Member "1..*" -- Library.memberList : maintains
    Librarian "1" -- Library : manages
    Librarian "1" -- Transaction.responsible : approves
    Transaction "1" --> Book : is associated with
```