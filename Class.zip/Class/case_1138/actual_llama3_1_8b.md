```mermaid
classDiagram
class Book { +string title +string author }
class Member { -string name }
class Librarian extends Member { +string libraryName ~Library~ }
class Library { +string address +string phoneNumber }
class Transaction { +date transactionDate +Book book }

Member --> "many" * Transaction : borrows
Transaction <|-- Book : rented
Library o--* Librarian : employed
Library --* "1..n" Transaction : transactions
```