```mermaid

    // Class Diagram for the Library Management System

    classDiagram

        // Book Example (Attributes and Operations)
        class A
            book <|-- fiction
            book : +string title
            book : +int pages
            book : +boolean checked
            book : +hasPages() bool
            book : +isAvailable() bool
            book : +copy() void

            library {
                books: "*" 
                loans: "+" 
                returnBooks: "0..*" 
                borrowing: "*" 
                returning: "*" 
                returningBorrowed: "*" 
                borrowed: "+*"
                returned: "1..*" 
                returnAll: "1..*" 
                returnLimit: "*"
            }

        // Member Example (Attributes and Operations)
        class B
            member <|-- book: "*" books, library, borrowing
            member : +string name
            member : +integer age
            member : -hasLibrary() bool
            member : +bookmarks: "*" bookmarks

        // Member Example (Attributes and Operations)
        class C
            member <|-- library: "*" returned, returning, returnAll
            member : *~*"1..*" "~" libraries
            member : +string name
            member : -hasReturn() bool
            member : +returningBorrowed() bool
            member : +library: "1.." "30..."

        // Member Example (Attributes and Operations)
        class D
            member <|-- library: "*" returned, returning, returnAll, returnLimit: "*"

        // BookExample Example (Association)
        library { books, borrowing, book } -> library

        // Library Example (Operations)
        library : +string name
        library : -contains *~*"1.." "~" libraries

        // Member Example (Operations)
        member : +name "John"
        member : +age 28
        member : +hasLibrary "True"

        // Transaction Example (Operations)
        book <|-- transaction: "*" transactions, returned
        transaction : -contains *~*"1.." "~" books

    ```
```