```mermaid
classDiagram
    class Library {
        +string name
        +List~Book~ books
        o-- Member members
        o-- Librarian librarian
        +addBook(book: Book) void
        +removeMember(member: Member) void
    }
    class Book {
        +string title
        +string author
        -int yearPublished
        +getDetails() string
    }
    class Member {
        +string name
        +List~Transaction~ transactions
        +borrowBook(book: Book) Transaction
        +returnBook(transaction: Transaction) void
    }
    class Librarian {
        +string name
        +addMember(member: Member) void
        +removeMember(member: Member) void
        -List~Member~ members
    }
    class Transaction {
        "1" --> "0..*" Book : borrowed
        "1" --> "1" Member : member
        +dateBorrowed: Date
        +dateReturned: Date
        +extendLoan(days: int) void
    }
    Library <|-- Librarian
```