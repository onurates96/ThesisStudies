```mermaid
classDiagram
    class Member
    Member : +string name : isMammal() bool 
        - int age
        - string gender
        +void loan()
    end

    class Book
    Book : +string title : returnDate() void
        +void returnBook()
    end
    
    class Library
    Library : +list member
        +addMember(member:Member)
    end

    Loan : +member (Book) (int amount:decimal)
        +returnBook()
```

```