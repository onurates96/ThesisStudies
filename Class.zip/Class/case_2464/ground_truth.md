classDiagram
    class Book {
        +int BookID
        string Title
        string Author
        string ISBN
        int Quantity
    }
    class Member {
        +int MemberID
        string Name
        string Address
        string Email
        string Phone
    }
    class Library {
        +int LibraryID
        string Name
        string Location
    }
    class Loan {
        +int LoanID
        int BookID
        int MemberID
        Date LoanDate
        Date DueDate
    }
    class Fine {
        +int FineID
        int MemberID
        double Amount
        Date DueDate
        Date PaymentDate
    }
    Book --> Loan : is_loaned_by
    Member --> Loan : borrows
    Book --> Fine : incurs_fine
    Member --> Fine : pays_fine
    Library --> Book : has_books