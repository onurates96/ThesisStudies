```mermaid
classDiagram
    class Book {
        +int id
        +string title
        +String author
        +Date publicationDate
        +Genre genre
        +int availableCopies
        +Loan[] loans
    }
    class Member {
        +int memberId
        +String name
        +Password password
        +Book borrowedBook
        +fine:Decimal = 0.00
        +Loan[] currentLoans
    }
    class Library {
        +int id
        +String name
        +Book[] books
        +Member[] members
        +Fine[] fines
    }
    class Loan {
        +int loanId
        +Book book
        +Member member
        +Date issuanceDate
        +Date returnDate
        +decimal overdueDays
        +bool isOverdue
    }
    class Fine {
        +int id
        +Book book
        +Member member
        +decimal amount
        +Date issuedDate
    }

    Library "1" "<--" "0..*" Book : contains
    Member "1" "1.."* Loan : issues
    Loan "1" "1.."* Book : has
    Library "1" "1.."* Fine : incurs
    Member "1" "1.."* Loan : has
    Book "1" "..1" Loan : borrowed
    Library "1" "..1.." Fine : manages
```