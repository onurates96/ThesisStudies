```mermaid
classDiagram
    Member <|-- Book : +string title, +isbn, +publisher
    Member : +Book add() void
    Member : +Book delete(books) void
    Member : +Book return(books) bool
    
    Member <|-- Member : *~
    
    Library "1" -> Book : +
    Library "1" -> Book : -  (add)
    Library "1" -> Book : +  (delete, add)
    Library "1" -> Book : +  (return, delete, add)
    
    Loan "1" : +Member return(books) bool
    Member : +Loan lend() void
    
    Member <|-- Member : *~
    
    Member <|-- Member : *~
    
    Member <|-- Member : *~
    
    Member <|-- Member : *~
    
    Member <|-- Member : *~
    
    Member <|-- Member : *~
    
    Member <|-- Member : *~
```