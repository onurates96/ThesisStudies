```mermaid
classDiagram
    class Book {
        +string title
        +string author
        -int yearPublished
        +boolean isAvailable()
    }
    class Member {
        +string name
        +string memberID
        +login() bool
    }
    class Library {
        *-- Book "0..*"
        *-- Member "1"
        +string libraryName
        +searchBook(title:string) Book
        +issueBook(member:Member, book:Book) Loan
    }
    class Loan {
        -Member borrower
        -Book borrowedBook
        +dueDate : Date
        +returnBook() void
    }
    class Fine {
        -Loan loan
        +amount : decimal
        +calculateFine(daysOverdue:int) decimal
    }
```