```mermaid
classDiagram
    class Book {
        +string title
        -string author
        -decimal price
        +isAvailable() bool
    }
    class Member {
        +string name
        +int age
        -string address
        +login(username:string, password:string) bool
    }
    class Library {
        +string name
        +int capacity
        +Book[] books
        Member "1" --> "*" Book : borrowedBy
        Loan "0..n" --> "*" Fine : associatedWith
    }
    class Loan {
        -decimal fineAmount
        -datetime loanDate
        Member "1" --> "1..*" Loan : borrowed
        Book "1" <-- "1.." Loan : lent
    }
    class Fine {
        +string reason
        Loan -- "0..n" Fine : associatedWith
    }
```