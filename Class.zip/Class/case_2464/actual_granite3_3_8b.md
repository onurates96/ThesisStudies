```mermaid
classDiagram
    class Book{
        +string isbn
        +string title
        +Author author
        -boolean isAvailable
        +void borrow()
        +void returnBook()
        +Fine calculateFine(int days:int)
    }
    class Member{
        +string name
        +Address address
        +List~int~ loans
        -double balance
        +void addLoan(Loan loan)
        +void payFine(Fine fine, double amount)
    }
    class Library{
        +Collection<Book> collection
        +Member[] members
        +FinePolicy policy
        -Map<Member, List<Loan>> outstandingLoans
        +Book searchByISBN(string isbn:string) : Book
        +void addBook(Book book)
        +void removeBook(Book book)
    }
    class Loan{
        +Member borrower
        +Book book
        +Date dueDate
        -Date returnDate
        +Fine fine
        +void markOverdue()
    }
    class Fine{
        +double amount
        +Date paymentDate
        +Member member
        +Book book
    }
```