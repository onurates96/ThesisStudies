```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +boolean isAvailable
        -borrowedBy: Member
        +return() void
        +reserve(Member) void
    }
    class Member {
        +string name
        +string address
        +string phoneNumber
        +borrow(Book) void
        +return(Book) void
    }
    class Library {
        +string location
        +boolean isOpen
        -books: Book[]
        -members: Member[]
        +addBook(Book) void
        +removeBook(Book) void
        +addMember(Member) void
        +removeMember(Member) void
    }
    Book <|-- Library : Books in the library
    Member --> Library : Members of the library
    Library *-- Book : Composition (books are part of the library)
    Book ..> Member : Borrowed by member
    Member ..|> Book : Reserved book
```