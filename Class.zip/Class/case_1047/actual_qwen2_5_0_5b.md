```mermaid
classDiagram
    Library <|-- Borrower
    Member <|-- Borrow, Return
    Book <|-- Borrow, Return
```

This Mermaid code block describes a library management system with classes such as `Book`, `Member`, and `Library`. It includes the relationship declarations between these classes using the specified connectors.