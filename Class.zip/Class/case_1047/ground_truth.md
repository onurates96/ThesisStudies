classDiagram
  Class Book {
    +title
    +author
    +publisher
    +ISBN
  }
  Class Member {
    +name
    +address
    +phone
  }
  Class Library {
    +name
    +location
  }
  Book <|-- Borrow
  Book <|-- Return
  Book <|-- Reserve
  Member <|-- Borrow
  Member <|-- Return
  Member <|-- Reserve