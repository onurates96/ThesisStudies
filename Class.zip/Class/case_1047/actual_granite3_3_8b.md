```mermaid
classDiagram
    class Book{
        +string title
        +string author
        +int publicationYear
        -bool isAvailable
        +getDetails() void
    }
    class Member{
        +string memberID
        +string name
        +List~int~ borrowedBooks "1..*"
        -List~int~ reservedBooks "*"
    }
    class Library{
        +string address
        +Collection<Book> bookCollection "1"
        +Member[] members "*"
        -Reserve[] pendingReserves "*"
    }
    Member "1" --> "*": borrows
    Book --> "Borrow" : label
    Book <-- "Return" : label
    Member --> "Reserve" : label
    Library "1" --> "*": contains
```