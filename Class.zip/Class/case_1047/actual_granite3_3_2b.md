```mermaid
classDiagram
    class Book {
        +int id
        +string title
        +string author
        +date publicationDate
        +BookGenre genre
        +List<Member> borrowers
    }
    class Member {
        +int id
        +string name
        +string membershipNumber
        +date joinDate
        +list borrowedBooks
    }
    class Library {
        +int id
        +string name
        +address
        +list managedBooks
        +class Book : managedBooks
        +class Member : members
    }
    Library "1" -- "*" Book : manages
    Member "1" -- "*" Book : borrows
```