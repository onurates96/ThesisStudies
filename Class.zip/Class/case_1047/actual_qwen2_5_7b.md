```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +int isbn
        -List~Member~ borrowedMembers
        -Date borrowDate
    }
    class Member {
        +string name
        +string email
        -List~Book~ borrowedBooks "0..*"
    }
    class Library {
        +String libraryName
        *-- Book books "1..*"
        *-- Member members "1..*"
    }
    Book --> Member : Borrow
    Book <-- Member : Return
    Book o-- Member : Reserve
```