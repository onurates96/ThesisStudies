```mermaid
classDiagram
    Book : +title string 
        borrow() void
        returnBook() void
    Member : +id int
        reserveBook() void
        withdrawBook() void
    Library : +name string
        addBook() void
        removeBook() void
    ClassA : +name string, attributes: [string]
        member : +name: Member, age: int
```