```mermaid
classDiagram
    class Student {
        -id: int
        +name: string
        +enroll(course: Course) void
        +unenroll(course: Course) void
    }
    class Course {
        -id: int
        +title: string
        +professor: Professor
        -- registration: Registration
        +enrolledStudents: List~Student~
    }
    class Professor {
        -id: int
        +name: string
        o-- Course : teaches
    }
    class Registration {
        -student: Student
        -course: Course
        +register() void
        +unregister() void
    }
    class Department {
        -id: int
        +name: string
        *-- Student : belongsTo
        *-- Course : offers
    }
    class Grade {
        -value: float
        -student: Student
        -course: Course
        +calculate() void
    }
    Student --> Course : enrollments
    Professor <|-- Course : teaches
    Department *-- Student : managesStudents
    Department *-- Course : offersCourses
    Registration -- "1" Course : isFor
    Registration -- "1" Student : ofStudent
    Grade ..> Course : gradesFor
    Grade ..> Student : givenTo
```