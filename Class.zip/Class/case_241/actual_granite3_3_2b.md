```mermaid
classDiagram
    class Student {
        +string name
        +int studentID
        +Department department
        +List<Registration> enrollments
    }
    class Course {
        +string courseCode
        +string courseName
        +Professor professor
        +List<Registration> registrations
    }
    class Professor {
        +string name
        +string email
        +Department department
        +List<Course> courses
    }
    class Registration {
        +string registrationID
        +Student student
        +Course course
        +grade::Grade
    }
    class Department {
        +string name
        +List<Professor> professors
    }
    class Grade {
        +float gradeValue
        +string description
    }

    Student "1" -- "*" Course : enrolls
    Student --> Registration : has
    Course *-- Professor : taughtBy
    Department "1" -- "*" Professor : departmentMember
```