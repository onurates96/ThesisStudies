```mermaid
classDiagram
    class Student {
        +id: int32
        -name: string
        +age: int32
        +rollno: int32
        
        classGrade: Grade[]
        void registerCourse(Course course) 
            +message: "Registering in course {course.name}"
        
        ClassA : +Student[]
    }
    
    class Course {
        +id: int32
        -name: string
        +credits: int32
        -grade: Grade
        
        classStudent: Student[]
        
        void assignProfessor(Professor professor) 
            +message: "Assigning professor to course {course.name}"
    }
    
    class Professor {
        +id: int32
        -name: string
        +rank: int32
        +courses: Course[]
        
        classStudents: Student[]
        
        ClassA : +Professor[]
    }
    
    class Department {
        +id: int32
        -name: string
        
        classMembers: Member[]
        
        void addMember(Member member) 
            +message: "Adding member to department {department.name}"
    }
    
    class Grade {
        +id: int32
        -grade: string
        
        ClassA : +Grade[]
        
        void assignStudent(Student student)
            +message: "Assigning grade to student {student.id}"
    }
```