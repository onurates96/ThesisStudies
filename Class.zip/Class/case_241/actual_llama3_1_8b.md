```mermaid
classDiagram
class Student {
    +string name
    -int student_id
    +Student() void
    +register_course(course:Course) void
}
class Course {
    +string course_name
    -int course_id
    +Course() void
    +assign_professor(professor:Professor) void
}
class Professor {
    +string name
    -int professor_id
    +Professor() void
    +teach_course(course:Course) void
}
class Registration {
    +string reg_number
    -int student_id
    -int course_id
    +Registration() void
    +record_grade(grade:Grade) void
}
class Department {
    +string department_name
    -int department_id
    +Department() void
    +affiliates_staff(professor:Professor) void
}
class Grade {
    +string grade_name
    -int student_id
    -int course_id
    +Grade() void
}

Student "1" --> "*" Registration : registered_in
Course -- Professor : taught_by
Registration -- Course : enrolled_in
Department *-- Professor : affiliated_with
Registration -- Grade : recorded_grade
Professor "1..*" --> Course : teaches
```