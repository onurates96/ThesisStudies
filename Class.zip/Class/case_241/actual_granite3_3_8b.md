```mermaid
classDiagram
    class Student {
        +string studentID
        +string name
        -List~Course~ enrolledCourses
        +register(course:Course) void
        +drop(course:Course) void
    }
    class Course {
        +string courseID
        +string title
        +Professor instructor
        +Department department
        +List~Student~ enrollments
        -Grade finalGrade
    }
    class Professor {
        +string professorID
        +string name
        +List~Course~ taughtCourses
    }
    class Department {
        +string deptName
        +List~Course~ courses
    }
    class Registration {
        +Student student
        +Course course
        +timestamp registrationTime
    }
    class Grade {
        +double gradeValue
        +Course course
        +Student student
    }
    Student "1" --> "*": register
    Course "1" --> "*": enrollments
    Professor *-- "*" : taughtCourses
    Department *-- "*" : courses
    Student --> Course : enrolledIn
    Course -- Grade : assignsGrade
```