```mermaid
classDiagram
    Student <|-- Course
    Professor <|-- Class
    Department <|-- Course
    Grade <|-- Student
    Enrollment (Student, Course) { "1" }
    Registration (Student, Course) { "1..*" }
    Professionals ("1") : +string profession
    Departments ("1") : +string department
    Grades ("1") : +decimal grade
    AcademicYear ("1", "2023-2024") : *..
    Course <|-- Professor, Department, Grade
    Registration <|-- Student, Professor, Department
    Professions ["1"] : +string profession
```

This Mermaid code creates a class diagram for a university course registration system. It defines classes like 'Student', 'Course', 'Professor', 'Registration', 'Department', and 'Grade' along with their relationships.