classDiagram;
  class Student {
    +studentId: String
    +name: String
    +major: String
  }
  class Course {
    +courseId: String
    +title: String
    +credits: Int
  }
  class Professor {
    +professorId: String
    +name: String
    +department: String
  }
  class Registration {
    +registrationId: String
    +studentId: String
    +courseId: String
    +semester: String
  }
  class Department {
    +departmentId: String
    +name: String
    +location: String
  }
  class Grade {
    +gradeId: String
    +studentId: String
    +courseId: String
    +grade: String
  }
  Student "1" -- "*" Registration: registers;
  Course "1" -- "*" Registration: hasRegistrations;
  Professor "1" -- "*" Course: teaches;
  Department "1" -- "*" Professor: hasProfessors;