```mermaid
classDiagram
    class Customer {
        +string name
        +decimal balance
        +addDeposit(amount: decimal)
        +subtractWithdrawal(amount: decimal)
        +viewBalance() : decimal
    }
    class Account {
        +Customer owner
        +checkBalance() : decimal
    }
    class Transaction {
        +Account sender
        +Account receiver
        +amount : decimal
        +type : string // deposit or withdrawal
    }
    class Loan {
        +Customer borrower
        +decimal amount
        +interestRate : decimal
        +status : string // approved, pending, rejected
    }
    class Branch {
        +string name
        +list Account employees
    }
    class Employee {
        +Branch branch
        +checkAccount(account: Account) : boolean
    }
```