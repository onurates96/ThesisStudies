```mermaid
classDiagram
    class Branch {
        -string name
        +handleTransaction(transaction:Transaction) void
        *Account[] accounts
    }
    class Employee {
        -string name
        -string role
        +processTransaction(transaction:Transaction) void
        -- Account account
    }
    class Customer {
        +string name
        o-- Account account
    }
    class Account {
        -double balance
        +deposit(amount:double) void
        +withdraw(amount:double) void
        +transfer(amount:double, toAccount:Account) void
        -- Customer customer
        -- Branch branch
    }
    class Transaction {
        -double amount
        +DateTime timestamp
        -- Account account1
        -- Account account2
    }
    class Loan {
        -double amount
        -int termInMonths
        +interestRate() double
        -- Customer customer
    }
    Employee <|-- Branch
    Customer <|-- Account
    Account *-- Transaction
    Loan ..> Customer
```