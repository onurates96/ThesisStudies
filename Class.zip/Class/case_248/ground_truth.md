classDiagram;
  class Customer {
    +customerId: String
    +name: String
    +address: String
  }
  class Account {
    +accountId: String
    +customerId: String
    +balance: Float
  }
  class Transaction {
    +transactionId: String
    +accountId: String
    +amount: Float
    +transactionDate: Date
  }
  class Loan {
    +loanId: String
    +customerId: String
    +amount: Float
    +interestRate: Float
    +loanDate: Date
  }
  class Branch {
    +branchId: String
    +name: String
    +location: String
  }
  class Employee {
    +employeeId: String
    +name: String
    +position: String
    +branchId: String
  }
  Customer "1" -- "*" Account: ownsAccounts;
  Account "1" -- "*" Transaction: hasTransactions;
  Customer "1" -- "*" Loan: appliesForLoans;
  Branch "1" -- "*" Account: hasAccounts;
  Branch "1" -- "*" Employee: hasEmployees;