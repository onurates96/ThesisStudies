classDiagram
    class Customer { +string id, +string name, +isActive() bool }
    class Account { +string id, +Customer owner, +decimal balance, +string type: TransactionType } +Transaction { +integer id, +Account from: Account, +Account to: Account, +float amount: decimal, +datetime createdAt: datetime } +Loan { +string id, +Customer lender, +double interestRate: double, +durationInMonths: int }
    class Branch { +string id, +Address street: string, +city: string, +country: string }
    class Employee { +string id, +name: string, +Position : Role } +Role { +enum : Position { ADMIN, MANAGER, STAFF } }
    class TransactionManager { +void deposit(int amount) void, +void withdraw(int amount) void }
    class CustomerService { +void processLoan(Loan loan): void } +EmployeeService { +void handleCustomerIssue(Employee customer): void }