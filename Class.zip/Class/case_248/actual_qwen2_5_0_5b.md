```mermaid
mermaid

classDiagram

    class Customer {
        +string name;
        -list of customer accounts: account;
        +int age;
        +*..
    }

    class Account {
        +decimal balance;
        ++deposit(amount:decimal) void;
        +withdrawal(amount:decimal) void
    }

    class Transaction {
        +account: list of accounts.
        ++debit() void;
        ++credit(amount:decimal) void;
    }

    class Loan {
        +*..
        -list of loan transactions.
        +-loan("name", "loanAmount");
    }

    class Branch {
        +string name;
        +*..*
    }

    class Employee {
        +string name;
        +*..
    }
```