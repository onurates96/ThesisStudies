```mermaid
classDiagram
    class Customer {
        +string name
        +int id
        +string address
        -List~Account~ accounts
        +addAccount(account:Account) void
        +removeAccount(account:Account) void
    }
    class Account {
        +string accountNumber
        +decimal balance
        +Customer owner
        +Transaction transactionHistory
        +applyInterest() void
    }
    class Transaction {
        +datetime timestamp
        +decimal amount
        +Account fromAccount
        +Account toAccount
    }
    class Loan {
        +decimal amount
        +Customer customer
        +Account associatedAccount
        +datetime dueDate
        +boolean isActive
        +Employee assignedEmployee
    }
    class Employee {
        +string name
        +int id
        +List~Loan~ managedLoans
        +Branch branch
    }
    class Branch {
        +string address
        +List~Employee~ employees
    }
```