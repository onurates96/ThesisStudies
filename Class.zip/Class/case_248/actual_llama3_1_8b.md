```mermaid
classDiagram
    class Customer {
        +string name
        +Account account
    }
    class Account {
        +Customer owner
        -decimal balance
        +Transaction[] transactions
    }
    class Transaction {
        +decimal amount
        +datetime date
        +Account source
        +Account target
    }
    class Loan {
        +Customer applicant
        +Account loanAccount
        -decimal interestRate
    }
    class Branch {
        +string location
        +Employee[] employees
    }
    class Employee {
        +string name
        +Branch branch
        +Role role
    }
    class Role {
        +string title
    }

    Customer "1" --> "*" Account : ownedAccount
    Account -- Loan : hasLoan
    Branch *-- Employee : worksAt
```