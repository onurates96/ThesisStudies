%% Use Case Diagram for Movie Streaming Service
classDiagram
  class Subscriber {
    +browseMovies()
    +watchMovie()
    +manageSubscription()
  }
  class Admin {
    +manageContent()
    +manageUsers()
  }
  class UseCase {}
  Subscriber --> UseCase : "Browse Movies"
  Subscriber --> UseCase : "Watch Movie"
  Subscriber --> UseCase : "Manage Subscription"
  Admin --> UseCase : "Manage Content"
  Admin --> UseCase : "Manage Users"
  UseCase :