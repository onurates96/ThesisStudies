```mermaid
classDiagram
    class Actor
        +string name
        +int age
    end
    class Role
        +string name
    end
    Actor : +Role* ()
    class Movie
        +string title
        -int actors[]
    end
    class Genre
        +string name
    end
    Actor : +
    class Person
        +Actor
        +string description
    end
    Person : +
    class Review
        +string rating
        +string reviewText
    end
```