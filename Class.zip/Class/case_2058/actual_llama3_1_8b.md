```mermaid
classDiagram    
    class Subscriber { 
        +string email
        +login() bool
        +subscribeToPlan(Plan plan) void
    }
    class Admin {
        +string username
        -password: string
        +manageSubscriptions() void
    }
    Subscriber --> Admin : interacts
    class BrowseMovies {
        +int rating
        +displayMovies(Movie movie) void
    }
    class WatchMovie { 
        +int duration
        +playVideo(Video video) void
    }
    class ManageSubscriptions { 
        +int subscriptionId
        +updatePlan() void
    }
    Subscriber --> BrowseMovies : uses
    Admin --> WatchMovie : uses
    Admin --> ManageSubscriptions : uses
```