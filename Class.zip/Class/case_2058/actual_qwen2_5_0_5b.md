```mermaid
classDiagram
    class A <|-- B
    A : +string name
    B : *--* C
    C o-- D
    D o-- E
    E -- F
    F > G : +int age
    G : +string email
    G = |>
    G : +string phone
    G : +boolean likesNetflix
    G : +string favoriteSeasons
    G : +boolean followsOther : boolean

```