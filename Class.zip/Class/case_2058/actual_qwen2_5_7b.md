```mermaid
classDiagram
    class Subscriber {
        +browseMovies() void
        +watchMovie(movieID: string) void
    }
    class Admin {
        +manageSubscriptions() void
    }
    class MovieStreamingService {
        -- Subscriber
        *-- Admin
        --> Subscriber : Browse Movies, Watch Movie
        ..> Admin : Manage Subscriptions
```