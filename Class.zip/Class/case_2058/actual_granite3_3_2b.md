```mermaid
classDiagram
    subscriber [1] "1" -- browsing[0..1] movie: Browse Movies
    admin [1] "1" -- using[*] watch_movie: Watch Movie
    subscriber [1] "1" -- interacting[0..1] with [1] admin: Manage Subscriptions
```