```mermaid
classDiagram
    Subscriber --> "Browse Movies" : uses
    Subscriber --> "Watch Movie" : performs
    Admin --> "Manage Subscriptions" : manages

    class Subscriber{
        +string name
        +string email
        "1" -"**" "Browse Movies" : uses
        "1" -"**" "Watch Movie" : performs
    }

    class Admin{
        +string adminName
        "1" -"**" "Manage Subscriptions" : manages
    }
```