```mermaid
classDiagram
    class Product { +string name: string }
    class Supplier { +string name: string }
    class Warehouse { +int quantity: int, +list orders: list }
    class Order { +string supplierName: string, +date: date}
    class Shipment { +string orderNumber: string, +status: string }
    class InventoryManagementSystem { +list products: list, +list suppliers: list, +list warehouses: list, +list orders: list, +list shipments: list }

    Warehouse : <|-- Product : Inheritance
    Warehouse : *-- Supplier : Aggregation
    Shipment : *--> Order : Association
    InventoryManagementSystem : <|-- SupplyChain
```