classDiagram
    class Product {
        +int ProductID
        string Name
        string Description
        double Price
        int Quantity
    }
    class Supplier {
        +int SupplierID
        string Name
        string Address
        string Contact
    }
    class Warehouse {
        +int WarehouseID
        string Location
        int Capacity
    }
    class Order {
        +int OrderID
        int ProductID
        int Quantity
        double UnitPrice
        Date OrderDate
    }
    class Shipment {
        +int ShipmentID
        int OrderID
        int WarehouseID
        Date ShipmentDate
        string Status
    }
    Product --> Supplier : supplied_by
    Product --> Order : included_in
    Warehouse --> Shipment : ships_to