```mermaid
classDiagram
    class Product {
        +string name
        +float price
        +Supplier supplier
        +Warehouse warehouse
    }
    class Supplier {
        +string name
        +list Order orders
    }
    class Warehouse {
        +string location
        +list StockedProduct products
    }
    class Order {
        +date placedDate
        +list LineItems lineItems
        +Ship ship
    }
    class Shipment {
        +ShipTo address
        +list Products products
    }
    Product "1" --|> Supplier : supplies
    Product "1" --|> Warehouse : stored
    Order "1" --|> Product : items
    Shipment "1" --> Order.ship : ships
    Supplier "1" -->*: placesOrders : has
```