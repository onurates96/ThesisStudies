```mermaid
classDiagram
class Product {
    +string name
    +decimal price
}
class Supplier {
    -string name
    -list~Product~ products
}
class Warehouse {
    +string location
    +list~Product~ inventory
}
class Order {
    -string orderID
    +date datePlaced
    +list~Product~ items
}
class Shipment {
    -string shipmentID
    +date dateShipped
    +list~Order~ orders
}
Product *-- Supplier : suppliedBy
Warehouse *-- Product : contains
Order --> Product : includes
Shipment --> Order : ships
```