```mermaid
classDiagram
    class Product {
        +string name
        +double price
        -int quantity
        +addQuantity(newQuantity:int) void
    }
    class Supplier {
        +string supplierName
        +"SupplierAddress" address
        *--"supplies" Product : supplies
    }
    class Warehouse {
        +string warehouseName
        +"WarehouseLocation" location
        o--"stores" Product : storedProducts
    }
    class Order {
        +string orderID
        +"CustomerAddress" customerAddr
        -->"contains" Product : orderedProducts
    }
    class Shipment {
        +string shipmentID
        +"ShipmentAddress" destinationAddr
        -->"includes" Order : shippedOrders
    }
```