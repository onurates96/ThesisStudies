```mermaid
classDiagram
    Product <|-- Supplier
    Supplier : +string name, -inventories()
    Warehouse <|-- Order
    Order : *-- "*" Shipment
    Shipment <|-- Delivery
    ClassA <|-- ClassB
    class C: +int quantity, -inventories()
    class D: +price, -products()
    class E: +dateCreated, -objects()
    class F: -types(), -properties(), -relationships()
    class G: -string address, -relations()
    class H: *-- "*" Products
    class I: *-- "*" Relations
    class J: -inventories()
    class K: -inventories()
    class L: +int quantity, -inventories()
    class M: *-- "*" relations()
    class N: -types(), -properties(), -relationships()
    class O: *-- "*" Customers, -relations()
    class P: *-- "*" Relations
```