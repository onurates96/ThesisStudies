```mermaid
classDiagram
    class Product {
        +string name
        +int stockQuantity
        -Supplier supplier
        -- Warehouse warehouse : 0..*
    }
    class Supplier {
        +string companyName
        +list~Product~ productsSupplied
    }
    class Warehouse {
        o-- Product productInventory "1"
    }
    class Order {
        +string orderNumber
        +Customer customer
        *-- Product orderedProducts "1..*"
    }
    class Shipment {
        -Order relatedOrder
        -- Warehouse shippingWarehouse : 0..1
    }
```