```mermaid
classDiagram
    class User {
        +int userId
        +string username
        +string password
        +List~string~ posts
        -List~Comment~ comments
        -List~Like~ likes
    }
    class Post {
        +int postId
        +string content
        +User author
        --> "1" -- "*" Comment
        --> "1" -- "*" Like
    }
    class Comment {
        +int commentId
        +string text
        +User author
        +Post post
        --> "1" -- "*" Post
    }
    class Like {
        +int likeId
        +User user
        +Post post
    }
```