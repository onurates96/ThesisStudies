classDiagram
  Class User {
    - username: String
    - email: String
    - password: String
    + login()
    + logout()
  }
  Class Post {
    - content: String
    - timestamp: DateTime
    + publish()
  }
  Class Comment {
    - text: String
    - timestamp: DateTime
    + addComment()
  }
  Class Like {
    - timestamp: DateTime
    + like()
  }
  User --> Post
  User --> Comment
  User --> Like