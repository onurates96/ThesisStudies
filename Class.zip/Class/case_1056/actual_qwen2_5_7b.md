```mermaid
classDiagram
    class User {
        +string username
        +string email
        -password string
        +login() bool
        +post(title: string, content: string) Post
        +comment(post: Post, text: string) Comment
        +like(post: Post) Like
    }
    class Post {
        +string title
        +string content
        +date createdAt date
        *User author User
        -comments Comment "0..*"
        -likes Like "0..*"
    }
    class Comment {
        +string text
        +date createdAt date
        -user User
        -- Post post Post
    }
    class Like {
        -User user User
        -- Post post Post
    }
```