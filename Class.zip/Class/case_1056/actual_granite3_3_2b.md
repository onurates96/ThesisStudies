```mermaid
classDiagram
    class User {
        +string username
        +string email
        +Password password
        +Date registrationDate
        +String bio
        +Set<Post> posts
        +Set<Comment> comments
        +Set<Like> likes
    }
    class Post {
        +int id
        +String content
        +User creator
        +Date creationDate
        +Set<Comment> comments
        +Set<Like> likes
        +List<Like>
    }
    class Comment {
        +int id
        +String content
        +User commenter
        +Post post
        +Date creationDate
    }
    class Like {
        +int id
        +User liking
        +Post post
        +Date likeDate
    }

    User "1" --> "0..*" Post : posts
    User "1..*" --> "*" Comment : comments
    User "1..*" --> "*" Like : likes
```