```mermaid
classDiagram
    class User {
        +name: string
        +email: string
        -posts: List~Post~
        -comments: List~Comment~
        -likes: Set~String~
        +balance: decimal
        +password: string
        +isAdmin: bool

        :+login(): login()
    }

    class Post {
        +title: string
        +content: text
        -user: Reference~User~

        :-create(): create()

        :+delete(): delete()
    }

    class Comment {
        +text: text
        -post: Reference~Post~
        -user: Reference~User~

        :-create(): create()

        :+delete(): delete()
    }

    class Like {
        +post: Reference~Post~
        +user: Reference~User~

        :-like(): like()
    }

    User :+posts() void
    User :+comments() void

    Post :+likes()
    Post :+comments()

    Comment :+likes()

    User :+user() void
```