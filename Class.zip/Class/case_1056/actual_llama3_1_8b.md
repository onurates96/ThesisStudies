```mermaid
classDiagram    
    class User {
        +string name
        +int id
        -string password
        +login() bool
        +register() void
    }
    class Post {
        +string content
        +int id
        +string author
        +comment() void
    }
    class Comment {
        +string text
        +int post_id
        +User user
    }
    class Like {
        +int count
        +Post post
        +User user
    }
    User --> Post : posts
    User --> Comment : comments_on
    User --> Like : likes
    
    class Diagram {
        -string name
    }

```