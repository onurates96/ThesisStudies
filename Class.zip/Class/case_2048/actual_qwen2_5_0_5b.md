```mermaid

@startuml

@endumtdown
---
title: Ride-sharing application diagram

---


## Actors
- Rider (Rider class)
  - *Driver* Driver class
  - 0:1 dependency: Rider -> Driver
- Driver (Driver class)
  - 0:1 dependency: Driver -> Rider

### Use Cases
- Request ride
  - ```Request Ride``` is the use case for both Rider and Driver.
- Accept ride
  - ```Accept Ride``` is the use case for only Rider, but it can also be used by Driver if needed.
- Complete trip
  - ```Complete Trip``` is a hypothetical end use case, representing a completed ride-sharing experience. It could involve multiple steps like paying fees, getting to your destination, etc.

### Interactions and Dependencies
## Interaction 1: Request Ride

### Actors
- Rider
- Driver (Driver class)

### Use Case: Request Ride
1. Rider requests a ride.
2. Driver approves the request by accepting it.
3. The rider pays their fees via an e-check or credit card.

```mermaid
classDiagram
    @startuml
        class Rider { ... }
        class Driver { ... }

        Rider : +rideRequest
        Driver : +acceptRide

        Ride <|-- Request Ride
```
### Interaction 2: Accept Ride

### Actors
- Rider (Rider class)
- Driver (Driver class)

### Use Case: Accept Ride
1. Rider accepts the ride.
2. Driver completes their task by completing the trip.

```mermaid
classDiagram
    @startuml
        class Rider { ... }
        class Driver { ... }

        Rider : +rideAccept
        Driver : +completeTrip

        Ride <|-- Accept Ride
```
### Interaction 3: Complete Trip

### Actors
- Rider (Rider class)
- Driver (Driver class)

### Use Case: Complete Trip
1. Rider and Driver complete the ride-sharing trip together.
2. The rider pays their final fees.
3. Driver collects the ride.

```mermaid
classDiagram
    @startuml
        class Rider { ... }
        class Driver { ... }

        Rider : +rideComplete
        Driver : +payFees

        Ride <|-- Complete Trip
```
### Interaction 4: Payment and Fare Calculation

### Actors
- Rider (Rider class)
- Driver (Driver class)

### Use Case: Payment and Fare Calculation
1. Rider pays their fees using a payment method like a credit card.
2. Driver processes the payment by completing the ride-sharing trip.

```mermaid
classDiagram
    @startuml
        class Rider { ... }
        class Driver { ... }

        Rider : +payment(creditCard)
        Driver : +rideComplete

        Ride <|-- Payment and Fare Calculation
```
### Interaction 5: Check Status (Optional)

### Actors
- Rider (Rider class)
- Driver (Driver class)

### Use Case: Check Status
1. Rider checks the status of their ride using a service like Uber or Lyft.
2. Driver logs into the service to verify the ride details.

```mermaid
classDiagram
    @startuml
        class Rider { ... }
        class Driver { ... }

        Rider : +rideCheckStatus
        Driver : +logIn

        Ride <|-- Check Status (optional)
```
### Interaction 6: Trip Planning and Booking

### Actors
- Rider (Rider class)

### Use Case: Trip Planning
1. Rider selects a destination using their preferred app or online map.
2. Rider books a ride-sharing service like Uber or Lyft.
3. Rider pays for the trip.

```mermaid
classDiagram
    @startuml
        class Rider { ... }

        Ride : +ridePickup
        Trip <|-- BookRide
```
### Interaction 7: Booking and Payment

### Actors
- Rider (Rider class)
- Driver (Driver class)

### Use Case: Booking and Payment
1. Rider books a ride-sharing trip using their rider account.
2. Driver logs into the service for payment.

```mermaid
classDiagram
    @startuml
        class Rider { ... }
        class Driver { ... }

        Ride : +ridePickup
        Trip <|-- BookRide

        Rider <|-- Payment and Fare Calculation
        Driver : +logIn
```
### Interaction 8: Traveling and Safety Check

### Actors
- Rider (Rider class)
- Driver (Driver class)

### Use Case: Traveling Safely
1. Rider takes the ride-sharing service to their destination.
2. Rider checks the safety features of the ride.

```mermaid
classDiagram
    @startuml
        class Rider { ... }
        class Driver { ... }

        Ride : +ridePickup
        Trip <|-- BookRide

        Rider <|-- SafetyCheck
```

@enduml
```