```mermaid
classDiagram
    class Rider {
        -string name
        +requestRide() void
        +completeTrip() void
    }
    class Driver {
        -string licenseNumber
        +acceptRide() void
        +completeTrip() void
    }
    Rider --> Request Ride : uses
    Driver --> Accept Ride : performs
    Rider *-- Complete Trip : experiences
    Driver *-- Complete Trip : experiences
```