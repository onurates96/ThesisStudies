```mermaid
classDiagram
    class Rider{
        +string name
        +string pickupLocation
        +string destination
        -boolean hasAcceptedRide
        RequestRide()
        AcceptRide()
        CancelRide()
    }
    class Driver{
        +string name
        +Vehicle vehicle
        +boolean isAvailable
        AcceptRide() : boolean
        CompleteTrip()
        UpdateAvailability()
    }
    Rider --> RequestRide: Request ride
    Driver --> AcceptRide: Accept ride request
    Rider <|-- RequestRide : Actor
    Driver <|-- AcceptRide : Actor
    Rider <|-- CompleteTrip : Actor (through intermediary)
    Driver <|-- CompleteTrip : Actor (through intermediary)
```