%% Use Case Diagram for Ride-Sharing Application
classDiagram
  class Rider {
    +requestRide()
    +cancelRide()
    +rateDriver()
  }
  class Driver {
    +acceptRide()
    +startTrip()
    +completeTrip()
  }
  class UseCase {}
  Rider --> UseCase : "Request Ride"
  Rider --> UseCase : "Cancel Ride"
  Rider --> UseCase : "Rate Driver"
  Driver --> UseCase : "Accept Ride"
  Driver --> UseCase : "Start Trip"
  Driver --> UseCase : "Complete Trip"
  UseCase :