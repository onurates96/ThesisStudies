mermaid
classDiagram    
    User <|-- Rider    
    Rider <|-- Driver
    RequestRide : Accept Ride
    CompleteTrip : Use ~UseCase~ (e.g., Pay ~Payment~
    AcceptRide : Get ~Rider~
    Use ~UseCase~
    DependentOn ~RequestRide~ : Use ~Driver~
class Duck{
    +string beakColor
    swim() void
    quack() void
}
class Fish{
    -int sizeInFeet
    canEat() bool
}
class Zebra{
    +bool is_wild
    run() void
}