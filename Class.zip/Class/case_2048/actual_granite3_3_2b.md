```mermaid
classDiagram
    class Rider {
        +string name
        +string destination
        +RequestRide()
        +AcceptRide(Driver d: Driver)
    }
    class Driver {
        +string vehicleType
        +Location
        +RequestRide(Rider r: Rider)
        +AcceptRide(Rider r: Rider)
        +CompleteTrip()
    }
    Rider "1" "--[Request Ride]--| Driver : Accept Ride |**0..***: Rider
    Rider "--[Complete Trip]-- Driver : Complete Trip"
```