```mermaid
classDiagram
    class Rider {
        +string name
        +login() bool
        +requestRide(destination:string) void
    }
    class Driver {
        +string name
        -vehicle:Vehicle
        +login() bool
        +acceptRide(requestedBy:Rider) void
        +completeTrip() void
    }
    class Vehicle {
        +string make
        +string model
        +getSpeed() decimal
        +accelerate() void
        +brake() void
    }
    Rider --> Driver : assigns
    Driver *-- Vehicle : owns
    class RequestRideUseCase {
        -rider:Rider
        -driver:Driver
        +perform() void
    }
    class AcceptRideUseCase {
        -rider:Rider
        -driver:Driver
        +perform() void
    }
    class CompleteTripUseCase {
        -driver:Driver
        +perform() void
    }
    Rider --> RequestRideUseCase : initiates
    Driver --> AcceptRideUseCase : performs
    Driver --> CompleteTripUseCase : performs
```