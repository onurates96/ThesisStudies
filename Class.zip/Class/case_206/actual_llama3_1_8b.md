```mermaid
classDiagram
    class Player {
        +string name
        +Item[] inventory
    }
    class Item {
        +string id
        +string name
        -Player owner
    }
    class Inventory {
        +string id
        +Item[] items
        -Game game
    }
    class Game {
        +string title
        +Inventory[] inventories
        -GameDeveloper developer
    }
    class Transaction {
        +string id
        -Item item
        -Player player
    }
    class GameDeveloper {
        +string name
        +string email
        -Game[] games
    }
    Player "1" --> "*" Item : owns
    Inventory *-- Item : contains
    Game -- Inventory : has
    Transaction -- Item : involves
    Game o-- GameDeveloper : developedBy
```