```mermaid
classDiagram
    class Player {
        +string name
        +int experiencePoints
        -List~Item~ inventory
        +addItem(item:Item) void
        +removeItem(item:Item) void
        +levelUp() void
    }
    class Item {
        +string name
        +int value
        +string rarity
    }
    class Inventory {
        +Player owner
        +List~Item~ items
    }
    class Game {
        +string title
        +GameDeveloper developer
        +List~Transaction~ transactions
    }
    class Transaction {
        +DateTime timestamp
        +Player player
        +Item item
        +string description
    }
    class GameDeveloper {
        +string name
        -List~Game~ gamesDeveloped
    }

Player "1" --> "*" Inventory
Player "1" --> "*<| Transaction : purchased"
Inventory *-- Item : contains
Game *-- Transaction : has
Game <|-- GameDeveloper : is by
GameDeveloper *-- Game : developed
```