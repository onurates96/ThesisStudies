```mermaid
classDiagram
    Player <|-- Game
    Item <|-- Inventory, Transaction
    Game <|-- Transaction, Inventory, Player
    Game <|-- (0..*), (1..*) GameInstance
    Transaction <|-- GameTransaction, InventoryTransaction
    Inventory <|-- (1..*)
    Transaction <|-- (0..*, 1..*)
    Player <|-- *; [public] : (Player)
    Game <|-- * ; [public, private] : (Game)

```