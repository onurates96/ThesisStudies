```mermaid
classDiagram
    class GameDeveloper{
        +name: string
        +affiliation: string
    }
    class Player{
        -inventory: Inventory
        +balance: decimal
        +login() void
        +logout() void
    }
    class Item{
        +name: string
        +description: string
    }
    class Inventory{
        +items: List~Item~
        *player: Player
        -- add(item: Item) void
        -- remove(item: Item) void
    }
    class Game{
        +players: List~Player~
        +startGame() void
        +endGame() void
    }
    class Transaction{
        +amount: decimal
        +type: string
        +time: DateTime
    }
    Player "1" *-- Inventory : owns
    Item "0..*" --* Inventory : is in
    Game "1" *-- Player : plays in
    GameDeveloper ..> Game : develops
    Transaction "0..*" --> Game : affects
```