classDiagram;
  class Player {
    +playerId: String
    +username: String
    +email: String
  }
  class Item {
    +itemId: String
    +name: String
    +description: String
  }
  class Inventory {
    +inventoryId: String
    +playerId: String
    +items: List<Item>
  }
  class Game {
    +gameId: String
    +title: String
    +developerId: String
  }
  class Transaction {
    +transactionId: String
    +playerId: String
    +gameId: String
    +itemIds: List<String>
    +transactionDate: Date
  }
  class Game_Developer {
    +developerId: String
    +name: String
    +headquarters: String
  }
  Player "1" -- "*" Inventory: hasInventory;
  Player "1" -- "*" Transaction: makesTransaction;
  Game "1" -- "*" Transaction: hasTransactions;
  Game_Developer "1" -- "*" Game: develops;