```mermaid
classDiagram
    class Player {
        +string name
        +Inventory inventory
    }
    class Item {
        +string name
        +int weight
        +string description
        +Price price
    }
    class Inventory {
        +Player player
        +list<Item> items
    }
    class Game {
        +string title
        +list<Transaction> transactions
    }
    class Transaction {
        +Game game
        +List<Item> itemsTransacted
    }
    class Developer {
        +string name
        +Game gameDeveloped
    }
    Player "1" -- "*" Inventory : uses
    Developer ".." Game : develops
```