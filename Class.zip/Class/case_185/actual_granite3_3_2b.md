```mermaid
classDiagram
    class Student {
        +string name
        +int studentId
        +Department dept
        +List<Course> enrolledCourses
    }
    class Course {
        +string courseCode
        +string courseName
        +Professor professor
        +Department dept
    }
    class Professor {
        +string name
        +Course[] coursesTeaching
    }
    class Department {
        +string name
        +Professor[] faculty
    }
    class Registration {
        +Student student
        +Course course
        +Date registrationDate
    }
    class Grade {
        +Student student
        +Course course
        +GradeGrade grade
    }

    Student "1" "-- Registration : has" Registration
    Course "1" "0..*" "Student : enrolls in"
    Professor "*" "<--" Course : teaches
    Department "1" "0..*" "Professor : belongs to"
    Registration "1" "1.." "Course : is registered for"
    Grade "1" "1.." "Student : receives grade for"
```