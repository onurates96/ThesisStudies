classDiagram;
  class Student {
    +studentId: String
    +name: String
    +email: String
  }
  class Course {
    +courseId: String
    +title: String
    +credits: Int
  }
  class Professor {
    +professorId: String
    +name: String
    +email: String
  }
  class Department {
    +departmentId: String
    +name: String
    +head: String
  }
  class Registration {
    +registrationId: String
    +studentId: String
    +courseId: String
    +semester: String
  }
  class Grade {
    +gradeId: String
    +registrationId: String
    +grade: String
  }
  Student "1" -- "*" Registration: registersFor;
  Course "1" -- "*" Registration: hasRegistration;
  Professor "1" -- "*" Course: teaches;
  Department "1" -- "*" Professor: hasProfessor;
  Registration "1" -- "1" Grade: hasGrade;