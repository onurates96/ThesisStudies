```mermaid
classDiagram
    class Student {
        +string name
        +int studentId
        -List~Course~ registeredCourses
        -List~Grade~ grades
        enrolls() void
    }
    class Course {
        +string courseName
        +int courseId
        +Professor instructor
        *--"1" Registration : registers
        +List~Student~ enrolledStudents
    }
    class Professor {
        +string name
        +int professorId
        +Department department
        teaches() void
    }
    class Department {
        +string name
        +int departmentId
        +Professor[] facultyMembers
        hasFaculty(p:Professor) boolean
    }
    class Registration {
        +RegistrationId registrationId
        +Course course
        +Student student
        +Grade grade
        -DateTime enrollmentDate
    }
    class Grade {
        +float value
        +String letterGrade
    }
```