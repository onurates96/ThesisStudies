```mermaid
classDiagram
    class Student {
        -name: string
        -id: int
        +enroll(course: Course) void
        +drop(course: Course) void
    }
    class Course {
        -title: string
        -code: string
        -professor: Professor
        +addStudent(student: Student) void
        +removeStudent(student: Student) void
    }
    class Professor {
        -name: string
        -id: int
        +teach(course: Course) void
    }
    class Department {
        -name: string
        -headProfessor: Professor
        *courses: Course
        +addCourse(course: Course) void
        +removeCourse(course: Course) void
    }
    class Registration {
        -student: Student
        -course: Course
        "1" --> "1": Enrollment
    }
    class Grade {
        -value: float
        -student: Student
        -course: Course
        +calculateGrade() float
    }
```