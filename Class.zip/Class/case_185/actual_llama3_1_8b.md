```mermaid
classDiagram
    class Student {
        +string studentID
        +string name
        +Course[] enrollments
    }
    class Course {
        +string courseID
        +string title
        +Professor professor
        -Department department
    }
    class Professor {
        +string professorID
        +string name
        +Course[] assignedCourses
    }
    class Department {
        +string departmentID
        +string name
        -Course[] affiliatedCourses
    }
    class Registration {
        +string registrationID
        +Student student
        +Course course
        +Grade grade
    }
    class Grade {
        +string gradeID
        +int score
        +Registration registration
    }

    Student "1" --> "*" Registration : enrollment
    Course *-- Professor : assignment
    Course -- Department : affiliation
    Registration --> Grade : record
```