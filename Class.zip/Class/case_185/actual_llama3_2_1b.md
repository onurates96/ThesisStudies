```mermaid
classDiagram
    class Student {
        +name: string
        +id: int
        -courses: List~Course~
        +grade: grade
    }
    class Course {
        +title: string
        +description: string
        +professor: Professor~
        +students: List~Student~
    }
    class Professor {
        +name: string
        +id: int
        -courses: List~Course~
        +studentGrades: Map~String~->float
    }
    class Department {
        +name: string
        +affiliations: List~Professor~
        +students: List~Student~
    }
    class Registration {
        +courseId: int
        +studentId: int
        -grade: float
    }
```