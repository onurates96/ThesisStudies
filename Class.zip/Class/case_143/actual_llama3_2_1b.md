```mermaid
classDiagram
    class User {
        +name: string
        +email: string
        -password: string (optional)
        +age: int
        +gender: string
        -isSubscribed: bool (optional)
        +subscribe(Subscription) : void
        +unsubscribe() : void
    }

    class Video {
        +title: string
        +description: string
        +genre: string
        +library: List<Playlist>
        +playCount: int
        -playStatus: bool (optional)
        +watchStatus: bool (optional)
        +share() : void
    }

    class Playlist {
        +id: int
        +name: string
        +videos: List<Video>
        +owner: User
        -isPublic: bool (optional)
        +members: List<User> (optional)
        +joinDate: datetime (optional)
    }

    class Subscription {
        +type: str
        +user: User
        -startDate: datetime
        -endDate: datetime
        +status: str (enum: "active", "inactive")
        +balance: decimal
        +paymentMethod: Payment
    }

    class Payment {
        +id: int
        +method: string
        +amount: decimal
        +timestamp: datetime
    }
```