```mermaid
classDiagram
    class User {
        +string name
        +string email
        *Subscription subscription
    }

    class Video {
        +string title
        +string description
        +string url
        +Date uploadDate
        o Playlist playlist
    }

    class Playlist {
        +string name
        +list<Video> videoList
    }

    class Subscription {
        +string planName
        +Date startDate
        +Date expiryDate
        +User user
    }

    class Payment {
        +string cardNumber
        +Date expiryDate
        +string cvv
        +Subscription subscription
    }

    User "1" --> Subscription : has
    Subscription "1" --> Payment : collects
    Video "1..*" --> Playlist : contains
```