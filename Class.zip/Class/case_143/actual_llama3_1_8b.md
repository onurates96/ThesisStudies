```mermaid
classDiagram
    class User {
        +string username
        +string email
        -password() string
    }
    
    class Video {
        +string title
        +string description
        -views() int
    }
    
    class Playlist {
        +string name
        +Video[] videos
    }
    
    class Subscription {
        -User user
        -Playlist playlist
        +cancelSubscription() void
    }
    
    class Payment {
        +decimal amount
        +date paymentDate
        -processPayment() boolean
    }
    
    User "1" --> "*..n" Playlist : subscribedTo
    Playlist "0..1" -- Video : containsVideo
    Subscription *-- Payment : requiresPayment
```