```mermaid
classDiagram
    class User {
        +string username
        +string email
        #password Hash
        -List~string~ playlists
        -List~Video~ videoLibrary
        -Subscription subscription
        -Payment paymentDetails
    }

    class Video {
        +string title
        +string description
        +string url
        -User uploader
    }

    class Playlist {
        +string name
        *Video videos : contains
    }

    class Subscription {
        +string planType
        +int duration
        -User user
        -- Payment payment
    }

    class Payment {
        +string method
        +datetime transactionDate
    }

    User "1" --> "*" Subscription
    User "1" <-- "0..*" Playlist : owns
    User *-- Video : hasUploaded
    Subscription -- Payment : linkedTo
```