classDiagram;
  class User {
    +userId: String
    +name: String
    +email: String
  }
  class Video {
    +videoId: String
    +title: String
    +duration: Int
  }
  class Playlist {
    +playlistId: String
    +userId: String
    +name: String
  }
  class Subscription {
    +subscriptionId: String
    +userId: String
    +plan: String
    +expiryDate: Date
  }
  class Payment {
    +paymentId: String
    +userId: String
    +amount: Float
    +paymentDate: Date
  }
  User "1" -- "1" Subscription: subscribesTo;
  User "1" -- "*" Playlist: creates;
  Playlist "1" -- "*" Video: contains;
  User "1" -- "*" Payment: makes;