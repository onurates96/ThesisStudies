```mermaid
classDiagram
    class User {
        -id int
        +login() bool
        +subscribe(subscription:Subscription) void
        +addVideoToPlaylist(video:Video, playlist:Playlist) void
    }
    class Video {
        -title string
        -length int
        -views int
        -- Library : 0..*
    }
    class Playlist {
        -name string
        -videos List~Video~
        +addVideo(video:Video) void
        +removeVideo(video:Video) void
    }
    class Subscription {
        -type string
        -isActive bool
        "1" -- "1" User : owns
        "0..*" -- "0..*" Video : isPartOfLibrary
    }
    class Payment {
        -amount decimal
        -method string
        +processPayment(subscription:Subscription) void
    }
```