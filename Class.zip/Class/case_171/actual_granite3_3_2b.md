```mermaid
classDiagram
    class User {
        +string username
        +string email
        +string password
        +Post createPost(string content)
        +Comment commentOnPost(int postID, string comment)
        +Like likePost(int postID)
        +Friendship requestFriendship(User friend)
        +Notification sendNotification(string message)
    }

    class Post {
        +int postID
        +string title
        +string content
        +User createdBy
        +-> Comment[] comments
        +-> Notification notifications
    }

    class Comment {
        +int commentID
        +string content
        +Post post
        +User commentedBy
        +time timestamp
    }

    class Like {
        +int likeID
        +Post post
        +User whoLiked
        +time timestamp
    }

    class Friendship {
        +int friendshipID
        +User user1
        +User user2
        +time createdAt
    }

    class Notification {
        +int notificationID
        +User notifiedUser
        +string message
        +time sentTime
    }
```