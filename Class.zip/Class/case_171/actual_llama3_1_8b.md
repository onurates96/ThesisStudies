```mermaid
classDiagram    
    class User {
        +string username
        +password : string
        +login() bool
        +post() Post
    }
    class Post {
        +int postId
        +string content
        -Comment[] comments
        -Like[] likes
        -User user : poster
        +getComments() Comment[]
        +like()
    }
    class Comment {
        +int commentId
        +string content
        -Post post : commentOn
        -User user : author
        +getPost() Post
    }
    class Like {
        +int likeId
        -Post post : likedPost
        -User user : liker
    }
    class Friendship {
        +int friendshipId
        -User user1 : userA
        -User user2 : userB
    }
    class Notification {
        +int notificationId
        -User recipient : forRecipient
        -Post post : relatedTo
        -string type : notifyType
    }

    User <|-- Friendships
    Post *-- Comment
    Comment -- Post : on
    Like -- Post : of
    Post --> User : postedBy
    Friendship -- User : with
    Notification ..> User : forRecipient
```