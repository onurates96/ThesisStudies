```mermaid
classDiagram
    class User {
        +username: string
        +password: password
        -friend: List~User
        -likes: List~Post>
        +follows: List~User>
    }
    class Post {
        +id: int
        +title: string
        +content: text
        +author: User
        +comments: List~Comment>
        -likes: List~Post>
        -shares: List~Post>
    }
    class Comment {
        +id: int
        +text: text
        -post: Post
        -user: User
    }
    class Friendship {
        +id: int
        +from: User
        +to: User
    }
    class Notification {
        +id: int
        +type: string
    }
```