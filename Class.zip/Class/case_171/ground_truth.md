classDiagram;
  class User {
    +userId: String
    +username: String
    +email: String
  }
  class Post {
    +postId: String
    +userId: String
    +content: String
    +timestamp: Date
  }
  class Comment {
    +commentId: String
    +postId: String
    +userId: String
    +content: String
    +timestamp: Date
  }
  class Like {
    +likeId: String
    +postId: String
    +userId: String
    +timestamp: Date
  }
  class Friendship {
    +friendshipId: String
    +userId1: String
    +userId2: String
    +status: String
  }
  class Notification {
    +notificationId: String
    +userId: String
    +content: String
    +timestamp: Date
  }
  User "1" -- "*" Post: creates;
  Post "1" -- "*" Comment: hasComments;
  Post "1" -- "*" Like: hasLikes;
  User "1" -- "*" Friendship: hasFriends;
  User "1" -- "*" Notification: receives;