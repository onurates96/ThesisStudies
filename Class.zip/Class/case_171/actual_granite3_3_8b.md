```mermaid
classDiagram
    class User {
        +string username
        +string passwordHash
        +List~int~ followers
        +List~int~ following
        +List~Post~ posts
        -List~Notification~ notifications
    }
    class Post {
        +string content
        +DateTime createdAt
        +User author
        +List~Comment~ comments
        +List~Like~ likes
    }
    class Comment {
        +string text
        +Post post
        +User user
        +DateTime createdAt
    }
    class Like {
        +User user
        +Post post
    }
    class Friendship {
        +User user1
        +User user2
        +bool accepted
    }
    class Notification {
        +User sender
        +User receiver
        +string messageType
        +Post relatedPost
        +DateTime created
    }
    User "1" --> "*" Post : writes
    User "1" --> "0..*" Comment : comments
    User "1" <-- "0..*" Like : likes
    User <|-- Friendship : hasFriends
    User "1" --> "1" Notification : receivesNotifications
```