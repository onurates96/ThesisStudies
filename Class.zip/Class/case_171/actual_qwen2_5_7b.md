```mermaid
classDiagram
    class User {
        -id int
        +username string
        +password string
        -email string
        +posts PostedPost "0..*"
        -friends User "*"
        +notifications Notification "0..*"
    }
    class Post {
        -title string
        -content string
        +comments Comment "0..*"
        +likes Like "0..*"
        -author User "1"
    }
    class Comment {
        -text string
        +replyTo Comment "0..*"
        -post Post "1"
        -user User "1"
    }
    class Like {
        -user User "1"
        -post Post "1"
    }
    class Friendship {
        -userA User "1"
        -userB User "1"
        +status string
    }
    class Notification {
        -title string
        -content string
        -read bool
        -sender User "1"
        -recipient User "1"
    }
```