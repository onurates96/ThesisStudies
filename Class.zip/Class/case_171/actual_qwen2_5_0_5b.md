```mermaid
mermaid
classDiagram
  User (classUser)
    -Like (likeAction)
      +Friendship (friendshipAction)
    *Post (postAction)
      +Like (likePost)
        -Reply (replyPost) (This is a hypothetical action, in real scenarios, it could involve different actions like comment, like, share etc.)
          -Post (commentAction)
            +Comment (commentText)
              -Friendship (friendshipReactions) (Friendship can include reactions such as likes, shares, and comments)
    *Comment (comments)
      +Like (likeComments)

  Post
    -Comment
      +Like (likeComments)
        -Reply (replyPost)
  *Notification (notificationAction)
    +Like (likeNotifications)

  User
    -Friendship

```