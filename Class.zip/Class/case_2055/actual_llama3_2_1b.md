```mermaid
classDiagram
    class Account {
        +string accountNumber
        - decimal balance
        + deposit(amount:decimal) void
        + withdrawal(amount:decimal) void
        classTransaction() void { }
    }

    class Customer {
        + string name
        + string address
        - int age
        + boolean isMammal()
        + Customer mate(Customer) void
        + void printDetails()
    }

    class Transaction {
        + decimal timestamp
        - decimal amount
        + bool successful
        classCustomer(Customer) void { }
        classAccount(Account) void { }
        classSystemError(String error) void { }
    }

    class BankAccount {
        + string owner
        + decimal balance
        + deposit(amount:decimal) void
        + withdrawal(amount:decimal) void
        classTransaction() void { }
    }

    class Customer{
        +string name
        +int age
        +isMammal()
        +Customer mate(Customer) 
        +void printDetails()
    }

    class Student {
        + string name
        + int age
        + boolean isMammal()
        +Student mate(Student)
        + void printDetails()
    }

class Bank ClassA {
    +string owner
    +decimal balance
    +deposit(amount:decimal) 
    +withdrawal(amount:decimal) 
}

BankClassB : Inheritance
BankClassD : Composition
BankClassE : Aggregation
BankClassF --> BankClassH : Association
```

```mermaid
classDiagram
    class Account {
        +string accountNumber
        - decimal balance
        + deposit(amount:decimal) void
        + withdrawal(amount:decimal) void
        + ClassTransaction() void { }
    }

    class Customer {
        + string name
        + string address
        - int age
        + boolean isMammal()
        + Customer mate(Customer) 
        + void printDetails()
    }

    class Transaction {
        + decimal timestamp
        - decimal amount
        + bool successful
        ClassCustomer(Customer) void { }
        ClassAccount(Account) void { }
        ClassSystemError(String error) void { }
    }

    class BankAccount {
        + string owner
        + decimal balance
        + deposit(amount:decimal) void
        + withdrawal(amount:decimal) void
        ClassTransaction() void { }
    }

    class Customer{
        +string name
        +int age
        +isMammal()
        +Customer mate(Customer)
        +void printDetails()
    }

    class Student {
        + string name
        + int age
        + boolean isMammal()
        +Student mate(Student)
        + void printDetails()
    }
```