```mermaid
classDiagram
    BankAccount <|-- Account
    Customer "1" --> "*..* *" Account
    Customer "2" --> *.."2.." Account
    Customer "3" --> *"3.." Account

    Customer "1", "2", "3" : +int id
    Account : +string owner
    Account : +decimal balance
    Account : +deposit(amount:decimal) void
    Account : +withdrawal(amount:decimal) void

    Ticket "1, 2, 3" --> "*.." BankAccount
```

This Mermaid diagram represents a banking application with classes `BankAccount`, `Customer`, and `Account`. It uses the same structure as your provided example but adds different relationships and attributes.