```mermaid
classDiagram
    class Account {
        +string owner
        +decimal balance
        +Account() void
        +deposit(amount: decimal) void
        +withdrawal(amount: decimal) void
    }
    
    class Transaction {
        -string description
        -Transaction() void
        +setDate(date: string) void
    }
    
    class Customer {
        +string name
        +Customer() void
        +login(username, password) bool
    }
    
    Account <|-- Transaction : has_transactions
    Customer -- Account : owns_account
```