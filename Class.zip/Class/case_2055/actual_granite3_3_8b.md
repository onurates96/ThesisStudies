```mermaid
classDiagram
    class Account
        +string accountNumber
        +decimal balance
        +Customer owner
        +createTransaction(transaction:Transaction) void
        +getTransactions() List~Transaction~
    class Transaction
        +Account fromAccount
        +Account toAccount
        +decimal amount
        +DateTime timestamp
        +create() void
    class Customer
        +string name
        +string address
        +string phoneNumber
        +List~Account~ accounts
        +addAccount(account:Account) void
        +removeAccount(account:Account) void
Account --> "1" createTransaction : creates
Account --> "*" getTransactions : retrieves
Customer *-- "*" Account : owns
```