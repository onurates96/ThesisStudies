```mermaid
classDiagram
    class Account {
        +decimal balance
    }
    class Transaction {
        +datetime timestamp
        +Account sender
        +Account receiver
        +decimal amount
    }
    class Customer {
        +string name
        +Account account
    }
    Account "<-" * Customer : maintains
    Customer "1"->"*": has
```