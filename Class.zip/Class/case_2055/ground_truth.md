classDiagram
  class Account {
    int account_number
    string account_type
    float balance
  }
  class Transaction {
    int transaction_id
    int account_number
    string type
    float amount
    datetime timestamp
  }
  class Customer {
    int customer_id
    string name
    string email
    string address
  }
  Customer "1" -- "*" Account : "owns"
  Account "*" -- "1" Transaction : "has"
