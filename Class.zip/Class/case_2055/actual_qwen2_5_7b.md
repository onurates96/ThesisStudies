```mermaid
classDiagram
    class Account {
        +string accountNumber
        +decimal balance
        -Date lastUpdated
        +deposit(amount:decimal) void
        +withdraw(amount:decimal) void
    }
    class Customer {
        +string customerId
        +string name
        +string email
        -List~Account~ accounts
    }
    Account *-- Customer : owns
    class Transaction {
        +string transactionId
        +Date timestamp
        +decimal amount
        -string description
        +logTransaction() void
    }
    Account --> Transaction : has
```