```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +int yearOfPublication
        -bool isAvailable
        +borrow() void
        +return() void
    }
    class Member {
        +string name
        +string id
        +Book "1" borrowedBook : Borrow
    }
    class Librarian {
        +string name
        +string id
        +Member "1..*" assistedMembers : Manage inventory
    }
    class Library {
        +string name
        +Librarian "1" librarian : Manage inventory
        +Book "*" books : Holds
    }
    class Transaction {
        +DateTime transactionDate
        +Member member : Involved in transaction
        +Book book : Involved in transaction
        +Librarian librarian : Processed transaction
    }
    Member "1" --> "1" Book : Borrow
    Librarian "1" --> "*" Library : Manage inventory
    Library "*'" --> "1..*" Book : Holds
    Member "1" --> "0..*" Transaction : Made transactions
    Librarian "1" --> "*" Transaction : Processed transactions
```