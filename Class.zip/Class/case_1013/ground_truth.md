classDiagram
  class Book {
    -title: string
    -author: string
    -ISBN: string
  }
  class Member {
    -name: string
    -id: int
  }
  class Librarian {
    -name: string
    -id: int
  }
  class Library {
    -name: string
    -location: string
  }
  class Transaction {
    -transactionId: int
    -date: Date
  }
  Book <-- Member
  Book <-- Librarian
  Book <-- Library
  Transaction <-- Member
  Transaction <-- Librarian
  Library <-- Librarian