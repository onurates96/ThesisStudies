```mermaid
classDiagram
    class LibraryManagementSystem {
        +ClassA : Book{
            attribute: title, type:string
            attribute: author, type:string
            method: borrow() void
            method: returnBook(title:string) bool
        }
        ClassB : Member{
            attribute: name, type:string
            attribute: age, type:int
            method: login(name:string) bool
            method: logout() void
        }
        classA <<--> .. Book
        classA <<--> .. Member
    }
```