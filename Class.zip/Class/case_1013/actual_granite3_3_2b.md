```mermaid
classDiagram
    classBook {
        +string title
        +string author
        +int publicationYear
        +boolean isAvailable
    }
    classMember {
        +string name
        +string memberID
        +int membershipID
        +date joinDate
    }
    classLibrarian {
        +string name
        +string librarianID
        +int departmentID
    }
    classLibrary {
        +string name
        +address
        +int libraryID
    }
    classTransaction {
        +Book borrowed
        +Member borrower
        +Date borrowDate
        +Date returnDate
        +boolean isFineDue
    }
    Book --> Library : manages
    Member <-- Library : joins
    Librarian <-- Library : worksAt
    Librarian : +manageInventory() void
    Transaction : +recordTransaction() void
    Transaction --> Book : borrows
    Transaction --> Member : returns
```