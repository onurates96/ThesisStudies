```mermaid
classDiagram
Library *-- Book : Composition
Member *-- Transaction : Composition
Librarian *-- Library : Composition
Library -- Member : Association
Transaction ..> Member : Dependency
Book : +string title
Book : +decimal price
Book : -int quantity
Library : +list~Book~
Library : +string address
Library : +login() bool
Member : +string name
Member : +email string
Member : +phone ~string~
Librarian : +string name
Librarian : +phone ~string~
Transaction : +date transactionDate
Transaction : +string status
Transaction -- Book : Association
```

This Mermaid code block represents a class diagram for a library management system, including classes like 'Book', 'Member', 'Librarian', and 'Library'. It shows relationships such as 'Borrow' and 'Return', and also includes member variables and methods for each class.