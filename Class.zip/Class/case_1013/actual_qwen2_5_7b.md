```mermaid
classDiagram
    class Library {
        +string name
        -List~Book~ books
        -List~Member~ members
        -List~Librarian~ librarians
        +addBook(book:Book) void
        +removeBook(book:Book) void
        +addMember(member:Member) void
        +removeMember(member:Member) void
        +addLibrarian(librarian:Librarian) void
        +removeLibrarian(librarian:Librarian) void
    }
    class Book {
        -string title
        -string author
        -int yearPublished
        -Library library
        +borrow(book:Book, member:Member) void : "0..1"
        +return(book:Book, member:Member) void : "0..*"
    }
    class Member {
        -string name
        -string contactInfo
        -List~Transaction~ transactions
        +borrow(member:Member, book:Book) void : "0..*"
        +return(member:Member, book:Book) void : "1"
    }
    class Librarian {
        -string name
        -Library library
        +manageInventory(inventory:Library) void : "1"
    }
    class Transaction {
        -Book book
        -Member member
        -Date borrowDate
        -Date returnDate
        +recordTransaction(book:Book, member:Member) void : "1..*"
    }
    Library --|> Book
    Library --|> Member
    Library --|> Librarian
    Book --> Transaction
    Member --> Transaction
    Librarian --> Library
```