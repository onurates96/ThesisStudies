```mermaid

classDiagram
    class Book <|-- Member
    class Member : +string name
    member Line 0: Member "1"
    member Line 2: Member "2" : +string author
    member Line 4: Member "3" : +int quantity
    member Line 6: Book : +string title
    library <|-- Member
    Member : +string name
    Member : +integer id
    member Line 0: Member "1"
    member Line 2: Member "2" : +string name
    member Line 4: Member "3" : +integer id

class Transaction <|-- Member
    Member : +string name
    Member : +double amount
    member Line 0: Member "1"
    member Line 2: Member "2" : +string name
    member Line 4: Member "3" : +double amount

class Library <|-- Member
    Member : +string name
    Member : +integer capacity
    library : +integer capacity
    member Line 0: Library "1"
    member Line 2: Library "2" : +string name
    member Line 4: Library "3" : +integer capacity

class Member <|-- Book, Transaction, Library, Student, Customer, Galaxy, Ticket
    Member : +string name
    Member : +string author
    Member : +int quantity
    class Book <|-- Member
    class Member : +string name
    class Transaction : +double amount
    member Line 0: Member "1"
    member Line 2: Member "2" : +string name
    member Line 4: Member "3" : +double amount

class Member <|-- Library, Student, Customer, Galaxy
    Member : +string name
    class Book <|-- Member
    class Transaction : +double amount
    class Library <|-- Member
    class Member : +string name
    member Line 0: Member "1"
    member Line 2: Member "2" : +string name
    member Line 4: Member "3" : +integer capacity

class Member <|-- Transaction, Ticket
    member Line 0: Member "1"
    member Line 2: Member "2" : +double amount

```mermaid