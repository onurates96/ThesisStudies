```mermaid
classDiagram
class Customer {
    +string name
    +string email
}
class Car {
    -int id
    +string make
    +string model
    +date manufacturedDate
}
class RentalTransaction {
    +int rentalId
    +Customer customer
    +Car car
    +date rentedDate
    +date returnedDate
}
class Insurance {
    +int insuranceId
    +string policyNumber
    +date startDate
    +date endDate
}
class Branch {
    +int branchId
    +string address
    +string city
}

Customer "1" --> "*" RentalTransaction : multiple rentals per customer
RentalTransaction -- Car : one car per rental
Car *-- Insurance : multiple insurances for one car
Branch o-- Customer : one branch can serve many customers
```