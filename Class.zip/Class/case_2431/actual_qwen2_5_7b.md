```mermaid
classDiagram
    class Branch {
        -string address
        +List~Car~ inventory
        *-- RentedCar
    }
    class Car {
        -string model
        -int year
        +bool isAvailable()
    }
    class Customer {
        -string name
        -string contactInfo
        +RentCar(car:Car) void
    }
    class RentalTransaction {
        -Customer customer
        -Car car
        -Date startDate
        -Date endDate
        +CalculateTotalAmount() decimal
    }
    class Insurance {
        -bool isCovered
        +ClaimCoverage(amount:decimal) void
    }
    Branch *-- Car : manages
    Customer --> RentalTransaction : makes
    RentalTransaction --> Car : involves
    RentalTransaction ..> Insurance : includes
```