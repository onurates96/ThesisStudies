mermaid
classDiagram    
    Car : +string color
    Branch : *-- Insurance
    Customer : +string name
    RentalTransaction : *--> Insurance
    VehicleType : ->* Car 
    classInsurance: ~type~ insurance_type
    
    classBranch : +string location
    classRentalCustomer : +string name : +string address

class Duck {
    string beakColor
    void swim()
    void quack()
}

class Fish {
    int sizeInFeet
    bool canEat()
}

class Zebra {
    bool isWild
    void run() 
}