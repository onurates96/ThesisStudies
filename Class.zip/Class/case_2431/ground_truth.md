classDiagram
    class Customer {
        +int CustomerID
        string Name
        string Address
        string Email
    }
    class Car {
        +int CarID
        string Model
        string Manufacturer
        string Type
        double RentalFeePerDay
    }
    class RentalTransaction {
        +int TransactionID
        int CustomerID
        int CarID
        Date RentalStartDate
        Date RentalEndDate
        double TotalCost
    }
    class Insurance {
        +int InsuranceID
        int TransactionID
        double Premium
        string CoverageDetails
    }
    class Branch {
        +int BranchID
        string Name
        string Location
    }
    Customer --> RentalTransaction : rents
    Car --> RentalTransaction : is_rented
    RentalTransaction --> Insurance : includes
    Customer --> Branch : belongs_to