```mermaid
classDiagram
    // Class Declaration
    class Customer {
        +string name
        +int id
        +date birthDate
        +string contactInfo
        +Vehicle rental *rental
        +Insurance insurance *insurance
    }

    class Car {
        +string make
        +string model
        +int year
        +string color
        +FuelType fuelType
        +Price price *price
    }

    class RentalTransaction {
        +date startDate
        +date endDate
        +Vehicle rental *car
        +Insurance insurance *insurance
        +Branch branch *branch
        +Customer customer *customer
        +float totalAmount *total
    }

    class Insurance {
        +string policyNumber
        +float premium
        +Company company *company
    }

    class Branch {
        +string name
        +string address
        +City city *city
        +Country country *country
        +ContactPerson contact *contact
    }

    // Relationships
    Customer "1" "**RentalTransaction" : uses
    RentalTransaction "1" "**Car" : has
    RentalTransaction "1" "**Insurance" : requires
    Branch "1" "**Customer" : serves
    Customer "1.." "**Branch" : located at
    Branch "1..*" "**RentalTransaction** : handles"
    Car "1.." "**Vehicle" : is a
    Insurance "1.." "**Car** : insures"
    ```