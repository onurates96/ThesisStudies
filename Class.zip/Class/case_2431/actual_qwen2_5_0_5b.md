```mermaid

classDiagram

    class Car {  
        +string make, makeYear  
        +string model, modelYear, yearOfModel
        +int price, mileage
        +carPlate, carPlateColor
    }
    Car: +string brand
    Car : +int maxSpeed
    Car : +string engineType
    Car : +color 

    Customer "1" --> "*" * -> * -* * 
    * : +Customer 
    * : +Order

    Customer "2" --> Customer "1" -* (age = 30) * -* (age < 50)
    Branch "1" --> (Customer "1") * -*

    * : +Car, carModel
    * : +Price, price
    * : +YearOfModel, modelYear

    Customer "2" --> "*" * -> * -* * 
    * : +Age, age
    * : +Order, orderDate
    * : +Brand, brand 

    Car "1" --> *"1.." * -> 1..* (carID = 1) -- (carModel) +*

    Branch "2" --> Customer "2" -*

```