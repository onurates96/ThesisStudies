```mermaid
classDiagram
    class Customer "1" -- "*" RentalTransaction
    class Car "1" -- "*" RentalTransaction
    class Insurance "1" -- "*" Car
    class Branch "1" -- "*" Car
    
    Customer <|-- RegisteredCustomer : Specialization
    RegisteredCustomer <<interface>>
    
    RentalTransaction *-- Insurance : Covers
    RentalTransaction *-- Branch : ConductedAt
```