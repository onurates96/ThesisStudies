classDiagram;
  class Customer {
    +customerId: String
    +name: String
    +email: String
  }
  class Account {
    +accountId: String
    +customerId: String
    +balance: Float
  }
  class Transaction {
    +transactionId: String
    +accountId: String
    +amount: Float
    +transactionType: String
    +transactionDate: Date
  }
  class Loan {
    +loanId: String
    +customerId: String
    +loanAmount: Float
    +interestRate: Float
    +loanStatus: String
  }
  class Credit_Card {
    +cardId: String
    +customerId: String
    +cardLimit: Float
    +availableBalance: Float
  }
  class Bank {
    +bankId: String
    +name: String
    +location: String
  }
  Customer "1" -- "*" Account: hasAccounts;
  Account "1" -- "*" Transaction: hasTransactions;
  Customer "1" -- "*" Loan: appliesForLoans;
  Customer "1" -- "*" Credit_Card: hasCreditCards;