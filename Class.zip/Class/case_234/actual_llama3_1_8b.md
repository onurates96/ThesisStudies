```mermaid
classDiagram
    class Bank {
        +string name
        +Bank()
        +login() bool
        +addCustomer(Customer) void
        +removeCustomer(Customer) void
    }

    class Customer {
        +string name
        +string address
        -Account* accounts
        +accountHistory(Transaction[]) Transaction[]
        +applyForLoan(Loan) Loan
        +getCreditCard() CreditCard
        +Bank bank : "1"
    }

    class Account {
        +string accountNumber
        +decimal balance
        -Transaction* transactions
        +Customer customer : "1"
    }

    class Transaction {
        +decimal amount
        +string description
        -Account sourceAccount : "1"
        -Account destinationAccount : "1"
        +Transaction(Account, Account) void
    }

    class Loan {
        +string loanNumber
        +decimal interestRate
        +Customer customer : "1"
    }

    class CreditCard {
        +string cardNumber
        +decimal creditLimit
        +Customer customer : "1"
    }
```