```mermaid
classDiagram
    class Bank {
        +string name
        +string address
        +list accounts Account
        +string interestRate
    }

    class Account {
        +string accountNumber
        +Bank owner
        +decimal balance
    }

    class Customer {
        +string name
        +Account customerAccount
    }

    class Transaction {
        +Customer initiator
        +Account debit
        +Account credit
        +decimal amount
        +string description
    }

    class Loan {
        +Customer borrower
        +decimal principal
        +decimal interestRate
        +date maturityDate
    }

    class CreditCard {
        +Customer owner
        +list transactions Transaction
    }

    Bank <|-- Account
    Customer : 1 * Account
    Customer --> Transaction: initiates
    Customer --> Loan: applies for
    Customer --> CreditCard: holds
    Account *-- Transaction: involved in
    Account *-- Loan: secured by
    Account *-- CreditCard: linked
```