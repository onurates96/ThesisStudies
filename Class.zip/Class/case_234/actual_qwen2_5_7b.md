```mermaid
classDiagram
    class Bank {
        +string name
        +list~Account~ accounts
        -- Customer customer
        o-- Account primaryAccount
        ..> Loan loanService
        ..|> CreditCard cardManagement
    }
    class Customer {
        -string firstName
        -string lastName
        +list~Account~ ownedAccounts
        -- Bank bank
        --> Transaction transactionHistory
    }
    class Account {
        +decimal balance
        +date accountCreationDate
        +deposit(amount:decimal) void
        +withdrawal(amount:decimal) void
        -- Customer customer
    }
    class Transaction {
        -datetime timestamp
        -string description
        +CreditCard cardUsed
        --> Account account
    }
    class Loan {
        +decimal loanAmount
        +date loanStartDate
        -- Bank bank
        --> Customer borrower
    }
    class CreditCard {
        -string cardNumber
        -float creditLimit
        -- Customer customer
        --> Transaction transactions
    }
```