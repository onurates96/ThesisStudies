```mermaid
classDiagram
    class Customer {
        - string firstName: String
            + string lastName: String
                - int age: int
                    - isMammal(): boolean
                        - mate(): void
                    + string gender: String
                    + integer loanAmount: int
                    + List<string> interests: List~string~
                : +integer accountNumber: int
        - string email: String
    }
    class Account {
        + customerID: int ->+Customer::id 
            + deposit(amount: decimal): void
            + withdrawal(amount: decimal): void
    }
    class Transaction {
        - integer transactionId: int
            - date: Date
                - amount: decimal
            + integer fromAccountID: int
                + integer toAccountID: int
                - type: string ("deposit" or "withdrawal")
    }
class Loan {
    + customerID: int ->+Customer::id 
        + loanAmount: int
        + interestRate: float
        - startDate: date
    + borrowerName: String
    - LoanStatus: enum ("pending", "approved", "defaulted"): string
}
class CreditCard {
    + accountNumber: int ->+Account::id 
        + balance: decimal
        + expirationDate: Date
    + issuingBankID: int ->+Customer::id 
        - creditLimit: float
    - cardType: String
    - holderName: String
    - isActive(): boolean
}
class Bank {
    + customerID: int ->+Customer::id 
        + accountNumber: int
        + balance: decimal
    + loanID: int ->+Loan::id 
        + borrowerName: string
    + creditCardID: int ->+CreditCard::id 
        - cardHolderName: string
}
class Relationship {
    class A : Inheritance { }
    class B : Association { }
}