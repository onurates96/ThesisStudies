```mermaid
classDiagram
    class Customer <|-- AccountHolder
    class Account *-- Transaction
    class Loan *-- Customer
    class CreditCard *-- Customer
    class Bank {
        +string name
        +List~int~ branches
        +List~Account~ accounts
        +processTransaction(transaction:Transaction) void
        +grantLoan(customer:Customer, loanDetails:Loan) void
        +issueCreditCard(customer:Customer, cardDetails:CreditCard) void
    }
    AccountHolder "1" --> "*" Account
    Customer "1" --> "*" CreditCard
    Customer "1" --> "*" Loan
```