```mermaid
mermaid
Mermaid UML Class Diagram

    class Customer {
        +string id
        +string name
        +list<*> tickets
        +* {"1"}: Ticket
    }

    class Account {
        -decimal balance
        -*"1" : Balance 
    }

    class Transaction {
        +string description
        +string amount
        +string fromAccountId
        +string toAccountId
    }

    class Loan {
        -decimal balance
        -string borrowerName
    }

    class CreditCard {
        -string cardNumber
        -string expirationYear
        -string expirationMonth
    }

    class Bank {
        -string owner
        -list<*> accounts
        +* {"1"}: Account
    }

classA <|-- classB : Inheritance
classC *-- classD : Composition
classE o-- classF : Aggregation
classG --> classH : Association
classI -- classJ : Link(Solid)
classK ..> classL : Dependency
classM ..|> classN : Realization
classO .. classP : Link(Dashed)

```