```mermaid
classDiagram
    class Book {
        +string title
        +string author
        -Date borrowDate
        -Patron borrower
        +borrow(Patron) void
        +return() void
    }
    class Patron {
        +string name
        +List~Book~ borrowedBooks
        +bool isMember
        +borrow(Book) void
        +return(Book) void
    }
    class Librarian {
        +string name
        -List~Book~ inventory
        +addBook(Book) void
        +removeBook(Book) void
        +manageInventory() void
    }
    Book --|> Patron : Borrow, Return
    Librarian *-- Book : Manage Inventory
```