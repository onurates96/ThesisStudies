```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +int yearPublished
        +boolean isAvailable
    }
    class Patron {
        +string name
        +int patronId
        +Book[] borrowedBooks
    }
    class Librarian {
        +string name
        +Patron[] managedPatrons
    }
    Book <-- Librarian : ManageInventory
    Patron --> Librarian : Borrow
    Patron --> Book : Borrow
    Librarian --> Patron : Return
```