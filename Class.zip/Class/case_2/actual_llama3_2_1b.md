```mermaid
classDiagram
    class Patron {
        +string name: ~Name~
        -int age: ~Age~
        -isStudent() bool
    }
    
    class Book {
        +string title: ~Title~ 
        +int id: ~ID~  
        +bool isBorrowed(bool) int?:
        +bool canBeReturned(bool): ~ReturnStatus~
    }
    
    class Librarian {
        -Patron: ~StudentId~
        +void borrowBook(Book): return true
        +void returnBook(Book): cancel Borrow()
    }
    
    class Library {
        +List<Librarian> librarianList: ~ListId~ 
        +void addBorrower(Patron): add to list
    }
```