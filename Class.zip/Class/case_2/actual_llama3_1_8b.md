```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +string publicationDate
        -int ISBN
        +bool isAvailable()
        +String borrow(Book borrower)
        +void returnBook()
    }

    class Patron {
        +string name
        +string email
        +bool isLibrarian
        +void login()
        +void logout()
        +List~Book~ borrowBooks() : getBorrowedItems
        +void returnBook(Book book) : returnItem
        +Patron(String name, String email)
    }

    class Librarian {
        +string name
        +string email
        +bool isAdmin
        +void manageInventory()
        +void checkOut(Book book)
        +void checkIn(Book book)
    }
    
    Book o-- Patron : borrow
    Patron -- Book : return
    Librarian --> Book : Manage
    Book <-- Librarian : Maintain
```

This class diagram represents a basic library management system with classes for `Book`, `Patron`, and `Librarian`. The relationships between these classes illustrate borrowing, returning, managing inventory, checking out/checking in books, and maintaining the book collection. 

The cardinality/multiplicity on relations is represented as follows:
- A patron can borrow multiple books ("1" -> "*").
- A librarian manages one book ("1" -> "1").
- A patron returns one book ("1" -> "0..1").