```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +int publicationYear
        -boolean isAvailable
        +addCopy() void
        +removeCopy() void
    }
    class Patron {
        +string name
        +string patronID
        -List~Book~ borrowedBooks
        +borrowBook(book:Book) void
        +returnBook(book:Book) void
    }
    class Librarian {
        +string name
        +string librarianID
        +manageInventory() void
        +addBook(book:Book) void
        +removeBook(book:Book) void
    }
    Patron "1" --> "*" borrowedBooks : borrows
    Librarian "1" --> "*" managedBooks : manages
    Book --> Patron : isBorrowedBy
    Book --> Librarian : manageInventory
```