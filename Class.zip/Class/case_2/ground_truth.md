classDiagram
  Class Book{
    +title: string
    +author: string
    +ISBN: string
    +available: boolean
  }

  Class Patron{
    +name: string
    +libraryCardNumber: string
  }

  Class Librarian{
    +name: string
    +employeeID: string
  }

  Book <-- Borrow
  Book <-- Return
  Librarian <-- Manage Inventory