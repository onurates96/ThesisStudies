```mermaid
classDiagram
class Book {
  title: Book
}
class Patron {
  title: Patron
}

class Librarian {
  title: Librarian
  class A { // Class declaration with space between class and {} blocks

    Borrow:
      "1" -- "0..*" Book;
      "1" : *{"1"};
  
    Return:
      (Return) -> {"1", "1"}{"1", "*" Book};
  
    Manage Inventory:
      |+*{"1", "2"}{"1", "*" Book};
  }
}
```