```mermaid
classDiagram
    class User
        +int userId
        +string username
        +string password
        -List~string~ roles
        +register() void
        +login() bool
        +updateProfile() void
    class Video
        +int videoId
        +string title
        +string description
        +User uploader
        +DateTime uploadDate
        +play() void
        +like() void
    class Playlist
        +int playlistId
        +string name
        +List~Video~ videos
        +createUser() void
        +addVideo() void
        +removeVideo() void
    class Subscription
        +int subscriptionId
        +User user
        +Video video
        +DateTime startDate
        +DateTime endDate
        +cancel() void
    class Comment
        +int commentId
        +string text
        +User user
        +Video video
        +DateTime createdAt
        +reply() void
    User "1" --> "*" Playlist : creates
    User "1" <-- "0..*" Subscription : has
    Video --> "1" Comment : has
    User --> "0..*" Video : uploads
    User --> "0..*" Comment : makes
```