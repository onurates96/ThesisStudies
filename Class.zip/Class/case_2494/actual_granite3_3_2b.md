```mermaid
classDiagram
    class User {
        +string name
        +string email
        +Password pwd
        +Set<Video> watchedVideos
        +Playlist favoritePlaylists
        +Subscription subscription
        +void login(string password:Password)
        +void logout()
        +void uploadVideo(Video video):void
        +void commentOnVideo(Comment comment, Video video):void
    }
    class Video {
        +string title
        +string description
        +Date uploadDate
        +Media file_path
        +User uploader
        +Playlist playlist
        +List<Comment> comments
        +Association : watchedBy - User
    }
    class Playlist {
        +string name
        +Set<Video> videos
        +Association : createdBy - User
    }
    class Subscription {
        +Date startDate
        +Date enddate
        +User subscriber
        +SubscriptionType type
    }
    class Comment {
        +string text
        +Video video
        +User creator
        +Date postedDate
        +Association : belongsToVideo - Video
        Association : likes - User
    }
    User "1" -- "*" Subscription : has
    Subscription "1" -- "*" User : subscribedBy
    User "1..*" -- "1.." Playlist : manages
    Playlist "1.." -- "+Video : contains"
    Video "1.." -- "*Comment : has"
    Comment "1" -- "1..*" User : postedBy
```