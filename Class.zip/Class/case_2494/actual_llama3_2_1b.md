```mermaid
classDiagram
    class User {
        +name: string
        +email: string
        +password: byte
        -age: int
        -gender: string
        +isMammal(): bool
        +mate(): void
    }
    
    class Video {
        +title: string
        +description: text
        +duration: int
        +views: int
        +likes: int
    }
    
    class Playlist {
        +name: string
        +videos: List~Video~
    }
    
    class Subscription {
        +type: string
        +user: reference User
        +plan: int
    }
    
    class Comment {
        +id: int
        +content: text
        +user: reference User
    }
    
    class Playlist as User { 
        +videos: List~Video~
    }
```