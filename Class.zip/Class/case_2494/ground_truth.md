classDiagram
    class User {
        +int UserID
        string Name
        string Email
        Date JoinDate
    }
    class Video {
        +int VideoID
        string Title
        string Description
        int Duration
        Date UploadDate
    }
    class Playlist {
        +int PlaylistID
        int UserID
        string Title
        string Description
    }
    class Subscription {
        +int SubscriptionID
        int UserID
        double MonthlyFee
        Date SubscriptionDate
    }
    class Comment {
        +int CommentID
        int UserID
        int VideoID
        string Content
        Date CommentDate
    }
    User --> Video : uploads
    User --> Playlist : creates_playlist
    User --> Subscription : subscribes
    Video --> Playlist : in_playlist
    Video --> Comment : has_comments