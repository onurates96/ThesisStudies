```mermaid
classDiagram
    class User {
        +string username
        +password() bool
        -login(string, string) bool
    }
    class Video {
        +string title
        +string description
        +upload() void
        +delete() void
    }
    class Playlist {
        +string name
        *-- Video : includes
    }
    class Subscription {
        +User user
        +Video video
        *-- User : subscribedTo
        *-- Video : isSubscribed
    }
    class Comment {
        +string content
        +Video video
        *-- User : commentedBy
        -delete() void
    }

    User ..> Subscription : depends_on
    Video -- Comment : contains
```