```mermaid
classDiagram
    class User {
        -id: int
        +login(username: str, password: str) bool
        +subscribe(subscription: Subscription) void
        +addComment(video: Video, content: str) Comment
    }
    class Video {
        +title: str
        +duration: int
        +isPremium: bool
        -views: int
        --Playlist videos: *Video
        o--User uploader: User
    }
    class Playlist {
        +name: str
        "0..*" Video videos: *
        *--User owner: User
    }
    class Subscription {
        +tier: str
        +expiryDate: date
        -is_active: bool
    }
    class Comment {
        +content: str
        +timestamp: datetime
        -likes: int
        --Video video: Video
        *--User author: User
    }
    User --> Video : subscribesTo
    User "1" --> "0..*" Comment : adds
    Video --> Playlist : belongsTo
    Subscription <|-- PremiumSubscription : Inheritance
```