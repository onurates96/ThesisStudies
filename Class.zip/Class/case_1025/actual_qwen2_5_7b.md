```mermaid
classDiagram
    class Book {
        +title: string
        +author: string
        +isbn: string
    }
    class Member {
        +name: string
        +id: int
        +borrowedBooks "0..*": Book
    }
    class Librarian {
        +name: string
        +id: int
        +managesMembers "1": Member
    }
    class Library {
        +name: string
        +capacity: int
        *-- Librarian : employs
        *-- Member : serves
        o-- Book : holds
    }
    Library --> Book : manages
    Librarian --> Member : updates
```