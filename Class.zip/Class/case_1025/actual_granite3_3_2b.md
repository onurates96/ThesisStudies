```mermaid
classDiagram
    classBook {
        +string title
        +string author
        +int yearPublished
        +bool isAvailable
    } *-- Library o-- Librarian
    classMember {
        +string name
        +string memberID
        +date joinDate
        +string address
        +contactInfo
        +LoanList book*
    } --> Book o-- Librarian
    classLibrarian {
        +string name
        +string contactInfo
        +List<Book> checkedOutBooks
    }
    classLibrary {
        +string name
        +address
        +Contact info
        +List<Member> members
        +List<Book> books
    }
```