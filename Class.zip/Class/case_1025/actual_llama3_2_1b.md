```mermaid
classDiagram
    class User {
        +string name: 
        +email: 
        -password: 
        -isAdmin(): bool
        +logout(): void
    }
    class Book {
        +string title: 
        +publisher: 
        +isbn: string
        -borrowedBy(): User[]
        +returnDate(date: Date): void
    }
    class Librarian {
        +string name: 
        -password: 
        +staffId(): int
        +addBook(Book): void
        -removeBook(Book): Book
    }
    class Library {
        +string name: string
        -location: string
        +address: Address
    }
```