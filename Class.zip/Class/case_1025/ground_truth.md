classDiagram
  Class Book{
    -ISBN
    -title
    -author
  }
  Class Member{
    -ID
    -name
  }
  Class Librarian{
    -ID
    -name
  }
  Class Library{
    -name
  }
  Book <-- Member : borrows
  Librarian --> Library : manages