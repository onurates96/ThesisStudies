```mermaid
classDiagram
    class Book {
        +string title
        -decimal price
    }
    class Member {
        +string name
        +bool hasCard : membership
    }
    class Librarian {
        +string name
        -bool isAuthorized : authority
    }
    class Library {
        +string location
        -Book[] collection : inventory
    }
    Book ..> Member : borrowedBy
    Member --> Library : belongsTo
    Library *-- Librarian : staffMember
```