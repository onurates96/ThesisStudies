```mermaid
classDiagram
    class Book{
        -int id
        +string title
        +string author
        +bool isAvailable
    }
    class Member{
        -int membershipId
        +string name
        +string contactInfo
    }
    class Librarian{
        -int staffId
        +string name
        +string contactInfo
        +List~string~ borrowedBooks : "0..*"
    }
    class Library{
        -int libraryId
        +string address
        +List~Book~ availableBooks : "*"
        +List~Member~ registeredMembers : "*"
        +Librarian primaryLibrarian : "1"
    }
    Member "1" --> "*" Librarian : registers
    Librarian --> Book : manages
    Library "1" --> Librarian : employs
    Library <|-- Book : contains
```