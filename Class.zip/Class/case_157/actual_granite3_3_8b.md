```mermaid
classDiagram
    class Book
        +string title
        +string isbn
        +Author author
        +Publisher publisher
        +int quantity
        -Inventory inventory
        +placeOrder(order:Order) void
    class Author
        +string name
        -List~Book~ books
    class Publisher
        +string name
        -List~Book~ books
    class Inventory
        +Book[] books
        +addBook(book:Book) void
        +removeBook(book:Book) void
    class Order
        +OrderID id
        +Customer customer
        +List~Book~ items
        +placeOrder() void
Author --> "1" "writes" Book : writes
Publisher --> "1" "publishes" Book : publishes
Inventory *-- Book : manages
Order --> "1" "contains" List~Book~ : contains
```