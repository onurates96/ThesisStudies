```mermaid
classDiagram
    class Book {
        +string title
        +Author author
        +Publisher publisher
    }
    class Author {
        -int id
        -string name
    }
    class Publisher {
        -int id
        -string name
    }
    class Inventory {
        +list<Book> books
        +Order currentOrder
    }
    class Order {
        -list<Book> orderedBooks
        -Customer customer
    }
    class Customer {
        -string name
        -string address
    }

    Book <|-- Author : belongsTo
    Book <|-- Publisher : belongsTo
    Inventory *-- Book : contains
    Inventory --> Order : manages
    Order -- Customer : relatesTo

    Author "1" --> "*" Book : writes
    Publisher "1" --> "*" Book : publishes
```