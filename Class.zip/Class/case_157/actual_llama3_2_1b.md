class A {
    +string name: String
    -int age: int
}

B : -string address: string
C : +string publisher: String
D : +int quantity: int
E : classF : composition(D : -string title: String, D : -int year: int)
F : classG : aggregation(E : -classF, E : -classH)
G : association(F : -classH, F : -classI)
H : realization(G : -classI, H : +classB)
I : dependency(G : -classI, G : -classJ)
J : link(Solid, I)