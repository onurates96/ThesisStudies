classDiagram;
  class Book {
    +isbn: String
    +title: String
    +authorId: String
    +publisherId: String
    +price: Float
  }
  class Author {
    +authorId: String
    +name: String
    +email: String
  }
  class Publisher {
    +publisherId: String
    +name: String
    +address: String
  }
  class Inventory {
    +inventoryId: String
    +isbn: String
    +quantity: Int
  }
  class Order {
    +orderId: String
    +isbn: String
    +quantity: Int
    +orderDate: Date
  }
  Author "1" -- "*" Book: writes;
  Publisher "1" -- "*" Book: publishes;
  Book "1" -- "*" Inventory: inInventory;
  Book "1" -- "*" Order: ordered;