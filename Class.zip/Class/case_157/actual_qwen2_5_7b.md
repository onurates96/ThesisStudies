```mermaid
classDiagram
    class Author {
        +string name
        +List~Book~ booksWritten
    }
    class Book {
        +string title
        -Author author
        +Publisher publisher
        -- "1" .. "0..*" Inventory
    }
    class Publisher {
        +string name
        +List~Book~ publishedBooks
    }
    class Inventory {
        +int quantity
        *-- Book book
    }
    class Order {
        +int orderID
        -List~Book~ booksOrdered
        -- "0..*" Inventory inventory
    }
```