```mermaid
classDiagram
    class Book {
        +string title
        +Author author
        +Publisher publisher
        +Inventory inventory
        +Order order
    }
    class Author {
        +string name
    }
    class Publisher {
        +string name
    }
    class Inventory {
        +int quantity
    }
    class Order {
        +Date placed
    }
    Book "1" "-- Inventory : has -"
    Author "*-- Book : writes -"
    Publisher "*-- Book : publishes -"
    Inventory "1..*" "-- Book : contains -"
    Order "1..*" "-- Book : ordered -"
```