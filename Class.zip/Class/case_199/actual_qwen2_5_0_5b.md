```mermaid

classDiagram
    Customer <|-- BookStore
    Customer : +int id
    BookStore <|-- *Book
    Book <|-- *ISBN
    *Book : *2019-01-01

    Order <|-- Book, *Customer, *Review
    *Order : +id, +CustomerId, +OrderId, +OrderDate
    Review <|-- *Customer, *Order
    *Customer : +int id, +FirstName, +LastName, +EmailAddress, +PhoneNumber
    *Review : +string content

    Payment <|-- *User, *Transaction
    *Payment : +id, +Amount:decimal, +Date:datetime

    Review <|-- *Book, *Customer, *Order
    *Review : +string content, +*Book, +*Customer, +*Order
```