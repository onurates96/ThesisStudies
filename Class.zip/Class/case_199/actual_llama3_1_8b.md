```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +decimal price
    }
    class Customer {
        +string name
        -string password
        -bool isPremium
    }
    class ShoppingCart {
        -Book[] items
    }
    class Order {
        -Customer customer
        -Book[] books
    }
    class Payment {
        -Order order
        -decimal amount
    }
    class Review {
        -Book book
        -string comment
        -int rating
    }

    Book "*" -- "1" Customer : purchased
    Customer "1" --> "* ShoppingCart : hasCart
    ShoppingCart "*" -- "0..*" Order : containsOrders
    Order "-1" *--> "1" Payment : processedByPayment
    Review "-1" *-- "1" Book : forBook
```