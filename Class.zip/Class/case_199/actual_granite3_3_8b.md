```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +int yearOfPublication
        -List~int~ availableCopies
        +addCopy() void
        +removeCopy() void
        +getDetails() string
    }
    class Customer {
        +string name
        +string email
        +string address
        -ShoppingCart shoppingCart
        +addBookToCart(book:Book) void
        +removeBookFromCart(book:Book) void
        +placeOrder(cart:ShoppingCart) : Order
    }
    class ShoppingCart {
        +List~Book~ items "1..*"
        +totalAmount : decimal
    }
    class Order {
        +OrderID : string
        +Customer : Customer
        +Date : Date
        +List~Book~ items "1..*"
        +Payment : Payment
        +Status : string ("pending", "completed", "cancelled")
    }
    class Payment {
        +PaymentMethod : string
        +TransactionID : string
        +Amount : decimal
        +Timestamp : Date
    }
    class Review {
        +Customer : Customer
        +Book : Book
        +Rating : int "1..5"
        +Comment : string
        +Date : Date
    }
    Customer "1" --> "*" ShoppingCart
    Customer "1" --> "*" Order
    Order "1" *--> "1" Payment
    Order "1" --> "1..*" Review
    Book "1" --> "0..*" Review
```