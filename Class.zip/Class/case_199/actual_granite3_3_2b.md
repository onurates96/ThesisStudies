```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +int yearPublished
        +string ISBN
        +BookInventory inventory
    }
    class Customer {
        +string name
        +string address
        +Email email
        +Order purchases
    }
    class ShoppingCart {
        +List<Book> items
    }
    class Order {
        +Customer customer
        +ShoppingCart cart
        +Payment payment
        +Review reviews
    }
    class Payment {
        +int amount
        +PaymentMethod method
    }
    class Review {
        +Customer reviewer
        +Book book
        +Rating rating
        +Comment comment
    }
    Book <|-- BookInventory
    Customer "1" --> Order "1.."
    Customer "1" --> ShoppingCart "1.."
    Order : contains Payment
    Order : generates Review
```