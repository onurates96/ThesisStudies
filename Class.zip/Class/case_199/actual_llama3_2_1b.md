class Diagram {
  class Book {
    +title string
    +author string
    +publisher string
    +price decimal
    +quantity int
  }
  
  class Customer {
    +id int
    +name string
    +email string
    +password string
  }
  
  class ShoppingCart {
    +id int
    +customer id -> Book[]
    +book book
    +total decimal = 0.0
  }
  
  class Order {
    +id int
    +customer id -> Customer[]
    +cart shopping cart
    +total decimal = 0.0
  }
  
  class Payment {
    +id int
    +order id -> Order[]
    +amount decimal
  }
  
  class Review {
    +id int
    +order id -> Order[]
    +book book
    +rating int
    +text string
  }
}