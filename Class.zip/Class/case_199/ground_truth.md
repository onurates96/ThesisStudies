classDiagram;
  class Book {
    +bookId: String
    +title: String
    +author: String
    +price: Float
  }
  class Customer {
    +customerId: String
    +name: String
    +email: String
  }
  class Shopping_Cart {
    +cartId: String
    +customerId: String
    +items: List<Book>
  }
  class Order {
    +orderId: String
    +customerId: String
    +items: List<Book>
    +totalAmount: Float
    +orderDate: Date
  }
  class Payment {
    +paymentId: String
    +orderId: String
    +amount: Float
    +paymentDate: Date
  }
  class Review {
    +reviewId: String
    +bookId: String
    +customerId: String
    +rating: Int
    +comment: String
  }
  Book "1" -- "*" Review: hasReviews;
  Customer "1" -- "*" Review: writesReview;
  Customer "1" -- "*" Shopping_Cart: hasCart;
  Shopping_Cart "1" -- "*" Book: containsBooks;
  Customer "1" -- "*" Order: placesOrder;
  Order "1" -- "1" Payment: requiresPayment;