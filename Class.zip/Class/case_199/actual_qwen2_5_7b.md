```mermaid
classDiagram
    class Book {
        +string title
        +string author
        +float price
    }
    class Customer {
        -string name
        -string email
        -List~Book~ booksBought
    }
    class ShoppingCart {
        -Customer customer
        *Book books
        -- addItem(Book) void
        -- removeItem(Book) void
    }
    class Order {
        -ShoppingCart cart
        +int orderNumber
        +DateTime orderedAt
    }
    class Payment {
        -Order order
        +string paymentMethod
        +decimal amountPaid
        +processPayment() void
    }
    class Review {
        -Customer customer
        -Book book
        +string reviewText
        +rating: int
    }
    Book --|> ShoppingCart : contains
    Customer *-- ShoppingCart : has
    ShoppingCart --> Order : places
    Order ..> Payment : requires
    Customer o-- Review : gives
```