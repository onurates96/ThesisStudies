```mermaid
classDiagram
    class Customer {
        +string name
        +int id
        ++isActive() bool
        Customer : +addTicket(Ticket) void
        Customer : -removeTicket(Ticket)
    }
    
    class Account {
        +string owner
        +decimal balance
        ++deposit(amount:decimal) void
        +withdrawal(amount:decimal) void
        
        ++getBalance() decimal get()
    }
    
    class Transaction {
        +int id
        +datetime time
        +float amount
        ++createTransaction(Record) void
        
        ++getTransactions() List(Transaction) get()
    }
    
    class Loan {
        +string owner
        +decimal interestRate
        +decimal principal
        ++applyLoan(float amount) void
        +payLoan(amount:float) void
        
        ++hasLoan() bool get()
    }
    
    class Employee {
        +string name
        +int id
        ++addTask(Task) void
        
        ++getTasks() List<Task> get()
    }
```