```mermaid
classDiagram
    Customer <|-- Account
    Account <-~*> Transaction
    Loan <|-- Account, Customer
    BankEmployee <|-- Loan
```

This Mermaid code provides a basic structure for an online banking system. It includes classes like `Customer`, `Account`, and relationships such as customer accounts, transactions, loans, and employee roles. The class diagram follows the specified rules and conventions.