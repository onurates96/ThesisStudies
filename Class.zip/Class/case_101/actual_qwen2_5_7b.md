```mermaid
classDiagram
    class BankEmployee {
        +string name
        +int id
        -- Account managedAccounts[*]
    }
    class Customer {
        +string name
        -int age
        *-- Account accounts[*]
        o-- Loan loans[0..*]
    }
    class Account {
        +decimal balance
        -Date openingDate
        --> BankEmployee managingBankEmployee
        --> Customer owner
        -- Transaction transactions[0..*]
    }
    class Transaction {
        +string type
        -decimal amount
        -Date date
    }
    class Loan {
        +decimal amount
        -Date startDate
        -Date endDate
        o-- Account account
    }
```