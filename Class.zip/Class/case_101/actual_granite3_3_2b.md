```mermaid
classDiagram
    classCustomer {
        +string name
        +decimal balance
        +void deposit(amount: decimal)
        +void withdrawal(amount: decimal)
        *-- Transaction : maintains
    }

    classAccount {
        +string accountNumber
        +Customer owner
        +decimal balance
        +void transferTo(customer: Customer, amount: decimal)
    }

    classTransaction {
        +string description
        +date date
        +decimal amount
        +Account sender
        +Account receiver
    }

    classLoan {
        +string loanType
        +decimal principal
        +BankEmployee officer
        +void apply()
    }

    classBankEmployee {
        +string name
        +Department dept
        +void processTransaction(transaction: Transaction)
        +void approveLoan(loan: Loan)
        +void manageAccount(account: Account)
    }

    Customer "1" --> Account : has
    BankEmployee : uses Account
    Transaction : involves Account, Customer
    Loan : involves BankEmployee
    Department "1..*" BankEmployee : organized by
```