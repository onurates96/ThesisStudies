```mermaid
classDiagram
    class Customer {
        +string name
        +string address
        +string contactInfo
        -List<Account> accounts
        +login() bool
        +registerAccount(accountType:AccountType) Account
        -makeTransaction(transaction:Transaction) void
        -applyForLoan(loanType:LoanType, amount:decimal) Loan
    }
    class Account {
        +AccountType accountType
        +decimal balance
        +string owner
        -List<Transaction> transactions
        +deposit(amount:decimal) void
        +withdrawal(amount:decimal) void
    }
    class Transaction {
        +decimal amount
        +Account sourceAccount
        +Account targetAccount
        +DateTime timestamp
        +string description
    }
    class Loan {
        +LoanType loanType
        +decimal principal
        +decimal interestRate
        +List<Payment> payments
        -Customer customer
        +makePayment(payment:Payment) void
    }
    class BankEmployee {
        +string employeeID
        +string role
        -List<Customer> managedCustomers
        +assignRole(customer:Customer, role:Role) void
    }

Customer "1" --> "*" Account : has
BankEmployee "1" --> "*" Customer : manages
Account *-- Transaction : contains
Loan *-- Payment : includes
```