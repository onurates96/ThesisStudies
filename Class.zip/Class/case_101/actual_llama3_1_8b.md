```mermaid
classDiagram
    class BankEmployee {
        +string employeeID
        +string name
        -password string
        -login() bool
    }
    class Customer {
        +string customerID
        +string name
        +Account "1"
    }
    class Account {
        +string accountNumber
        +decimal balance
        +Customer "1" --> "*"
        +Transaction "0..n"
        +Loan "..*"
    }
    class Transaction {
        +string transactionID
        +decimal amount
        +date date
        +Account "1" <-- "*"
    }
    class Loan {
        +string loanID
        +decimal interestRate
        +decimal amountBorrowed
        +Customer "0..n"
        +BankEmployee "..>"
    }
    BankEmployee --> Customer : employee-assigned-customer
    Customer "1" <-- Account : customer-owns-account
    Account "0..1" <-- Loan : account-may-have-loan
```