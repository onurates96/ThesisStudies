classDiagram;
  class Customer {
    +customerId: String
    +name: String
    +email: String
  }
  class Account {
    +accountId: String
    +balance: Float
    +type: String
  }
  class Transaction {
    +transactionId: String
    +accountId: String
    +amount: Float
    +date: Date
  }
  class Loan {
    +loanId: String
    +customerId: String
    +amount: Float
    +interestRate: Float
  }
  class Bank_Employee {
    +employeeId: String
    +name: String
    +role: String
  }
  Customer "1" -- "*" Account: owns;
  Account "1" -- "*" Transaction: includes;
  Customer "1" -- "*" Loan: appliesFor;
  Bank_Employee "1" -- "*" Account: manages;