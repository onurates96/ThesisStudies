```mermaid
classDiagram
    class Restaurant {
        +string name
        +Menu menu
        ~Order[] orders
        -Customer[] reservations
    }
    class Menu {
        +string[] items
        ~Chef chef
        Restaurant -- "owns" Menu : owns
    }
    class Chef {
        +string name
        -Recipe[] recipes
        Menu *-- Recipe : prepares
        Restaurant --> Chef : assigns
    }
    class Order {
        +decimal total
        -Customer customer
        -MenuItem[] items
        Restaurant -- "processes" Order : processes
    }
    class Reservation {
        +datetime date
        -Customer customer
        -Table table
        Restaurant *-- Table : reserves
    }
    class Customer {
        +string name
        ~Order[] orders
        -Reservation[] reservations
        Restaurant --> Customer : serves
    }
    class MenuItem {
        +decimal price
        -Recipe recipe
        Menu -- "includes" MenuItem : includes
    }
    class Recipe {
        +string description
        -Ingredient[] ingredients
        Chef -- "develops" Recipe : develops
    }
```