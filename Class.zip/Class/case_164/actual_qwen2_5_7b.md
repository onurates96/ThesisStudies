```mermaid
classDiagram
    class Restaurant {
        -name: string
        +addMenu(menu: Menu) void
        +removeMenu(menu: Menu) void
    }
    class Menu {
        -items: list~Item~
        +addItem(item: Item) void
        +removeItem(item: Item) void
    }
    class Item {
        -name: string
        -price: decimal
    }
    class Chef {
        -name: string
        +prepareOrder(order: Order) void
    }
    class Order {
        -items: list~Item~
        +addMenuItem(item: Item) void
        +removeMenuItem(item: Item) void
    }
    class Reservation {
        -customer: Customer
        -date: datetime
        +makeReservation(date: datetime, customer: Customer) void
    }
    class Customer {
        -name: string
        -reservation: Reservation
        +makeReservation(date: datetime) void
    }
    Restaurant *-- Menu : serves
    Chef --|> Order : prepares
    Order --> Item : contains
    Customer o-- Reservation : has
```