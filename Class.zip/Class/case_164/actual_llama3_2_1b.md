```mermaid
classDiagram
    Restaurant : +string name
    classMenuClass {
        +string[] menuItems
    }
    Menu : +Restaurant+ *-- classMenuClass
    Chef : +string chefName
    classOrderClass {
        +string orderNumber
        +string customerName
        -int orderTime
    }
    Order : +Chef+ *-- classOrderClass
    classReservationClass {
        +string reservationId
        +date dateOfArrival
    }
    Reservation : +classReservationClass+ *-- classReservationClass
    classCustomerClass {
        +string customerName
        -int customerID
    }
    Customer : +classCustomerClass+ *-- classCustomerClass
```