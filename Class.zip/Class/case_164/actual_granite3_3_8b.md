```mermaid
classDiagram
    class Restaurant <|-- Menu
        Restaurant : +string name
            Restaurant --> "1" -- "*" Order : placedBy
        Restaurant *-- Chef : assignedTo
    class Menu {
        +List~string~ items : menu
        +add(item:string) void
        +remove(item:string) void
    }
    class Chef {
        +string specialty
        +prepare(dish:string) void
    }
    class Order {
        +Reservation reference
        +Customer customer
        +List~MenuItem~ items : orderDetails
        +process() void
    }
    class Reservation {
        +DateTime time : reservedFor
        +Customer customer
        +int numberOfGuests
        +boolean confirmed : status
    }
    class Customer {
        +string name
        +string contactInfo
        :Reservations "0..*"
        :Orders "1..*"
    }
```