```mermaid
classDiagram
    class Restaurant {
        +string name
        +string location
        +Chef assignedChef
        +Menu menu
        +Reservation reservation
        +List<Customer> customers
        --> Menu: serves
        *-- Reservation: has
        o-- Customer: places order with
    }
    class Menu {
        +string dishName
        +string description
        +float price
        *-- Restaurant: offeredBy
    }
    class Chef {
        +string name
        +string specialty
        *-- Restaurant: assignedTo
    }
    class Order {
        +string id
        +List<MenuItem> items
        o-- Restaurant: processes
        ..> Payment: requires for confirmation
    }
    class Reservation {
        +Date date
        +Time time
        +int partySize
        --> Restaurant: bookedAt
    }
    class Customer {
        +string name
        +string contactInfo
        +List<Reservation> reservations
        +List<Order> orders
        o-- Restaurant: placesOrderWith
    }
    class MenuItem {
        +string name
        +string description
        +float price
        *-- Menu: item
    }
```