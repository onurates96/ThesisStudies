classDiagram;
  class Restaurant {
    +restaurantId: String
    +name: String
    +location: String
  }
  class Menu {
    +menuId: String
    +restaurantId: String
    +itemName: String
    +price: Float
  }
  class Chef {
    +chefId: String
    +name: String
    +specialty: String
  }
  class Order {
    +orderId: String
    +restaurantId: String
    +customerId: String
    +menuItems: List<String>
    +orderDate: Date
  }
  class Reservation {
    +reservationId: String
    +restaurantId: String
    +customerId: String
    +reservationDate: Date
  }
  class Customer {
    +customerId: String
    +name: String
    +email: String
  }
  Restaurant "1" -- "*" Menu: hasMenu;
  Chef "1" -- "*" Menu: prepares;
  Customer "1" -- "*" Order: places;
  Customer "1" -- "*" Reservation: makes;