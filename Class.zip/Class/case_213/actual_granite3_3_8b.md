```mermaid
classDiagram
    class Patient {
        +string name
        +int age
        +string gender
        -list<MedicalRecord> medicalRecords
        +addMedicalRecord(record: MedicalRecord) void
        +removeMedicalRecord(record: MedicalRecord) void
    }
    class Doctor {
        +string name
        +string specialty
        -list<Appointment> appointments
        +scheduleAppointment(date: Date, patient: Patient) void
        +cancelAppointment(appointment: Appointment) void
    }
    class Nurse {
        +string name
        +Department department
        -list<Patient> assignedPatients
        +assignPatient(patient: Patient) void
        +dischargePatient(patient: Patient) void
    }
    class Department {
        +string name
        -list<Nurse> nurses
        +addNurse(nurse: Nurse) void
        +removeNurse(nurse: Nurse) void
    }
    class Appointment {
        +DateTime date
        +Doctor doctor
        +Patient patient
        +status StatusEnum // enum values: Scheduled, Completed, Cancelled
    }
    class MedicalRecord {
        +string recordID
        +Patient patient
        +Doctor doctor
        +string notes
    }

    Patient "1" --> "*" Appointment : scheduledBy
    Doctor <|-- Nurse : specialistNurse
    Doctor --> Appointment : makesAppointmentFor
    Nurse o-- Department : worksIn
    Department *-- Nurse : employs
    Appointment --> MedicalRecord : relatedTo
    Patient --> MedicalRecord : has
```