```mermaid
classDiagram
    class Patient {
        -name: string
        +age: int
        -gender: string
        +addDoctor(Doctor): void
        +removeDoctor(Doctor): void
    }
    class Doctor {
        +name: string
        -specialization: string
        +scheduleAppointment(Appointment): void
        +treatPatient(Patient): void
    }
    class Nurse {
        -name: string
        +handlePatient(Patient): void
        +monitorHealth(Patient): void
    }
    class Appointment {
        +date: date
        +time: time
        +status: string
    }
    class MedicalRecord {
        -recordId: int
        -patientId: int
        +addEntry(entry: string): void
    }
    class Department {
        -name: string
        +manageDoctor(Doctor): void
        +assignNurse(Nurse): void
    }

    Patient "1" -- "0..*" Doctor : Assigns
    Patient "1" -- "1..*" MedicalRecord : Has
    Appointment "1" -- "1" Doctor : Schedules with
    Appointment "1" -- "1" Patient : For
    Department "1" -- "1.." Doctor : Manages
    Department "1" -- "1.." Nurse : Assigns
```