classDiagram;
  class Patient {
    +patientId: String
    +name: String
    +dob: Date
    +address: String
  }
  class Doctor {
    +doctorId: String
    +name: String
    +specialty: String
  }
  class Nurse {
    +nurseId: String
    +name: String
  }
  class Appointment {
    +appointmentId: String
    +patientId: String
    +doctorId: String
    +dateTime: DateTime
  }
  class Medical_Record {
    +recordId: String
    +patientId: String
    +doctorId: String
    +diagnosis: String
    +prescription: String
  }
  class Department {
    +deptId: String
    +name: String
  }
  Patient "1" -- "*" Appointment: hasAppointments;
  Patient "1" -- "*" Medical_Record: hasRecords;
  Doctor "1" -- "*" Appointment: schedules;
  Doctor "1" -- "*" Medical_Record: manages;
  Nurse "1" -- "*" Appointment: assists;