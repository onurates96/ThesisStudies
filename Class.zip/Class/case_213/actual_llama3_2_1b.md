```mermaid
graph LR;
    classPatient { label: Patient; }
    classDoctor { label: Doctor; }
    classNurse { label: Nurse; }
    classAppointment{ label: Appointment; }
    classMedicalRecord{ label: Medical Record; }
    classDepartment{ label: Department; }

    Patient["age", "string"]
    Doctor["gender", "string"]
    Nurse["isMammal()", "boolean"]
    Doctor["isSpecialist()", "boolean"]

    Appointment{"date", "date"}
    Appointment["doctor", "Doctor"]
    Appointment["patient", "Patient"]

    MedicalRecord["recordDate", "date"]
    MedicalRecord["recordType", "string"]
    MedicalRecord["medicalHistory", "string"]

    Department["departmentName", "string"]
    Department["headOfDepartment", "Doctor"]

    classDose { label: Dose; }
    classPrescription { label: Prescription; }

    Doctor --> classDose : prescribe()
    Doctor --> classPrescription : order()

    classA : +BankAccount
    classB : Inheritance

    classC -- composition relationship
        classD : classC

    classE o-- classF : aggregation relationship
        classG : classE

    classI "-- association relationship"
        classJ : classI

    classK ..> classL : dependency relationship
    classM ..|> classN : realization relationship
    classO .. classP : link solid relationship
```