```mermaid
mermaid
classDiagram
    Patient <|-- Doctor
    Doctor <|-- Nurse
    Nurse <|-- Appointment
    Appointment <|-- MedicalRecord
    MedicalRecord <|-- Department
    Department <|-- Hospital
```
This Mermaid code generates a valid class diagram for the provided hospital management system. It shows the relationships between classes like 'Patient', 'Doctor', 'Nurse', 'Appointment', 'MedicalRecord', and 'Department'. The relationship labels follow the specified rules and format guidelines.