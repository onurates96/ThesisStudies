```mermaid
classDiagram
    class Patient {
        +string name
        +string address
        +date birthDate
    }
    class Doctor {
        -string specialty
        -boolean isOnDuty
    }
    class Nurse {
        -string department
        -boolean isCertified
    }
    class Appointment {
        +string date
        +time time
        -Patient patient
        -Doctor doctor
    }
    class MedicalRecord {
        +string diagnosis
        +string treatmentPlan
        -Patient patient
    }
    class Department {
        +string name
        -Nurse nurse
    }

    Patient <-- "has" Appointment : has_appointments
    Doctor <-- "treats" Appointment : treats_appointments
    Nurse <-- "works_in" Department : works_in_department
    MedicalRecord <-- "belongs_to" Patient : belongs_to_patient

    class Department {
        +string name
        -Nurse nurse
    }
```