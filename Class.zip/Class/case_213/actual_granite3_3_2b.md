```mermaid
classDiagram
    class Patient {
        +string name
        +date birthDate
        +string gender
        +Department department
        +MedicalRecord medicalRecord
    }
    class Doctor {
        +string name
        +Department department
        +List<Nurse> nurses
        +Appointment appointment
    }
    class Nurse {
        +string name
        +Doctor doctor
        +List<Appointment> appointments
    }
    class Appointment {
        +date date
        +Patient patient
        +Doctor doctor
        +Nurse nurse
    }
    class MedicalRecord {
        +string id
        +Patient patient
        +List<Appointment> appointments
        +Doctor doctor
    }
    class Department {
        +string name
        +List<Doctor> doctors
        +List<Nurse> nurses
    }

    Patient "1" "-- Department : contains" Department
    Doctor *-- Nurse : manages
    Appointment --> MedicalRecord : records patient data
    MedicalRecord :1..1** Appointment
    Department "1..*" -- Patient : located
```