```mermaid
classDiagram
    class Customer {
        -name: string
        -address: string
        +placeOrder(order: Order) void
    }
    class Order {
        +orderNumber: int
        +date: Date
        *items: List~Item~
        -- Warehouse : stocks
        --> Shipping : ships
        ..> DeliveryPersonnel : delivers
    }
    class Warehouse {
        -stock: Map~string, int~
        +manageStock(item: string, quantity: int) void
    }
    class Shipping {
        +shipOrder(order: Order) void
    }
    class DeliveryPersonnel {
        -personnelID: int
        +deliverOrder(order: Order) void
    }
```