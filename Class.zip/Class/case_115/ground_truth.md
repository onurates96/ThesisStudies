classDiagram;
  class Order {
    +orderId: String
    +customerId: String
    +orderDate: Date
  }
  class Customer {
    +customerId: String
    +name: String
    +address: String
  }
  class Warehouse {
    +warehouseId: String
    +location: String
  }
  class Shipping {
    +shippingId: String
    +orderId: String
    +warehouseId: String
    +deliveryDate: Date
  }
  class Delivery_Personnel {
    +personnelId: String
    +name: String
    +vehicle: String
  }
  Customer "1" -- "*" Order: places;
  Order "1" -- "*" Shipping: hasShipments;
  Warehouse "1" -- "*" Shipping: manages;
  Delivery_Personnel "1" -- "*" Shipping: delivers;