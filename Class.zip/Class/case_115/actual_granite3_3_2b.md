```mermaid
classDiagram
    class Order {
        +int id
        +string customer_id *
        +Warehouse warehouse
        +Shipping shipping
        +DeliveryPersonnel delivery_personnel
        +date created_at
    }
    class Customer {
        +int id
        +string name
        +Order orders *
    }
    class Warehouse {
        +int id
        +string location
        +Order order_list o--
    }
    class Shipping {
        +int id
        +Warehouse warehouse
        +Order order
        +date shipment_date
    }
    class DeliveryPersonnel {
        +int id
        +string name
        +Shipping shipments *
    }

    Customer "1" --> "*" Order : places
    Order : contains Warehouse
    Order : uses Shipping
    Shipping : generates Shipment
    DeliveryPersonnel : processes Shipment
```