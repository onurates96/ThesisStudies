```mermaid
classDiagram
    class Order {
        +string orderID
        +Customer placedBy
        +Warehouse from
        +Shipping shippedBy
        +DeliveryPersonnel assignedTo
        +boolean status
        +void placeOrder()
        +void updateStatus()
    }
    class Customer {
        +string customerID
        +string name
        +string address
        +string contactInfo
        -List~Order~ placedOrders
    }
    class Warehouse {
        +string warehouseID
        +string location
        +List~Product~ stockedProducts
        +void receiveGoods()
        +void dispatchGoods()
    }
    class Shipping {
        +string shippingID
        +string trackingNumber
        +boolean shipped
        +void packOrder()
        +void shipOrder()
    }
    class DeliveryPersonnel {
        +string personnelID
        +string name
        +string contactInfo
        +List~Order~ assignedOrders
        +void deliverPackage()
    }
```