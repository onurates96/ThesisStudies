```mermaid
classDiagram
    Warehouse <|-- Order
    Warehouse *-- Customer
    Order : +string orderId
    DeliveryPersonnel : +string name
    Shipping : +void
    Delivery : +void
    class DeliveryPersonnel {
        +string role
        +isAvailable() bool
    }
```