```mermaid
classDiagram
    class Order {
        +string orderNumber
        +date orderDate
        -Customer customer : placedBy
    }
    class Customer {
        +string name
        +string address
        -Order[] orders : placed
    }
    class Warehouse {
        +string warehouseNumber
        +location location
        -Product[] products : stored
    }
    class Shipping {
        +date shippingDate
        +string trackingNumber
        -Delivery delivery : shippedTo
    }
    class Delivery {
        +date deliveryDate
        -Customer recipient : deliveredTo
        -Order order : contains
    }
    class DeliveryPersonnel {
        +string personnelID
        +string name
        -Order[] orders : assigned
        -Vehicle vehicle : uses
    }
    Customer "1" --> "*" Order : placedBy
    Warehouse "--> Shipping : storesProducts
    Order "--> Shipping : shippedFrom
    Shipping "--> Delivery : shippedTo
    Order "--> Delivery : contains
    DeliveryPersonnel "--> Order : assigned
```