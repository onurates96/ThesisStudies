```mermaid
classDiagram
    Order "1" --> "*" *{"1"}
    *Customer "1" --> "*" *{"1"}
    Customer "1" --> "*" *{"1..*"}
    DeliveryPerson "1" --> "*" *{"1"}
    Warehouse "1" --> "*" *{"1"}
    Shipping "1" --> "*" *{"1"}
    DeliveryPerson "1" --> "*" *{"1"}
```