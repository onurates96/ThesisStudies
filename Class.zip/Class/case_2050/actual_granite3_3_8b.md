```mermaid
classDiagram
    class Product {
        +int productId
        +string productName
        +float price
        -String description
        +addReview(review:String) void
    }
    class Customer {
        +string customerId
        +string name
        +string email
        -List<Order> orders
        +placeOrder(orderDetails:OrderDetails) void
    }
    class Order {
        +int orderId
        +Customer placedBy
        +Product* products
        +float totalAmount
        +Payment paymentInfo
        +String status
    }
    class Payment {
        +String paymentId
        +float amount
        +String paymentMethod
    }
    Product "1" --> "*" Order : has
```