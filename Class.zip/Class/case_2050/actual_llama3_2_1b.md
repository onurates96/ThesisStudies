```mermaid
classDiagram
    class Product {
        +id: int32
        +name: string
        +price: decimal
        -category: string
    }
    
    class Customer {
        +id: int32
        +email: string
        +name: string
        +orders: List<Product>
        -balance: decimal
    }
    
    class Order {
        +id: int32
        +customer_id: int32
        +product_id: int32
        +quantity: int32
        +total_price: decimal
        +status: string
    }
    
    class Payment {
        +id: int32
        +order_id: int32
        +amount: decimal
        -time: datetime
    }
    
    class OrderItem {
        +id: int32
        +product_id: int32
        +quantity: int32
        +price: decimal
    }
```