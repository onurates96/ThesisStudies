```mermaid
classDiagram
    class Product {
        +string name
        +decimal price
        -string description
        +addImage(imagePath:string) void
        +removeImage() void
    }
    class Customer {
        +string firstName
        +string lastName
        +emailAddress email
        -List~Order~ orders
        +placeOrder(product:Product) Order
    }
    class Order {
        +decimal totalAmount
        +Date orderDate
        *Customer customer
        "1" --> "0..*" LineItem : contains
    }
    class LineItem {
        +int quantity
        +string productID
        -Product product
        +calculateTotal() decimal
    }
```