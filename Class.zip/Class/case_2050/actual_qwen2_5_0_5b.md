```mermaid
classDiagram
    Customer A {A1, A2,...} (must follow exactly)
    Customer B : +int age
    Customer C : +string name
    Customer D : +hasPhoneNumber bool
    Customer E : +emailAddress
    Customer F : *--* --+*
    Customer G : +hasName, +hasAge bool
    Customer H : -int budget
    Customer I {1} --> Customer J (must follow exactly)
    Customer K (X) --> Customer L (must follow exactly)
    Customer M {1} --> Customer N (must follow exactly)
    Customer O : *--* --+*
    Customer P (X) : +hasName, +hasAge bool
```

Explanation:
- The example diagram defines classes `Customer`, `A`, and several relationships.
  - Each class has a single method for creating new instances. Methods are named using the dot notation.
  - Relationships between classes: direct inheritance (`class A { }`), composition (`+int age` -> `+hasName, +hasAge bool`), aggregation (`Customer B : +string name`). For relationships with multiple values (e.g., having a specific name or age in different instances), the use of `++* --+*` is required.
  - Cardinality for each relationship: `A "1" --> "*" Customer`.
- Relationships like `Customer A {1}` are defined using `{1} -> Customer`, which indicates a "hasOne" relationship with no specific value attached.