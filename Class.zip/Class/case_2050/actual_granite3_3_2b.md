```mermaid
classDiagram
    class Product {
        +string name
        +float price
        +string description
        +Image image
        +Category category
        +Stock int stock
        +class Customer adds
    }
    class Customer {
        +string name
        +Address address
        +Email email
        +Password password
        +class Order adds
        +list orderItems Orders
    }
    class Order {
        +DateTime date
        +float totalPrice
        +Status status
        +class Product[] items Products
    }
    Product "1" ..--> Customer : places * Order
```