classDiagram
  class Product {
    int product_id
    string name
    float price
    int stock_quantity
  }
  class Customer {
    int customer_id
    string name
    string email
  }
  class Order {
    int order_id
    int customer_id
    datetime order_date
    float total_amount
  }
  Customer "1" -- "*" Order : "places"
  Order "*" -- "*" Product : "contains"
