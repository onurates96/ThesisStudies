```mermaid
classDiagram
    class Product {
        +string name
        +decimal price
        +int stockLevel
        -processPayment(paymentMethod: string) bool
        +getDiscount() decimal
        +calculateTotalPrice() decimal
    }
    
    class Customer {
        +string name
        +string email
        +string address
        +placeOrder(product: Product, quantity: int) Order
        +viewOrders()
        -updateProfile(newInfo: string) bool
    }
    
    class Order {
        +int orderID
        +decimal totalCost
        -processOrder(paymentMethod: string) bool
        +getOrderStatus() string
    }
    
    Product "*" -- "1" Customer : orders
    Customer "1" --> "*| Order : hasOrders
```