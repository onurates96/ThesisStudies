```mermaid
classDiagram
    class Song {
        +string title
        +string artist
        +int duration
    }
    class Playlist {
        +List<Song> songs
        +string name
    }
    class User {
        +string name
        +List<Playlist> playlists
        +int favoriteGenre
    }
    User "1" "--*-- Playlist : contains
    User "--*-- Song : plays
```