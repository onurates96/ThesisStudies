classDiagram
  class Song {
    int song_id
    string title
    string artist
    string album
  }
  class Playlist {
    int playlist_id
    string name
    int user_id
  }
  class User {
    int user_id
    string username
    string email
  }
  User "1" -- "*" Playlist : "owns"
  Playlist "*" -- "*" Song : "includes"
