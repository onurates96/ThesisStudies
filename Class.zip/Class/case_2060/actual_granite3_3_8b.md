```mermaid
classDiagram
    class Song {
        +string title
        +string artist
        +int duration
        -Album album
    }
    class Playlist {
        +string name
        *--"1" Song songs : contains
    }
    class User {
        +string username
        +string password
        "1" --> "0..*" Playlist playlists : has
    }
```