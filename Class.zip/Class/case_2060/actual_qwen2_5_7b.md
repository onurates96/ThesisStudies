```mermaid
classDiagram
    class Song {
        +string title
        +string artist
        -List~Song~ likedSongs
    }
    class Playlist {
        +string name
        *-- Song songs
    }
    class User {
        +string username
        ~bool isPremium
        +login() bool
        +logout() void
    }
    User --* Playlist : owns
    Song --> Playlist : includedIn
```