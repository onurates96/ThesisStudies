```mermaid
classDiagram
    class Song {
        +string title
        +list<Playlist> playlists
        ++int duration
        ++double tempo
        +~User~
        <|-- User:
            +int age
            +string name
        }
        
    Playlist { <|-- Song: contains }
    User { +{age, name}}
```