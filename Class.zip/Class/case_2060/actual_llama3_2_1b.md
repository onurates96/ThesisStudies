```mermaid
classDiagram
    class Song {
        +title
        +artist
        +genre
        +duration
        +playlist()
    }

    class Playlist {
        +name
        +description
        +songs()
        +addSong(song:Song)
    }

    class User {
        +id
        +username
        +password
        +preferences()
        +login(username:string, password:string)
    }
```