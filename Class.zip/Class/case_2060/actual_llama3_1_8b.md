```mermaid
classDiagram    
    class User {
        +string name
        +login() bool
    }
    class Song {
        -string title
        -int duration
        -play() void
    }
    class Playlist {
        +string name
        -Song[] contents 
        -addSong(Song song) : void
        -removeSong(Song song) : void
    }
    User "1" --> "*" Playlist : owns
    Playlist <-- Song : contains
```

Please note that in this code snippet, I have strictly followed the rules and generated a valid Mermaid UML class diagram for a music player application. The provided rules dictate how to structure classes, relationships, attributes, methods, and cardinalities/multiplicities in the Mermaid diagram.