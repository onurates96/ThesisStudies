```mermaid
classDiagram
    class Customer {
        -name: string
        -id: int
        +rentCar(carId: int, days: int) void
    }
    class Car {
        -model: string
        -make: string
        *branchLocation: BranchLocation
        +isAvailable() bool
    }
    class Reservation {
        -customerId: int
        -carId: int
        -startDate: date
        -endDate: date
        +createReservation(customerId: int, carId: int, startDate: date, endDate: date) void
    }
    class RentalAgreement {
        -customer: Customer
        -car: Car
        -reservation: Reservation
        +generateAgreement() void
    }
    class Payment {
        -amount: decimal
        -paymentDate: date
        -status: string
        +processPayment(amount: decimal, paymentDate: date) bool
    }
    class BranchLocation {
        -address: string
        *car: Car "0..*"
        +manageInventory() void
    }
    Customer --> Reservation : rents
    Reservation --> Car : reserves
    RentalAgreement <|-- Reservation : realization
    Payment ..> RentalAgreement : processes
    BranchLocation o-- Car : manages
```