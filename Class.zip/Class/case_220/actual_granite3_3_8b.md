```mermaid
classDiagram
    class Customer {
        +string name
        +int customerId
        -List~Car~ preferredCars
        +makeReservation(car:Car) Reservation
        +pay(amount:decimal) Payment
    }
    class Car {
        +string licensePlate
        +string model
        -BranchLocation location
        +isAvailable() bool
    }
    class Reservation {
        +Customer customer
        +Car car
        +datetime startTime
        +datetime endTime
        -Payment payment
    }
    class RentalAgreement {
        +Reservation reservation
        +Customer customer
        +BranchLocation branch
        +datetime startDate
        +datetime endDate
        -Payment payment
    }
    class Payment {
        +datetime transactionDate
        +decimal amount
        +PaymentMethod method
    }
    class BranchLocation {
        +string address
        +List~Car~ availableCars
        +manageReservations() void
        +processRentalAgreement(agreement:RentalAgreement) void
    }
```