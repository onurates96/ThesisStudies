```mermaid
classDiagram
    classCustomer {
        +string name
        +string contactInfo
        +List<Reservation> bookings
    } *-- classBranchLocation "1": manages
    +string carModel
    +date lastMaintenance
    classCar {
        +string carModel
        +string color
        +Date purchaseDate
        +decimal dailyRate
    } o-- classReservation : reserves
    o-- classRentalAgreement : agreesUpon
    +string status // e.g., 'available', 'rented'
    classReservation {
        +string customerName
        +date bookingDate
        +date pickupDate
        +date returnDate
        +string carModel
        +decimal rentalRate
        +boolean isPaid
    } --> classPayment : pays
    ..> classRentalAgreement : needs
    ..> classBranchLocation : operatesIn
    classRentalAgreement {
        +date agreementDate
        +string customerName
        +string carModel
        +decimal agreedRent amount
        +boolean isAccepted
    }
    classBranchLocation {
        +string locationName
        +string address
        +contactInfo
        +List<Car> availableCars
    }
```