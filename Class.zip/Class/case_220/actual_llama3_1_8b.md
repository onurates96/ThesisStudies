```mermaid
classDiagram    
    class Customer {
        +string name
        +email : string
        +phoneNumber : string
        -private password : string
        +login() bool
        +bookCar(car: Car) Reservation
        +viewReservations() void
    }
    class Car {
        +string model
        +string color
        +int yearOfManufacture
        +isAvailable(bool)
        +assignToBranch(branchLocation: BranchLocation) void
    }
    class Reservation {
        -private customer : Customer
        -private car : Car
        +getRentalAgreement() RentalAgreement
        +getPaymentStatus() string
    }
    class RentalAgreement {
        +string agreementNumber
        +dateOfAgreement : date
        +rentalPeriod : period
        -private reservation : Reservation
        -private payment : Payment
    }
    class Payment {
        +string paymentMethod
        +amountPaid : decimal
        +paymentDate : date
        +setPaymentStatus() string
    }
    class BranchLocation {
        +string address
        +branchManager : Customer
        +assignCars(cars: Car[]) void
        +manageReservations(reservations: Reservation[]) void
    }

    Car "1" --> "*" RentalAgreement 
    Customer "1" --> "*" Reservation
    Reservation <-- "0..n" Payment
    BranchLocation *-- Car
```