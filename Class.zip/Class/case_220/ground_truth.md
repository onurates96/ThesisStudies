classDiagram;
  class Customer {
    +customerId: String
    +name: String
    +email: String
  }
  class Car {
    +carId: String
    +make: String
    +model: String
    +year: Int
  }
  class Reservation {
    +reservationId: String
    +customerId: String
    +carId: String
    +pickupDate: Date
    +returnDate: Date
  }
  class Rental_Agreement {
    +agreementId: String
    +customerId: String
    +carId: String
    +pickupDate: Date
    +returnDate: Date
    +totalCost: Float
  }
  class Payment {
    +paymentId: String
    +agreementId: String
    +amount: Float
    +paymentDate: Date
  }
  class Branch_Location {
    +branchId: String
    +name: String
    +location: String
  }
  Customer "1" -- "*" Reservation: makesReservation;
  Customer "1" -- "*" Rental_Agreement: rents;
  Car "1" -- "*" Reservation: hasReservations;
  Car "1" -- "*" Rental_Agreement: isRented;
  Branch_Location "1" -- "*" Car: hasCars;