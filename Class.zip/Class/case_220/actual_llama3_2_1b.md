```mermaid
classDiagram
    class Customer {
        + string name: String
        + int age: int
        + boolean isMammal: bool
        
        -string address: string
        + void bookCar( Car )
        + void pay(BankAccount)
        
        -void cancelReservation(Customer)
    }
    
    class Reservation {
        -string customerName: string
        + string carId: string
        + int startTime: int
        + int endTime: int
        
        + void cancel()
    }
    
    class Car {
        + integer id: int
        + String brand: string
        + String model: string
        
        + void rent(Customer)
    }
    
    class Payment {
        + decimal amount: decimal
        - customerPayment(BankAccount)
        
        + boolean success: bool
        
        + void process()
    }
    
    class BranchLocation {
        + integer id: int
        + String address: string
        
        + void open(Customer)
    }
    
    class RentalAgreement {
        + Customer customerId: int
        -carId: int
        + datetime agreementDate: datetime
        
        + void signCustomer(Rental Agreement)
    }
```