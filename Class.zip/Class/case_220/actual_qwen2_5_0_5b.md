```mermaid
classDiagram
    Customer "1" --* Branch Location
    Car ||-- Rental Agreement : +Car
    Car : +Customer
    Reservation | |-- Branch Location : +Reservation
    Payment  *-- Branch Location : +Payment
    Branch Location <|-- "* "1" -> "* [1..*" "2"]
```