```mermaid
classDiagram
    class User {
        +string username
        +string password
        -List~Bid~ placedBids
    }
    class Auction {
        +Item itemForAuction
        +User auctionOwner
        -Bid highestBid
        "1" --> "0..*" Bid : contains
    }
    class Bid {
        +User bidder
        +int bidAmount
        -- "1" --> "1" Auction : placedIn
    }
    class Item {
        +string itemName
        +string description
        o-- "1" Auction : listedIn
    }
    class Payment {
        +string paymentMethod
        +decimal amountPaid
        ..> "0..*" Bid : relatedTo
    }
```