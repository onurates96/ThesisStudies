classDiagram
    class User {
        +int UserID
        string Username
        string Email
        string Address
    }
    class Auction {
        +int AuctionID
        int SellerID
        string Title
        string Description
        double StartingPrice
        Date StartTime
        Date EndTime
        string Status
    }
    class Bid {
        +int BidID
        int AuctionID
        int BidderID
        double Amount
        Date BidTime
    }
    class Item {
        +int ItemID
        string Name
        string Description
        string Category
    }
    class Payment {
        +int PaymentID
        int BidID
        Date PaymentDate
        double Amount
        string Method
    }
    User --> Auction : lists
    Auction --> Bid : receives
    Bid --> Auction : placed_on
    Bid --> Payment : pays
    User --> Bid : makes
    Item --> Auction : offered_for