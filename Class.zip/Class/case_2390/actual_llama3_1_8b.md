```mermaid
classDiagram
class User {
    +username string
    +password string
}
class Auction {
    +id int
    -items Item[]
    -bids Bid[]
    -winner User
}
class Bid {
    +id int
    -amount decimal
    -auction Auction
    -user User
}
class Item {
    +id int
    -name string
    -description string
    -price decimal
    -auction Auction
}
class Payment {
    +id int
    -amount decimal
    -auction Auction
    -user User
}
User "1" --> "*" Auction : bids
Auction *-- Item : contains
Item *-- Bid : bids
Payment -- Auction : payment
```