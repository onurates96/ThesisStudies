```mermaid
classDiagram
    class User {
        +string username
        +string password
        +string email
        -List~int~ bids
        -List~Item~ items
        -List~Payment~ payments
    }
    class Auction {
        +string title
        +Item item
        +List~Bid~ currentBids
        +User creator
        +DateTime startTime
        +DateTime endTime
        User <|-- "1" create : creates
        Item --|> "1" has : auctions an item
    }
    class Bid {
        +User bidder
        +Auction auction
        +int amount
        User --> "1..*" Auction : places bids on
    }
    class Item {
        +string name
        +Category category
        +float price
        +List~Image~ images
        Category --|> "1" has : has categories
    }
    class Payment {
        +User payer
        +Auction winner
        +float amount
        +DateTime date
        User --> "1" pays for : makes payments
        Auction <-- "1" received payment from : receives payments
    }
```