classDiagram
    User <|-- Auction
    Bid : +int itemId:integer id:integer timestamp:timestamp status:status
    Item : +string name:string description:string price:decimal quantity:integer sold:bool
    Payment : +bool successful?:bool fee?:decimal
    classPayment : ~Payment ClassA{
        isSuccessful() bool
        getFee(decimal) => fee
    }