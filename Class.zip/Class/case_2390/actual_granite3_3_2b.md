```mermaid
classDiagram
    class User {
        +string username
        +string password
        +string email
        +int balance
        +void placeBid(Auction auction, int amount)
        +void viewBids(Auction auction)
    }
    class Auction {
        +string title
        +string description
        +int startingPrice
        +Date startTime
        +Date endTime
        +int highestBidAmount
        +User highestBidder
        +list<Bid> bids
        +-> Payment payment
    }
    class Bid {
        +User bidder
        +int amount
        +Date placedAt
        +Auction auction
        +-> User highestBidder
    }
    class Item {
        +string title
        +string description
        +int startingPrice
        +Date endTime
        +User seller
        +list<Payment> payments
    }
    class Payment {
        +User receiver
        +int amount
        +Date paymentAt
    }

    User "1" --> Auction : placesBid
    Auction -> Bid : placesBid
    Item : haspayments : Aggregation
    Payment : paysItem : Aggregation
```