```mermaid
classDiagram
    Patient <|-- Doctor
    Doctor <|-- Nurse
    Nurse <|-- AssistantNurse
    AssistantNurse <|-- MedicalStaff
    MedicalStaff <|-- MedicalRecord
    MedicalRecord <|-- MedicalHistory
    MedicalHistory <|-- Appointment
    Appointment <|-- MedicalAppointment
    MedicalAppointment <|-- MedicalConsultation

```
In this Mermaid class diagram, we have defined the following classes and relationships:

1. `Patient` and its relationship with `Doctor`, which is a direct relationship.

2. `Doctor` and its relationship with `Nurse`, which is also a direct relationship.

3. `Nurse` and its relationship with `AssistantNurse`, which is an indirect relationship.

4. `AssistantNurse` and its relationship with `MedicalStaff`, which is another direct relationship.

5. `MedicalStaff` and its relationship with `MedicalRecord`, which is also a direct relationship.

6. `MedicalRecord` and its relationship with `MedicalHistory`, which is another direct relationship.

7. `MedicalHistory` and its relationship with `Appointment`, which is a direct relationship.

8. `Appointment` and its relationship with `MedicalAppointment`, which is another direct relationship.

9. `MedicalAppointment` and its relationship with `MedicalConsultation`, which is also an indirect relationship.

10. `MedicalConsultation` and its relationship with the `MedicalStaff` class, which is a direct relationship.

This diagram represents a hierarchical structure of classes and their relationships in the hospital management system. Each class has one or more parent classes, and each child class inherits from one or more of these parents.