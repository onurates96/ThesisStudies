```mermaid
classDiagram
    class Patient
        +string name
        +int age
        +string gender
        +MedicalRecord medicalRecord
        -list<Appointment> appointments
    class Doctor <|-- MedicalStaff
        +string specialty
        -list<Appointment> appointments
    class Nurse <|-- MedicalStaff
        +string department
    MedicalStaff <-- "1" -- "*" Appointment : books
    Appointment --> "1" "0..*" Patient : scheduledFor
    Appointment --> "1" "1..*" Doctor/Nurse : by
    class MedicalRecord
        +string diagnosis
        +string treatmentPlan
        +Patient patient
    MedicalRecord --> Patient : contains
```