```mermaid
classDiagram
    class Patient {
        +name: string
        +age: int
        +gender: string
        -id: int
        
        +void makeAppointment(): void { void}
        
        +void updateInfo(): void { void }
    }

    class Doctor {
        +name: string
        +age: int
        +specialty: string
        
        +void treatPatient(): void { void}
        
        +void scheduleAppointments(): void { void }
    }

    class Nurse {
        +name: string
        +age: int
        +certification: string
        
        +void assistPatient(): void { void}
        
        +void attendMeeting(): void { void}
    }

    class Appointment {
        -id: int
        -patientId: int
        -doctorId: int
        -nurseId: int
        
        +void cancel(): void { void}
        
        +void updateStatus(): void { void }
    }

    class MedicalRecord {
        +id: int
        -patientId: int
        -appointmentId: int
        
        +void addNote(): void { void}
        
        +void viewRecord(): void { void }
    }

    class MedicalStaff {
        +name: string
        +age: int
        +specialty: string
        
        +void performOperation(): void { void}
        
        +void receivePatientInfo(): void { void}
    }

    class Hospital {
        -id: int
        
        +void addMedicalStaff(): void { void}
        
        +void updateHospitalInfo(): void { void }
    }

    class MedicalRecordSystem {
        +void createPatientAccount(): void { void}

        +void assignDoctorToAppointment(): void { void}

        +void manageMedicalRecords(): void { void}
    }
```