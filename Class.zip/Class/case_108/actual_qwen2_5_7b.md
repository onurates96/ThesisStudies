```mermaid
classDiagram
    class Patient {
        -name: string
        +id: int
        +appointments: Appointment[]
        +medicalRecords: MedicalRecord[]
    }
    class Doctor {
        -name: string
        +id: int
        +specialty: string
        *appointments: Appointment
    }
    class Nurse {
        -name: string
        +id: int
        +shifts: string
        o-- Appointment
    }
    class Appointment {
        -date: Date
        -time: Time
        +patientId: int
        +doctorId: int
        *nurseId: int
    }
    class MedicalRecord {
        -id: int
        -diagnosis: string
        -treatmentPlan: string
        "1" -- "0..*" Patient : belongsTo
    }
```