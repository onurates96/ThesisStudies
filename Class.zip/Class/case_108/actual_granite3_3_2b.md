```mermaid
title: Hospital Management System Class Diagram

classDiagram
    class Patient {
        +string name
        +date birthDate
        +string address
        +list appointments Appointment
        +medicalRecord MedicalRecord
    }
    class Doctor {
        +string name
        +specialization String
        +list appointments Appointment
        +list patients Patient
    }
    class Nurse {
        +string name
        +specialization String
        +list appointments Appointment
        +list patients Patient
    }
    class Appointment {
        +date date
        +time time
        +Patient patient
        +Doctor doctor
        +Nurse nurse
    }
    class MedicalRecord {
        +string id
        +Patient patient
        +list diagnoses Diagnosis
        +list treatments Treatment
    }

Patient "1" --> * Appointment : has
Doctor "1" --> * Appointment : handles
Nurse "1" --> * Appointment : handles
Patient * -- MedicalRecord : has medical record
Doctor * -- MedicalRecord : maintains records for
Nurse * -- MedicalRecord : maintains records for
```