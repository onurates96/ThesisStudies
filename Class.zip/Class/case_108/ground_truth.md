classDiagram;
  class Patient {
    +patientId: String
    +name: String
    +dob: Date
    +address: String
  }
  class Doctor {
    +doctorId: String
    +name: String
    +specialization: String
  }
  class Nurse {
    +nurseId: String
    +name: String
    +shift: String
  }
  class Appointment {
    +appointmentId: String
    +patientId: String
    +doctorId: String
    +appointmentDateTime: DateTime
  }
  class Medical_Record {
    +recordId: String
    +patientId: String
    +doctorId: String
    +diagnosis: String
    +prescription: String
  }
  Patient "1" -- "*" Appointment: hasAppointments;
  Doctor "1" -- "*" Appointment: schedules;
  Patient "1" -- "*" Medical_Record: hasRecords;