```mermaid
classDiagram
    Patient {+string patientId, +string name, -int age}
    Doctor {+string doctorId, +string specialty}
    Nurse {+string nurseId, +string shift}
    Appointment {+date appointmentDate, +time appointmentTime, -Patient patient, -Doctor doctor, -Nurse nurse}
    MedicalRecord {+string recordId, +date admissionDate, +string diagnosis, -Patient patient}

    Patient --> "*--" Appointment : has_appointments
    Doctor <-- "1" Appointment : assigned_to
    Nurse <-- "1" Appointment : assigned_to
    Appointment <-- "-" MedicalRecord : generates_record

    class Patient{
        +void scheduleAppointment()
    }
    class Doctor{
        +void seePatient(Patient patient)
    }
    class Nurse{
        +void careForPatient(Patient patient)
    }
    class Appointment{
        +string getSchedule()
    }
    class MedicalRecord{
        +string getDiagnosis()
    }
```